create view stl_cache_policy_stats
            (node_num, promote_untracked_to_cold_untouch, promote_cold_untouch_to_cold_touch,
             promote_cold_touch_to_hot_untouch, promote_hot_untouch_to_hot_touch, reaccess_hot_touch,
             demote_hot_touch_to_hot_untouch, demote_hot_untouch_to_cold_touch, demote_cold_touch_to_cold_untouch,
             demote_cold_untouch_to_untracked, cold_blocks, hot_blocks, blocks_in_cache, start_time, end_time, capacity,
             write_accesses, rerep_writes, hot_touched_blocks, hot_untouched_blocks, cold_touched_blocks,
             cold_untouched_blocks, ghost_buffer_hits)
as
SELECT stll_cache_policy_stats.node_num,
       stll_cache_policy_stats.promote_untracked_to_cold_untouch,
       stll_cache_policy_stats.promote_cold_untouch_to_cold_touch,
       stll_cache_policy_stats.promote_cold_touch_to_hot_untouch,
       stll_cache_policy_stats.promote_hot_untouch_to_hot_touch,
       stll_cache_policy_stats.reaccess_hot_touch,
       stll_cache_policy_stats.demote_hot_touch_to_hot_untouch,
       stll_cache_policy_stats.demote_hot_untouch_to_cold_touch,
       stll_cache_policy_stats.demote_cold_touch_to_cold_untouch,
       stll_cache_policy_stats.demote_cold_untouch_to_untracked,
       stll_cache_policy_stats.cold_blocks,
       stll_cache_policy_stats.hot_blocks,
       stll_cache_policy_stats.blocks_in_cache,
       stll_cache_policy_stats.start_time,
       stll_cache_policy_stats.end_time,
       stll_cache_policy_stats.capacity,
       stll_cache_policy_stats.write_accesses,
       stll_cache_policy_stats.rerep_writes,
       stll_cache_policy_stats.hot_touched_blocks,
       stll_cache_policy_stats.hot_untouched_blocks,
       stll_cache_policy_stats.cold_touched_blocks,
       stll_cache_policy_stats.cold_untouched_blocks,
       stll_cache_policy_stats.ghost_buffer_hits
FROM stll_cache_policy_stats;

alter table stl_cache_policy_stats
    owner to rdsdb;

