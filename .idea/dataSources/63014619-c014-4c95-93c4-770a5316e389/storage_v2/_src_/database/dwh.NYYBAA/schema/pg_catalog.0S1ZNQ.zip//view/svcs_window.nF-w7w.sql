create view svcs_window
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, is_diskbased, workmem) as
SELECT stcs.userid,
       "map".primary_query                                                                                  AS query,
       stcs.slice,
       stcs.segment,
       stcs.step,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.starttime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval                                                                                 AS starttime,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.endtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision * '00:00:01'::interval   AS endtime,
       stcs.tasknum,
       stcs."rows",
       stcs.is_diskbased,
       stcs.workmem
FROM stcs_window stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE stcs.__cluster_type = 'cs'::bpchar
  AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10);

alter table svcs_window
    owner to rdsdb;

