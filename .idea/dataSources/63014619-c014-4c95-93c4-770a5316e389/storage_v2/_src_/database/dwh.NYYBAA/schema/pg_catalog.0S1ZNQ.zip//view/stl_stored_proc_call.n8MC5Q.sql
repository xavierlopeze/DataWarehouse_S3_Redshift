create view stl_stored_proc_call
            (userid, session_userid, query, label, xid, pid, database, querytxt, starttime, endtime, aborted) as
SELECT stll_stored_proc_call.userid,
       stll_stored_proc_call.session_userid,
       stll_stored_proc_call.query,
       stll_stored_proc_call."label",
       stll_stored_proc_call.xid,
       stll_stored_proc_call.pid,
       stll_stored_proc_call."database",
       stll_stored_proc_call.querytxt,
       stll_stored_proc_call.starttime,
       stll_stored_proc_call.endtime,
       stll_stored_proc_call.aborted
FROM stll_stored_proc_call;

alter table stl_stored_proc_call
    owner to rdsdb;

