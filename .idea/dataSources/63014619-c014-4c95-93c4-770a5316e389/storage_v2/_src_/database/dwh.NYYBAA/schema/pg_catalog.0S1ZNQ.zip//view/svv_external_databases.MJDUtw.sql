create view svv_external_databases(eskind, esoptions, databasename, location, parameters) as
SELECT stv_external_databases.eskind,
       btrim(stv_external_databases.esoptions::text)    AS esoptions,
       btrim(stv_external_databases.databasename::text) AS databasename,
       btrim(stv_external_databases."location"::text)   AS "location",
       btrim(stv_external_databases."parameters"::text) AS "parameters"
FROM stv_external_databases
ORDER BY stv_external_databases.eskind, btrim(stv_external_databases.esoptions::text),
         btrim(stv_external_databases.databasename::text);

alter table svv_external_databases
    owner to rdsdb;

grant select on svv_external_databases to public;

