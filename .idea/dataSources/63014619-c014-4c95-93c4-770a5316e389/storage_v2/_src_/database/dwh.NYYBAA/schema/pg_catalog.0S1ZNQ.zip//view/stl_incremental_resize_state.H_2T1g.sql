create view stl_incremental_resize_state
            (resizeid, starttime, resizephase, resizeplanstate, nodenum, globalslicenum, localslicenum, datablocks,
             metadatablocks, distallblocks, metachainblocks, blockchainmetachainblocks, leadersnapshotblocks,
             pgwalblocks, rows, distallrows, persist_temp_tables_state, temp_blocks, temp_distall_blocks, temp_rows,
             temp_distall_rows)
as
SELECT stll_incremental_resize_state.resizeid,
       stll_incremental_resize_state.starttime,
       stll_incremental_resize_state.resizephase,
       stll_incremental_resize_state.resizeplanstate,
       stll_incremental_resize_state.nodenum,
       stll_incremental_resize_state.globalslicenum,
       stll_incremental_resize_state.localslicenum,
       stll_incremental_resize_state.datablocks,
       stll_incremental_resize_state.metadatablocks,
       stll_incremental_resize_state.distallblocks,
       stll_incremental_resize_state.metachainblocks,
       stll_incremental_resize_state.blockchainmetachainblocks,
       stll_incremental_resize_state.leadersnapshotblocks,
       stll_incremental_resize_state.pgwalblocks,
       stll_incremental_resize_state."rows",
       stll_incremental_resize_state.distallrows,
       stll_incremental_resize_state.persist_temp_tables_state,
       stll_incremental_resize_state.temp_blocks,
       stll_incremental_resize_state.temp_distall_blocks,
       stll_incremental_resize_state.temp_rows,
       stll_incremental_resize_state.temp_distall_rows
FROM stll_incremental_resize_state;

alter table stl_incremental_resize_state
    owner to rdsdb;

