create view stl_block_access_errors
            (node, logtime, blkid, tbl, col, slice, sb_pos, blknum, num_values, flags, reps, s3_state, rep_strings,
             file, linenum) as
SELECT stll_block_access_errors.node,
       stll_block_access_errors.logtime,
       stll_block_access_errors.blkid,
       stll_block_access_errors.tbl,
       stll_block_access_errors.col,
       stll_block_access_errors.slice,
       stll_block_access_errors.sb_pos,
       stll_block_access_errors.blknum,
       stll_block_access_errors.num_values,
       stll_block_access_errors.flags,
       stll_block_access_errors.reps,
       stll_block_access_errors.s3_state,
       stll_block_access_errors.rep_strings,
       stll_block_access_errors."file",
       stll_block_access_errors.linenum
FROM stll_block_access_errors;

alter table stl_block_access_errors
    owner to rdsdb;

