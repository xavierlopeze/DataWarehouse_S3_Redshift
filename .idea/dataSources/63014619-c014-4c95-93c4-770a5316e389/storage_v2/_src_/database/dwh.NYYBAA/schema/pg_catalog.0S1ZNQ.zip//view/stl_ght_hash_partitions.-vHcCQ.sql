create view stl_ght_hash_partitions
            (query, slice, segment, step, lds, part_num, num_blocks, mem_resident, rows, slots, occupied, resizes) as
SELECT stll_ght_hash_partitions.query,
       stll_ght_hash_partitions.slice,
       stll_ght_hash_partitions.segment,
       stll_ght_hash_partitions.step,
       stll_ght_hash_partitions.lds,
       stll_ght_hash_partitions.part_num,
       stll_ght_hash_partitions.num_blocks,
       stll_ght_hash_partitions.mem_resident,
       stll_ght_hash_partitions."rows",
       stll_ght_hash_partitions.slots,
       stll_ght_hash_partitions.occupied,
       stll_ght_hash_partitions.resizes
FROM stll_ght_hash_partitions;

alter table stl_ght_hash_partitions
    owner to rdsdb;

