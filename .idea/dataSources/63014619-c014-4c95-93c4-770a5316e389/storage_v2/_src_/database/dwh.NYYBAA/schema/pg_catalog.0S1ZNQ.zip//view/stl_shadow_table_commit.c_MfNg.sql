create view stl_shadow_table_commit(xid, record_time, status, lock_duration) as
SELECT stll_shadow_table_commit.xid,
       stll_shadow_table_commit.record_time,
       stll_shadow_table_commit.status,
       stll_shadow_table_commit.lock_duration
FROM stll_shadow_table_commit;

alter table stl_shadow_table_commit
    owner to rdsdb;

