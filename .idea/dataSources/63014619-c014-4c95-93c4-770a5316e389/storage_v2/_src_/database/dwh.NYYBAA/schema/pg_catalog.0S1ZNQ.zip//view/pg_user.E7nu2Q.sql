create view pg_user (usename, usesysid, usecreatedb, usesuper, usecatupd, passwd, valuntil, useconfig) as
SELECT pg_shadow.usename,
       pg_shadow.usesysid,
       pg_shadow.usecreatedb,
       pg_shadow.usesuper,
       pg_shadow.usecatupd,
       '********'::character varying AS passwd,
       pg_shadow.valuntil,
       pg_shadow.useconfig
FROM pg_shadow
WHERE pg_shadow.usename !~~ 'f346c9b8%'::text;

alter table pg_user
    owner to rdsdb;

grant select on pg_user to public;

