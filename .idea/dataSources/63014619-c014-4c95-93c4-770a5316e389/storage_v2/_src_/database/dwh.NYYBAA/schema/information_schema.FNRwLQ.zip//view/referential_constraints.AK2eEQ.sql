create view referential_constraints
            (constraint_catalog, constraint_schema, constraint_name, unique_constraint_catalog,
             unique_constraint_schema, unique_constraint_name, match_option, update_rule, delete_rule)
as
SELECT current_database()::information_schema.sql_identifier AS constraint_catalog,
       ncon.nspname::information_schema.sql_identifier       AS constraint_schema,
       con.conname::information_schema.sql_identifier        AS constraint_name,
       CASE
           WHEN npkc.nspname IS NULL THEN NULL::name
           ELSE current_database()
           END::information_schema.sql_identifier            AS unique_constraint_catalog,
       npkc.nspname::information_schema.sql_identifier       AS unique_constraint_schema,
       pkc.conname::information_schema.sql_identifier        AS unique_constraint_name,
       CASE
           WHEN con.confmatchtype = 'f'::"char" THEN 'FULL'::text
           WHEN con.confmatchtype = 'p'::"char" THEN 'PARTIAL'::text
           WHEN con.confmatchtype = 'u'::"char" THEN 'NONE'::text
           ELSE NULL::text
           END::information_schema.character_data            AS match_option,
       CASE
           WHEN con.confupdtype = 'c'::"char" THEN 'CASCADE'::text
           WHEN con.confupdtype = 'n'::"char" THEN 'SET NULL'::text
           WHEN con.confupdtype = 'd'::"char" THEN 'SET DEFAULT'::text
           WHEN con.confupdtype = 'r'::"char" THEN 'RESTRICT'::text
           WHEN con.confupdtype = 'a'::"char" THEN 'NO ACTION'::text
           ELSE NULL::text
           END::information_schema.character_data            AS update_rule,
       CASE
           WHEN con.confdeltype = 'c'::"char" THEN 'CASCADE'::text
           WHEN con.confdeltype = 'n'::"char" THEN 'SET NULL'::text
           WHEN con.confdeltype = 'd'::"char" THEN 'SET DEFAULT'::text
           WHEN con.confdeltype = 'r'::"char" THEN 'RESTRICT'::text
           WHEN con.confdeltype = 'a'::"char" THEN 'NO ACTION'::text
           ELSE NULL::text
           END::information_schema.character_data            AS delete_rule
FROM pg_namespace ncon
         JOIN pg_constraint con ON ncon.oid = con.connamespace
         JOIN pg_class c ON con.conrelid = c.oid
         JOIN pg_user u ON c.relowner = u.usesysid
         LEFT JOIN (pg_constraint pkc
    JOIN pg_namespace npkc ON pkc.connamespace = npkc.oid)
                   ON con.confrelid = pkc.conrelid AND information_schema._pg_keysequal(con.confkey, pkc.conkey)
WHERE c.relkind = 'r'::"char"
  AND con.contype = 'f'::"char"
  AND (pkc.contype = 'p'::"char" OR pkc.contype = 'u'::"char" OR pkc.contype IS NULL)
  AND u.usename = "current_user"()::name;

alter table referential_constraints
    owner to rdsdb;

grant select on referential_constraints to public;

