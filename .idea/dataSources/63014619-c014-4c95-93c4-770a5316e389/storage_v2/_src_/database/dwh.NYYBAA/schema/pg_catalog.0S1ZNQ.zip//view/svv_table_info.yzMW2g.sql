create view svv_table_info
            (database, schema, table_id, "table", encoded, diststyle, sortkey1, max_varchar, sortkey1_enc, sortkey_num,
             size, pct_used, empty, unsorted, stats_off, tbl_rows, skew_sortkey1, skew_rows, estimated_visible_rows,
             risk_event, vacuum_sort_benefit)
as
SELECT tbl_info_base."database",
       tbl_info_base."schema",
       tbl_info_base.table_id,
       tbl_info_base."table",
       tbl_info_base.encoded,
       tbl_info_base."diststyle",
       tbl_info_base.sortkey1,
       tbl_info_base.max_varchar,
       tbl_info_base.sortkey1_enc,
       tbl_info_base.sortkey_num,
       tbl_info_base.size,
       tbl_info_base.pct_used,
       tbl_info_base.empty,
       tbl_info_base.unsorted,
       CASE
           WHEN psi.stairows = 0::double precision AND
                (psi.staidels > 0::double precision OR psi.staiins > 0::double precision)
               THEN 100::numeric::numeric(5, 2)
           WHEN psi.stairows = 0::double precision AND psi.staidels = 0::double precision AND
                psi.staiins = 0::double precision THEN NULL::numeric
           WHEN psi.stairows IS NULL THEN NULL::numeric
           WHEN tbl_info_base.tbl_rows = 0::numeric THEN NULL::numeric
           WHEN psi.stairows > 0::double precision THEN LEAST(
                   (psi.staidels + psi.staiins) * 100::double precision / psi.stairows,
                   100::double precision)::numeric(5, 2)
           ELSE NULL::numeric
           END                      AS stats_off,
       tbl_info_base.tbl_rows,
       tbl_info_base.skew_sortkey1,
       tbl_info_base.skew_rows,
       psi.stairows::numeric(38, 0) AS estimated_visible_rows,
       tbl_info_base.risk_event,
       tbl_info_base.vacuum_sort_benefit
FROM (SELECT row_d.db_n                                     AS "database",
             stg_d.schema_n                                 AS "schema",
             stg_d.tbl_id                                   AS table_id,
             stg_d.tbl_n                                    AS "table",
             CASE
                 WHEN strct_d.max_enc = 0 AND strct_d.is_encode_auto = 1 THEN 'N, AUTO(ENCODE)'::text
                 WHEN strct_d.max_enc <> 0 AND strct_d.is_encode_auto = 1 THEN 'Y, AUTO(ENCODE)'::text
                 ELSE
                     CASE
                         WHEN strct_d.max_enc = 0 THEN 'N'::text
                         ELSE 'Y'::text
                         END
                 END                                        AS encoded,
             btrim(
                     CASE
                         WHEN stg_d."diststyle" = 0 THEN 'EVEN'::text
                         WHEN stg_d."diststyle" = 1 THEN ('KEY('::text || strct_d."distkey") || ')'::text
                         WHEN stg_d."diststyle" = 8 THEN 'ALL'::text
                         WHEN stg_d."diststyle" = 10 THEN 'AUTO(ALL)'::text
                         WHEN stg_d."diststyle" = 11 THEN 'AUTO(EVEN)'::text
                         WHEN stg_d."diststyle" = 12 THEN ('AUTO(KEY('::text || strct_d."distkey") || '))'::text
                         ELSE NULL::text
                         END)                               AS "diststyle",
             CASE
                 WHEN strct_d.is_sortkey_auto < 1 THEN btrim(strct_d.headsort)
                 WHEN strct_d.is_sortkey_auto = 1 AND btrim(strct_d.headsort) IS NOT NULL
                     THEN ('AUTO(SORTKEY('::text || btrim(strct_d.headsort)) || '))'::text
                 WHEN strct_d.is_sortkey_auto = 1 AND btrim(strct_d.headsort) IS NULL THEN 'AUTO(SORTKEY)'::text
                 ELSE NULL::text
                 END                                        AS sortkey1,
             strct_d.max_vc_size                            AS max_varchar,
             format_encoding(strct_d.headsort_enc::integer) AS sortkey1_enc,
             strct_d.n_sortkeys                             AS sortkey_num,
             sum(stg_d.col_mb)                              AS size,
             CASE
                 WHEN cap_d.total_mb = 0 THEN NULL::numeric
                 ELSE (sum(stg_d.col_mb)::numeric::numeric(19, 3) / cap_d.total_mb::numeric::numeric(19, 3) *
                       100::numeric)::numeric(10, 4)
                 END                                        AS pct_used,
             sum(stg_d.empty_col_mb)                        AS empty,
             CASE
                 WHEN row_d.tbl_rows = 0 THEN NULL::numeric
                 WHEN strct_d.n_sortkeys = 0 THEN NULL::numeric
                 ELSE (row_d.unsorted_tbl_rows::numeric::numeric(19, 3) / row_d.tbl_rows::numeric::numeric(19, 3) *
                       100::numeric)::numeric(5, 2)
                 END                                        AS unsorted,
             CASE
                 WHEN row_d.tbl_rows = 0 THEN NULL::numeric
                 WHEN strct_d.n_sortkeys = 0 THEN NULL::numeric
                 WHEN "max"(tbl_avg_qpd.avg_qpd) IS NULL THEN 0::numeric
                 ELSE "max"(tbl_avg_qpd.avg_qpd)
                 END::numeric(12, 2)                        AS vacuum_sort_benefit,
             CASE
                 WHEN (stg_d."diststyle" = 8 OR stg_d."diststyle" = 10) AND "max"(row_d.node_num) > 0
                     THEN (row_d.tbl_rows / "max"(row_d.node_num))::numeric::numeric(38, 0)
                 ELSE row_d.tbl_rows::numeric
                 END                                        AS tbl_rows,
             CASE
                 WHEN "max"(stg_d.sk_mb) = 0 THEN NULL::numeric
                 WHEN btrim(strct_d.headsort) = 'INTERLEAVED'::text THEN NULL::numeric
                 WHEN strct_d.n_sortkeys = 0 THEN NULL::numeric
                 ELSE ("max"(stg_d.col_mb)::numeric::numeric(19, 3) /
                       "max"(stg_d.sk_mb)::numeric::numeric(19, 3))::numeric(19, 2)
                 END                                        AS skew_sortkey1,
             CASE
                 WHEN stg_d."diststyle" = 0 OR stg_d."diststyle" = 8 OR stg_d."diststyle" = 10 OR stg_d."diststyle" = 11
                     THEN NULL::numeric
                 WHEN row_d.min_slice_rows = 0 AND row_d.max_slice_rows = 0 THEN 0::numeric
                 WHEN row_d.min_slice_rows = 0 AND row_d.max_slice_rows > 0 THEN 100::numeric
                 ELSE (row_d.max_slice_rows::numeric::numeric(19, 3) /
                       row_d.min_slice_rows::numeric::numeric(19, 3))::numeric(19, 2)
                 END                                        AS skew_rows,
             risk_d.value                                   AS risk_event
      FROM (SELECT btrim(pn.nspname::text) AS schema_n,
                   btrim(pc.relname::text) AS tbl_n,
                   pc.oid                  AS tbl_id,
                   sb.col,
                   CASE
                       WHEN pc.reldiststyle <= 8 THEN pc.reldiststyle::integer
                       ELSE pce.value::integer
                       END                 AS "diststyle",
                   pc.reltuples            AS stats_rows,
                   count(sb.blocknum)      AS col_mb,
                   sum(
                           CASE
                               WHEN pa.attnum IS NOT NULL AND pa.attnum = (sb.col + 1) THEN 1
                               ELSE 0
                               END)        AS sk_mb,
                   sum(
                           CASE
                               WHEN sb.tombstone > 0 THEN 1
                               ELSE 0
                               END)        AS empty_col_mb
            FROM stv_blocklist sb
                     JOIN pg_class pc ON sb.tbl::oid = pc.oid
                     JOIN pg_namespace pn ON pc.relnamespace = pn.oid
                     LEFT JOIN pg_class_extended pce ON pce.reloid = pc.oid AND pce.colnum = 0
                     LEFT JOIN pg_attribute pa
                               ON sb.tbl::oid = pa.attrelid AND pa.attsortkeyord = 1 AND pa.attisdropped = false
            GROUP BY btrim(pn.nspname::text), btrim(pc.relname::text), pc.oid, sb.col, pce.value, pc.reldiststyle,
                     pc.reltuples) stg_d
               JOIN (SELECT sum(sp.capacity) AS total_mb
                     FROM stv_node_storage_capacity sp) cap_d ON 1 = 1
               JOIN (SELECT inner_q.db_n,
                            inner_q.tbl_id,
                            count(DISTINCT inner_q.node_num) AS node_num,
                            sum(inner_q.slice_rows)          AS tbl_rows,
                            sum(inner_q.unsorted_slice_rows) AS unsorted_tbl_rows,
                            min(inner_q.slice_rows)          AS min_slice_rows,
                            "max"(inner_q.slice_rows)        AS max_slice_rows
                     FROM (SELECT btrim(pd.datname::text)           AS db_n,
                                  stp.id                            AS tbl_id,
                                  stp.slice,
                                  ss.node                           AS node_num,
                                  sum(stp."rows")                   AS slice_rows,
                                  sum(stp."rows" - stp.sorted_rows) AS unsorted_slice_rows
                           FROM stv_tbl_perm stp,
                                pg_database pd,
                                stv_slices ss
                           WHERE stp.db_id::oid = pd.oid
                             AND stp.slice = ss.slice
                           GROUP BY btrim(pd.datname::text), stp.id, ss.node, stp.slice) inner_q
                     GROUP BY inner_q.db_n, inner_q.tbl_id) row_d ON row_d.tbl_id::oid = stg_d.tbl_id
               JOIN (SELECT pa.attrelid                                     AS tbl_id,
                            CASE
                                WHEN pce.value IS NULL THEN -1
                                ELSE pce.value::integer
                                END                                         AS is_sortkey_auto,
                            CASE
                                WHEN pce_enc.value IS NULL THEN -1
                                ELSE pce_enc.value::integer
                                END                                         AS is_encode_auto,
                            min(
                                    CASE
                                        WHEN pa.attisdistkey = true AND NOT pa.attisdropped THEN pa.attname
                                        ELSE NULL::name
                                        END::text)                          AS "distkey",
                            min(
                                    CASE
                                        WHEN pa.attsortkeyord = 1 AND NOT pa.attisdropped THEN pa.attname
                                        WHEN pa.attsortkeyord = -1 AND NOT pa.attisdropped THEN 'INTERLEAVED'::name
                                        ELSE NULL::name
                                        END::text)                          AS headsort,
                            min(
                                    CASE
                                        WHEN abs(pa.attsortkeyord) = 1 AND NOT pa.attisdropped THEN pa.attnum
                                        ELSE NULL::smallint
                                        END)                                AS headsort_col,
                            min(
                                    CASE
                                        WHEN abs(pa.attsortkeyord) = 1 AND NOT pa.attisdropped THEN pa.attencodingtype
                                        ELSE NULL::smallint
                                        END)                                AS headsort_enc,
                            "max"(abs(pa.attsortkeyord))                    AS n_sortkeys,
                            "max"(COALESCE(pa.attencodingtype::integer, 0)) AS max_enc,
                            "max"(
                                    CASE
                                        WHEN pt.typname = 'varchar'::name THEN pa.atttypmod - 4
                                        ELSE 0
                                        END)                                AS max_vc_size
                     FROM pg_attribute pa
                              LEFT JOIN pg_class_extended pce ON pa.attrelid = pce.reloid AND pce.colnum = 12
                              LEFT JOIN pg_class_extended pce_enc
                                        ON pa.attrelid = pce_enc.reloid AND pce_enc.colnum = 14
                              JOIN pg_type pt ON pa.atttypid = pt.oid AND pa.attnum > 0
                     GROUP BY pa.attrelid, pce.value, pce_enc.value) strct_d ON strct_d.tbl_id = stg_d.tbl_id
               LEFT JOIN (SELECT pce.reloid AS tbl_id,
                                 CASE
                                     WHEN pce.value = ''::text THEN 'NULL'::text
                                     ELSE "replace"(pce.value, split_part(pce.value, '|'::text, 3),
                                                    date_add('microseconds'::text,
                                                             split_part(pce.value, '|'::text, 3)::bigint,
                                                             '2000-01-01 00:00:00'::timestamp without time zone)::text)
                                     END    AS value
                          FROM pg_class_extended pce
                          WHERE pce.colnum = 5) risk_d ON risk_d.tbl_id = stg_d.tbl_id
               LEFT JOIN (SELECT stv_table_partitions.id,
                                 CASE
                                     WHEN sum(stv_table_partitions.qpd) = 0 THEN NULL::numeric
                                     ELSE avg(stv_table_partitions.qpd)::numeric::numeric(12, 2)
                                     END::numeric(12, 2) AS avg_qpd
                          FROM stv_table_partitions
                          WHERE stv_table_partitions.is_sorted = 'f'::bpchar
                            AND stv_table_partitions.qpd > 0
                          GROUP BY stv_table_partitions.id) tbl_avg_qpd ON stg_d.tbl_id = tbl_avg_qpd.id::oid
      GROUP BY row_d.db_n, stg_d.schema_n, stg_d.tbl_n, stg_d.tbl_id,
               CASE
                   WHEN strct_d.max_enc = 0 AND strct_d.is_encode_auto = 1 THEN 'N, AUTO(ENCODE)'::text
                   WHEN strct_d.max_enc <> 0 AND strct_d.is_encode_auto = 1 THEN 'Y, AUTO(ENCODE)'::text
                   ELSE
                       CASE
                           WHEN strct_d.max_enc = 0 THEN 'N'::text
                           ELSE 'Y'::text
                           END
                   END,
               btrim(
                       CASE
                           WHEN stg_d."diststyle" = 0 THEN 'EVEN'::text
                           WHEN stg_d."diststyle" = 1 THEN ('KEY('::text || strct_d."distkey") || ')'::text
                           WHEN stg_d."diststyle" = 8 THEN 'ALL'::text
                           WHEN stg_d."diststyle" = 10 THEN 'AUTO(ALL)'::text
                           WHEN stg_d."diststyle" = 11 THEN 'AUTO(EVEN)'::text
                           WHEN stg_d."diststyle" = 12 THEN ('AUTO(KEY('::text || strct_d."distkey") || '))'::text
                           ELSE NULL::text
                           END), stg_d."diststyle", btrim(strct_d.headsort), strct_d.max_vc_size,
               format_encoding(strct_d.headsort_enc::integer), strct_d.n_sortkeys, strct_d.is_sortkey_auto,
               strct_d.is_encode_auto, strct_d.max_enc, cap_d.total_mb, row_d.tbl_rows, row_d.unsorted_tbl_rows,
               row_d.min_slice_rows, row_d.max_slice_rows, risk_d.value) tbl_info_base
         LEFT JOIN (SELECT pg_statistic_indicator.stairelid,
                           sum(pg_statistic_indicator.stairows) AS stairows,
                           sum(pg_statistic_indicator.staiins)  AS staiins,
                           sum(pg_statistic_indicator.staidels) AS staidels
                    FROM pg_statistic_indicator
                    GROUP BY pg_statistic_indicator.stairelid
                    HAVING count(pg_statistic_indicator.stairelid) = 1) psi ON tbl_info_base.table_id = psi.stairelid;

alter table svv_table_info
    owner to rdsdb;

