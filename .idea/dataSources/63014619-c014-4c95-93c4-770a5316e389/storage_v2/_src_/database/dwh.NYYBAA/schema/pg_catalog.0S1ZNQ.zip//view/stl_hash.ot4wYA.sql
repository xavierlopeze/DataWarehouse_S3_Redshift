create view stl_hash
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, slots, occupied, maxlength,
             tbl, is_diskbased, workmem, num_parts, est_rows, num_blocks_permitted, resizes, checksum, used_prefetching,
             runtime_filter_size, max_runtime_filter_size, runtime_filter_type, is_hashed_subplan,
             build_global_hash_table)
as
SELECT stll_hash.userid,
       stll_hash.query,
       stll_hash.slice,
       stll_hash.segment,
       stll_hash.step,
       stll_hash.starttime,
       stll_hash.endtime,
       stll_hash.tasknum,
       stll_hash."rows",
       stll_hash.bytes,
       stll_hash.slots,
       stll_hash.occupied,
       stll_hash.maxlength,
       stll_hash.tbl,
       stll_hash.is_diskbased,
       stll_hash.workmem,
       stll_hash.num_parts,
       stll_hash.est_rows,
       stll_hash.num_blocks_permitted,
       stll_hash.resizes,
       stll_hash.checksum,
       stll_hash.used_prefetching,
       stll_hash.runtime_filter_size,
       stll_hash.max_runtime_filter_size,
       stll_hash.runtime_filter_type,
       stll_hash.is_hashed_subplan,
       stll_hash.build_global_hash_table
FROM stll_hash;

alter table stl_hash
    owner to rdsdb;

grant select on stl_hash to public;

