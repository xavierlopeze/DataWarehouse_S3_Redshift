create view stl_metadata_step (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl) as
SELECT stll_metadata_step.userid,
       stll_metadata_step.query,
       stll_metadata_step.slice,
       stll_metadata_step.segment,
       stll_metadata_step.step,
       stll_metadata_step.starttime,
       stll_metadata_step.endtime,
       stll_metadata_step.tasknum,
       stll_metadata_step."rows",
       stll_metadata_step.tbl
FROM stll_metadata_step;

alter table stl_metadata_step
    owner to rdsdb;

grant select on stl_metadata_step to public;

