create view pg_stats
            (schemaname, tablename, attname, null_frac, avg_width, n_distinct, most_common_vals, most_common_freqs,
             histogram_bounds, correlation)
as
SELECT n.nspname     AS schemaname,
       c.relname     AS tablename,
       a.attname,
       s.stanullfrac AS null_frac,
       s.stawidth    AS avg_width,
       s.stadistinct AS n_distinct,
       CASE
           WHEN 1 = s.stakind1 THEN s.stavalues1
           WHEN 1 = s.stakind2 THEN s.stavalues2
           WHEN 1 = s.stakind3 THEN s.stavalues3
           WHEN 1 = s.stakind4 THEN s.stavalues4
           ELSE NULL::"unknown"
           END       AS most_common_vals,
       CASE
           WHEN 1 = s.stakind1 THEN s.stanumbers1
           WHEN 1 = s.stakind2 THEN s.stanumbers2
           WHEN 1 = s.stakind3 THEN s.stanumbers3
           WHEN 1 = s.stakind4 THEN s.stanumbers4
           ELSE NULL::real[]
           END       AS most_common_freqs,
       CASE
           WHEN 2 = s.stakind1 THEN s.stavalues1
           WHEN 2 = s.stakind2 THEN s.stavalues2
           WHEN 2 = s.stakind3 THEN s.stavalues3
           WHEN 2 = s.stakind4 THEN s.stavalues4
           ELSE NULL::"unknown"
           END       AS histogram_bounds,
       CASE
           WHEN 3 = s.stakind1 THEN s.stanumbers1[1]
           WHEN 3 = s.stakind2 THEN s.stanumbers2[1]
           WHEN 3 = s.stakind3 THEN s.stanumbers3[1]
           WHEN 3 = s.stakind4 THEN s.stanumbers4[1]
           ELSE NULL::real
           END       AS correlation
FROM pg_statistic s
         JOIN pg_class c ON c.oid = s.starelid
         JOIN pg_attribute a ON c.oid = a.attrelid AND a.attnum = s.staattnum
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE has_table_privilege(c.oid, 'select'::text);

alter table pg_stats
    owner to rdsdb;

grant select on pg_stats to public;

