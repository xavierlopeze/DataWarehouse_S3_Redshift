create view stl_disks_blocks_stats
            (node, logtime, local_cap, sb_cap, allocated_blks, primary_allocated_blks, mirror_allocated_blks, perm_blks,
             to_backup_blks, temp_blks, local_backedup_blks, primary_rerep_blks, mirror_rerep_blks,
             num_primary_reserved, num_mirror_reserved)
as
SELECT stll_disks_blocks_stats.node,
       stll_disks_blocks_stats.logtime,
       stll_disks_blocks_stats.local_cap,
       stll_disks_blocks_stats.sb_cap,
       stll_disks_blocks_stats.allocated_blks,
       stll_disks_blocks_stats.primary_allocated_blks,
       stll_disks_blocks_stats.mirror_allocated_blks,
       stll_disks_blocks_stats.perm_blks,
       stll_disks_blocks_stats.to_backup_blks,
       stll_disks_blocks_stats.temp_blks,
       stll_disks_blocks_stats.local_backedup_blks,
       stll_disks_blocks_stats.primary_rerep_blks,
       stll_disks_blocks_stats.mirror_rerep_blks,
       stll_disks_blocks_stats.num_primary_reserved,
       stll_disks_blocks_stats.num_mirror_reserved
FROM stll_disks_blocks_stats;

alter table stl_disks_blocks_stats
    owner to rdsdb;

