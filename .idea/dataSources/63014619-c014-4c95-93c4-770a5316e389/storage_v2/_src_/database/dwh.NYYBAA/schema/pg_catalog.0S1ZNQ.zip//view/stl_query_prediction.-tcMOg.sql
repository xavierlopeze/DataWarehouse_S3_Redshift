create view stl_query_prediction
            (query, xid, execution_time, execution_time_error, memory, memory_error, execution_time_without_compile,
             execution_time_without_compile_error)
as
SELECT stll_query_prediction.query,
       stll_query_prediction.xid,
       stll_query_prediction.execution_time,
       stll_query_prediction.execution_time_error,
       stll_query_prediction.memory,
       stll_query_prediction.memory_error,
       stll_query_prediction.execution_time_without_compile,
       stll_query_prediction.execution_time_without_compile_error
FROM stll_query_prediction;

alter table stl_query_prediction
    owner to rdsdb;

