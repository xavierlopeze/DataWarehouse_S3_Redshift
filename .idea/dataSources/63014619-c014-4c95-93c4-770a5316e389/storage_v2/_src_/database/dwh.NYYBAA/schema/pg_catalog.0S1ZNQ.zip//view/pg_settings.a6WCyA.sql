create view pg_settings (name, setting, category, short_desc, extra_desc, context, vartype, source, min_val, max_val) as
SELECT a.name,
       a.setting,
       a.category,
       a.short_desc,
       a.extra_desc,
       a.context,
       a.vartype,
       a.source,
       a.min_val,
       a.max_val
FROM pg_show_all_settings() a(name character varying, setting character varying, category character varying,
                              short_desc character varying, extra_desc character varying, context character varying,
                              vartype character varying, source character varying, min_val character varying,
                              max_val character varying);

alter table pg_settings
    owner to rdsdb;

grant select, update on pg_settings to public;

