create view stl_federated_trace(userid, xid, pid, query, recordtime, message, on_leader) as
SELECT stll_federated_trace.userid,
       stll_federated_trace.xid,
       stll_federated_trace.pid,
       stll_federated_trace.query,
       stll_federated_trace.recordtime,
       stll_federated_trace.message,
       stll_federated_trace.on_leader
FROM stll_federated_trace;

alter table stl_federated_trace
    owner to rdsdb;

