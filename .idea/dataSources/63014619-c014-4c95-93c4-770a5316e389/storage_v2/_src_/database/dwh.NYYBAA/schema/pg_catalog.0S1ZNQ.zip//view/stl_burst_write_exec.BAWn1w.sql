create view stl_burst_write_exec
            (pid, xid, query, query_start_time, flush_start_time, stream_start_time, stream_end_time,
             dispatch_start_time, snap_in_start_time, snap_in_end_time)
as
SELECT stll_burst_write_exec.pid,
       stll_burst_write_exec.xid,
       stll_burst_write_exec.query,
       stll_burst_write_exec.query_start_time,
       stll_burst_write_exec.flush_start_time,
       stll_burst_write_exec.stream_start_time,
       stll_burst_write_exec.stream_end_time,
       stll_burst_write_exec.dispatch_start_time,
       stll_burst_write_exec.snap_in_start_time,
       stll_burst_write_exec.snap_in_end_time
FROM stll_burst_write_exec;

alter table stl_burst_write_exec
    owner to rdsdb;

