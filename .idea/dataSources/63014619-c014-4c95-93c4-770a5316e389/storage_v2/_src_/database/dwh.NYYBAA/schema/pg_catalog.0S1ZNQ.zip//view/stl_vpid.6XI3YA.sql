create view stl_vpid(vpid, pid, recordtime, processname) as
SELECT stll_vpid.vpid, stll_vpid.pid, stll_vpid.recordtime, stll_vpid.processname
FROM stll_vpid;

alter table stl_vpid
    owner to rdsdb;

