create view svl_s3log(pid, query, segment, step, node, slice, eventtime, message) as
SELECT stl_s3log.pid,
       stl_s3log.query,
       stl_s3log.segment,
       stl_s3log.step,
       stl_s3log.node,
       stl_s3log.slice,
       stl_s3log.eventtime,
       btrim(stl_s3log.message::text) AS message
FROM stl_s3log
WHERE stl_s3log.is_internal = 0;

alter table svl_s3log
    owner to rdsdb;

grant select on svl_s3log to public;

