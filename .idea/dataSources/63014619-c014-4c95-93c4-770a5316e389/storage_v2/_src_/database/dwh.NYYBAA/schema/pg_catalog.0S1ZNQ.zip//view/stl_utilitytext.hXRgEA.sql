create view stl_utilitytext(userid, xid, pid, label, starttime, endtime, sequence, text) as
SELECT stll_utilitytext.userid,
       stll_utilitytext.xid,
       stll_utilitytext.pid,
       stll_utilitytext."label",
       stll_utilitytext.starttime,
       stll_utilitytext.endtime,
       stll_utilitytext."sequence",
       stll_utilitytext.text
FROM stll_utilitytext;

alter table stl_utilitytext
    owner to rdsdb;

grant select on stl_utilitytext to public;

