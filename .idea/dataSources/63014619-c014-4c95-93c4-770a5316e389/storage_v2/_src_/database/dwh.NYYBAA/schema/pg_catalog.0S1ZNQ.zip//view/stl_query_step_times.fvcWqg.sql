create view stl_query_step_times
            (xid, query, segment, step, slice, step_name, step_type, step_specific, step_shared, step_common, duration,
             on_cpu, off_cpu)
as
SELECT stll_query_step_times.xid,
       stll_query_step_times.query,
       stll_query_step_times.segment,
       stll_query_step_times.step,
       stll_query_step_times.slice,
       stll_query_step_times.step_name,
       stll_query_step_times.step_type,
       stll_query_step_times.step_specific,
       stll_query_step_times.step_shared,
       stll_query_step_times.step_common,
       stll_query_step_times.duration,
       stll_query_step_times.on_cpu,
       stll_query_step_times.off_cpu
FROM stll_query_step_times;

alter table stl_query_step_times
    owner to rdsdb;

