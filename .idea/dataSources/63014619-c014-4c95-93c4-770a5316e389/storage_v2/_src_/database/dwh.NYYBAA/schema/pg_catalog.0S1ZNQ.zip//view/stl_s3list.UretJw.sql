create view stl_s3list
            (userid, query, uuid, segment, node, slice, eventtime, bucket, prefix, recursive, retrieved_files,
             max_file_size, avg_file_size, duration, generated_splits, avg_split_length, scan_type)
as
SELECT stll_s3list.userid,
       stll_s3list.query,
       stll_s3list.uuid,
       stll_s3list.segment,
       stll_s3list.node,
       stll_s3list.slice,
       stll_s3list.eventtime,
       stll_s3list.bucket,
       stll_s3list.prefix,
       stll_s3list."recursive",
       stll_s3list.retrieved_files,
       stll_s3list.max_file_size,
       stll_s3list.avg_file_size,
       stll_s3list.duration,
       stll_s3list.generated_splits,
       stll_s3list.avg_split_length,
       stll_s3list.scan_type
FROM stll_s3list;

alter table stl_s3list
    owner to rdsdb;

