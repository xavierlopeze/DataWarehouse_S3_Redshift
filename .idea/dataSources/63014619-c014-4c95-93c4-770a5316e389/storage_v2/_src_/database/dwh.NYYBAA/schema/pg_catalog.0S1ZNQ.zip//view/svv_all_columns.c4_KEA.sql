create view svv_all_columns
            (database_name, schema_name, table_name, column_name, ordinal_position, column_default, is_nullable,
             data_type, character_maximum_length, numeric_precision, numeric_scale, remarks)
as
(SELECT svv_redshift_columns.database_name,
        svv_redshift_columns.schema_name,
        svv_redshift_columns.table_name,
        svv_redshift_columns.column_name,
        svv_redshift_columns.ordinal_position,
        svv_redshift_columns.column_default,
        svv_redshift_columns.is_nullable,
        CASE
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'numeric'::text OR
                 "left"(svv_redshift_columns.data_type::text, 7) = 'decimal'::text THEN 'numeric'::character varying
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'varchar'::text OR
                 "left"(svv_redshift_columns.data_type::text, 17) = 'character varying'::text
                THEN 'character varying'::character varying
            WHEN "left"(svv_redshift_columns.data_type::text, 4) = 'char'::text OR
                 "left"(svv_redshift_columns.data_type::text, 9) = 'character'::text THEN 'character'::character varying
            WHEN svv_redshift_columns.data_type::text = 'information_schema.sql_identifier'::text
                THEN 'sql_identifier'::character varying
            WHEN svv_redshift_columns.data_type::text = 'information_schema.character_data'::text
                THEN 'character_data'::character varying
            WHEN svv_redshift_columns.data_type::text = 'information_schema.cardinal_number'::text
                THEN 'cardinal_number'::character varying
            ELSE svv_redshift_columns.data_type
            END::character varying(128) AS data_type,
        CASE
            WHEN svv_redshift_columns.data_type::text = 'varchar'::text OR
                 svv_redshift_columns.data_type::text = 'character varying'::text OR
                 svv_redshift_columns.data_type::text = 'char'::text THEN -1
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'varchar'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text, 7)::integer
            WHEN "left"(svv_redshift_columns.data_type::text, 4) = 'char'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text, 4)::integer
            WHEN svv_redshift_columns.data_type::text = 'string'::text THEN 16383
            ELSE NULL::integer
            END                         AS character_maximum_length,
        CASE
            WHEN svv_redshift_columns.data_type::text = 'int2'::text OR
                 svv_redshift_columns.data_type::text = 'smallint'::text THEN 16
            WHEN svv_redshift_columns.data_type::text = 'int'::text OR
                 svv_redshift_columns.data_type::text = 'int4'::text OR svv_redshift_columns.data_type::text = 'integer'::text
                THEN 32
            WHEN svv_redshift_columns.data_type::text = 'int8'::text OR svv_redshift_columns.data_type::text = 'bigint'::text
                THEN 64
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'decimal'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text, 7)::integer
            WHEN svv_redshift_columns.data_type::text = 'float'::text THEN 24
            WHEN svv_redshift_columns.data_type::text = 'double'::text THEN 53
            WHEN svv_redshift_columns.data_type::text = 'numeric'::text OR
                 svv_redshift_columns.data_type::text = 'decimal'::text THEN NULL::integer
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'numeric'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text, 0, 1)::integer
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'decimal'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text, 0, 1)::integer
            ELSE NULL::integer
            END                         AS numeric_precision,
        CASE
            WHEN svv_redshift_columns.data_type::text = 'int2'::text OR
                 svv_redshift_columns.data_type::text = 'smallint'::text OR
                 svv_redshift_columns.data_type::text = 'int4'::text OR
                 svv_redshift_columns.data_type::text = 'int'::text OR
                 svv_redshift_columns.data_type::text = 'integer'::text OR
                 svv_redshift_columns.data_type::text = 'int8'::text OR svv_redshift_columns.data_type::text = 'bigint'::text
                THEN '0'::text
            WHEN svv_redshift_columns.data_type::text = 'decimal'::text OR
                 svv_redshift_columns.data_type::text = 'numeric'::text THEN NULL::text
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'decimal'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text,
                    regexp_instr(svv_redshift_columns.data_type::text, ','::text, 7))
            WHEN "left"(svv_redshift_columns.data_type::text, 7) = 'numeric'::text THEN regexp_substr(
                    svv_redshift_columns.data_type::text, '[0-9]+'::text,
                    regexp_instr(svv_redshift_columns.data_type::text, ','::text, 7))
            ELSE NULL::text
            END::integer                AS numeric_scale,
        svv_redshift_columns.remarks
 FROM svv_redshift_columns
 UNION ALL
 SELECT current_database()::character varying(128)                  AS database_name,
        btrim(ext_columns.schemaname::text)::character varying(128) AS schema_name,
        btrim(ext_columns.tablename::text)::character varying(128)  AS table_name,
        btrim(ext_columns.columnname::text)::character varying(128) AS column_name,
        ext_columns.columnnum                                       AS ordinal_position,
        NULL::"unknown"                                             AS column_default,
        CASE
            WHEN ext_columns.is_nullable::text = 'true'::text THEN 'YES'::text
            WHEN ext_columns.is_nullable::text = 'false'::text THEN 'NO'::text
            ELSE ''::text
            END::character varying(3)                               AS is_nullable,
        CASE
            WHEN "left"(ext_columns.external_type::text, 7) = 'varchar'::text OR
                 "left"(ext_columns.external_type::text, 17) = 'character varying'::text
                THEN 'character varying'::character varying
            WHEN "left"(ext_columns.external_type::text, 4) = 'char'::text THEN 'character'::character varying
            WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text THEN 'numeric'::character varying
            WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text THEN 'numeric'::character varying
            WHEN ext_columns.external_type::text = 'float'::text THEN 'real'::character varying
            WHEN ext_columns.external_type::text = 'double'::text THEN 'double precision'::character varying
            WHEN ext_columns.external_type::text = 'int'::text OR ext_columns.external_type::text = 'int4'::text
                THEN 'integer'::character varying
            WHEN ext_columns.external_type::text = 'int2'::text THEN 'smallint'::character varying
            ELSE ext_columns.external_type
            END::character varying(128)                             AS data_type,
        CASE
            WHEN ext_columns.external_type::text = 'varchar'::text OR
                 ext_columns.external_type::text = 'character varying'::text THEN -1
            WHEN "left"(ext_columns.external_type::text, 7) = 'varchar'::text OR
                 "left"(ext_columns.external_type::text, 17) = 'character varying'::text
                THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
            WHEN ext_columns.external_type::text = 'char'::text THEN -1
            WHEN "left"(ext_columns.external_type::text, 4) = 'char'::text
                THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 4)::integer
            WHEN ext_columns.external_type::text = 'string'::text THEN 16383
            ELSE NULL::integer
            END                                                     AS character_maximum_length,
        CASE
            WHEN ext_columns.external_type::text = 'numeric'::text OR ext_columns.external_type::text = 'decimal'::text
                THEN NULL::integer
            WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text
                THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
            WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text
                THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
            WHEN ext_columns.external_type::text = 'int2'::text THEN 16
            WHEN ext_columns.external_type::text = 'int'::text OR ext_columns.external_type::text = 'int4'::text OR
                 ext_columns.external_type::text = 'integer'::text THEN 32
            WHEN ext_columns.external_type::text = 'bigint'::text THEN 64
            WHEN ext_columns.external_type::text = 'float'::text THEN 24
            WHEN ext_columns.external_type::text = 'double'::text THEN 53
            ELSE NULL::integer
            END                                                     AS numeric_precision,
        CASE
            WHEN ext_columns.external_type::text = 'decimal'::text OR ext_columns.external_type::text = 'numeric'::text
                THEN NULL::text
            WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text THEN regexp_substr(
                    ext_columns.external_type::text, '[0-9]+'::text,
                    regexp_instr(ext_columns.external_type::text, ','::text, 7))
            WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text THEN regexp_substr(
                    ext_columns.external_type::text, '[0-9]+'::text,
                    regexp_instr(ext_columns.external_type::text, ','::text, 7))
            WHEN ext_columns.external_type::text = 'int2'::text OR ext_columns.external_type::text = 'smallint'::text OR
                 ext_columns.external_type::text = 'int4'::text OR ext_columns.external_type::text = 'int'::text OR
                 ext_columns.external_type::text = 'integer'::text OR ext_columns.external_type::text = 'int8'::text OR
                 ext_columns.external_type::text = 'bigint'::text THEN '0'::text
            ELSE NULL::text
            END::integer                                            AS numeric_scale,
        NULL::"unknown"                                             AS remarks
 FROM pg_get_external_columns() ext_columns(esoid integer, schemaname character varying, tablename character varying,
                                            columnname character varying, external_type character varying,
                                            columnnum integer, part_key integer, is_nullable character varying))
UNION ALL
SELECT btrim(ext_columns.databasename::text)::character varying(128) AS database_name,
       btrim(ext_columns.schemaname::text)::character varying(128)   AS schema_name,
       btrim(ext_columns.tablename::text)::character varying(128)    AS table_name,
       btrim(ext_columns.columnname::text)::character varying(128)   AS column_name,
       ext_columns.columnnum                                         AS ordinal_position,
       NULL::"unknown"                                               AS column_default,
       CASE
           WHEN ext_columns.is_nullable::text = 'true'::text THEN 'YES'::text
           WHEN ext_columns.is_nullable::text = 'false'::text THEN 'NO'::text
           ELSE ''::text
           END::character varying(3)                                 AS is_nullable,
       CASE
           WHEN "left"(ext_columns.external_type::text, 7) = 'varchar'::text OR
                "left"(ext_columns.external_type::text, 17) = 'character varying'::text
               THEN 'character varying'::character varying
           WHEN "left"(ext_columns.external_type::text, 4) = 'char'::text THEN 'character'::character varying
           WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text THEN 'numeric'::character varying
           WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text THEN 'numeric'::character varying
           WHEN ext_columns.external_type::text = 'float'::text THEN 'real'::character varying
           WHEN ext_columns.external_type::text = 'double'::text THEN 'double precision'::character varying
           WHEN ext_columns.external_type::text = 'int'::text OR ext_columns.external_type::text = 'int4'::text
               THEN 'integer'::character varying
           WHEN ext_columns.external_type::text = 'int2'::text THEN 'smallint'::character varying
           ELSE ext_columns.external_type
           END::character varying(128)                               AS data_type,
       CASE
           WHEN ext_columns.external_type::text = 'varchar'::text OR
                ext_columns.external_type::text = 'character varying'::text THEN -1
           WHEN "left"(ext_columns.external_type::text, 7) = 'varchar'::text OR
                "left"(ext_columns.external_type::text, 17) = 'character varying'::text
               THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
           WHEN ext_columns.external_type::text = 'char'::text THEN -1
           WHEN "left"(ext_columns.external_type::text, 4) = 'char'::text
               THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 4)::integer
           WHEN ext_columns.external_type::text = 'string'::text THEN 16383
           ELSE NULL::integer
           END                                                       AS character_maximum_length,
       CASE
           WHEN ext_columns.external_type::text = 'numeric'::text OR ext_columns.external_type::text = 'decimal'::text
               THEN NULL::integer
           WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text
               THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
           WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text
               THEN regexp_substr(ext_columns.external_type::text, '[0-9]+'::text, 7)::integer
           WHEN ext_columns.external_type::text = 'int2'::text THEN 16
           WHEN ext_columns.external_type::text = 'int'::text OR ext_columns.external_type::text = 'int4'::text OR
                ext_columns.external_type::text = 'integer'::text THEN 32
           WHEN ext_columns.external_type::text = 'bigint'::text THEN 64
           WHEN ext_columns.external_type::text = 'float'::text THEN 24
           WHEN ext_columns.external_type::text = 'double'::text THEN 53
           ELSE NULL::integer
           END                                                       AS numeric_precision,
       CASE
           WHEN ext_columns.external_type::text = 'decimal'::text OR ext_columns.external_type::text = 'numeric'::text
               THEN NULL::text
           WHEN "left"(ext_columns.external_type::text, 7) = 'decimal'::text THEN regexp_substr(
                   ext_columns.external_type::text, '[0-9]+'::text,
                   regexp_instr(ext_columns.external_type::text, ','::text, 7))
           WHEN "left"(ext_columns.external_type::text, 7) = 'numeric'::text THEN regexp_substr(
                   ext_columns.external_type::text, '[0-9]+'::text,
                   regexp_instr(ext_columns.external_type::text, ','::text, 7))
           WHEN ext_columns.external_type::text = 'int2'::text OR ext_columns.external_type::text = 'smallint'::text OR
                ext_columns.external_type::text = 'int4'::text OR ext_columns.external_type::text = 'int'::text OR
                ext_columns.external_type::text = 'integer'::text OR ext_columns.external_type::text = 'int8'::text OR
                ext_columns.external_type::text = 'bigint'::text THEN '0'::text
           ELSE NULL::text
           END::integer                                              AS numeric_scale,
       NULL::"unknown"                                               AS remarks
FROM pg_get_all_external_columns() ext_columns(databasename character varying, schemaname character varying,
                                               tablename character varying, esoid integer, columnname character varying,
                                               external_type character varying, columnnum integer, part_key integer,
                                               is_nullable character varying);

alter table svv_all_columns
    owner to rdsdb;

grant select on svv_all_columns to public;

