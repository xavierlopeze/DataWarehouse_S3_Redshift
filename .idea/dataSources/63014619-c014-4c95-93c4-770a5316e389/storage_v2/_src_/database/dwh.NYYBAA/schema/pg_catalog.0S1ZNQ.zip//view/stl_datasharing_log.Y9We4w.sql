create view stl_datasharing_log (userid, xid, pid, query, dskind, recordtime, message, on_leader, initial_query_time) as
SELECT stll_datasharing_log.userid,
       stll_datasharing_log.xid,
       stll_datasharing_log.pid,
       stll_datasharing_log.query,
       stll_datasharing_log.dskind,
       stll_datasharing_log.recordtime,
       stll_datasharing_log.message,
       stll_datasharing_log.on_leader,
       stll_datasharing_log.initial_query_time
FROM stll_datasharing_log;

alter table stl_datasharing_log
    owner to rdsdb;

