create view stl_auto_dispatcher_wlm_occupancy
            (eventtime, wlm_occupancy_percent, autovacuum_pid, autoanalyze_pid, autoalter_pid) as
SELECT stll_auto_dispatcher_wlm_occupancy.eventtime,
       stll_auto_dispatcher_wlm_occupancy.wlm_occupancy_percent,
       stll_auto_dispatcher_wlm_occupancy.autovacuum_pid,
       stll_auto_dispatcher_wlm_occupancy.autoanalyze_pid,
       stll_auto_dispatcher_wlm_occupancy.autoalter_pid
FROM stll_auto_dispatcher_wlm_occupancy;

alter table stl_auto_dispatcher_wlm_occupancy
    owner to rdsdb;

