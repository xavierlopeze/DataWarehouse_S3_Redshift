create view stl_block_priority_based_rereplication(logtime, seqnum, slice, col, tbl, blocknum, backed_up, sb_pos, state) as
SELECT stll_block_priority_based_rereplication.logtime,
       stll_block_priority_based_rereplication.seqnum,
       stll_block_priority_based_rereplication.slice,
       stll_block_priority_based_rereplication.col,
       stll_block_priority_based_rereplication.tbl,
       stll_block_priority_based_rereplication.blocknum,
       stll_block_priority_based_rereplication.backed_up,
       stll_block_priority_based_rereplication.sb_pos,
       stll_block_priority_based_rereplication.state
FROM stll_block_priority_based_rereplication;

alter table stl_block_priority_based_rereplication
    owner to rdsdb;

