create view stl_delete (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl) as
SELECT stll_delete.userid,
       stll_delete.query,
       stll_delete.slice,
       stll_delete.segment,
       stll_delete.step,
       stll_delete.starttime,
       stll_delete.endtime,
       stll_delete.tasknum,
       stll_delete."rows",
       stll_delete.tbl
FROM stll_delete;

alter table stl_delete
    owner to rdsdb;

grant select on stl_delete to public;

