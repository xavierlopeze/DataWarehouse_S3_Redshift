create view svl_datashare_change_log
            (userid, username, pid, xid, share_id, share_name, source_database_id, source_database_name,
             consumer_database_id, consumer_database_name, recordtime, action, status, share_object_type,
             share_object_id, share_object_name, target_user_type, target_userid, target_username, consumer_account,
             consumer_namespace, producer_account, producer_namespace, attribute_name, attribute_value, message)
as
SELECT stl_datashare_changes_producer.userid,
       btrim(stl_datashare_changes_producer.username::text)::character varying(128)         AS username,
       stl_datashare_changes_producer.pid,
       stl_datashare_changes_producer.xid,
       stl_datashare_changes_producer.shareid                                               AS share_id,
       btrim(stl_datashare_changes_producer.sharename::text)::character varying(128)        AS share_name,
       stl_datashare_changes_producer.dbid                                                  AS source_database_id,
       btrim(stl_datashare_changes_producer.dbname::text)::character varying(128)           AS source_database_name,
       NULL::"unknown"                                                                      AS consumer_database_id,
       NULL::"unknown"                                                                      AS consumer_database_name,
       stl_datashare_changes_producer.actiontime                                            AS recordtime,
       CASE
           WHEN stl_datashare_changes_producer."action" = 0 THEN 'CREATE DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 1 THEN 'DROP DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 2 THEN 'GRANT ALTER ON DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 3 THEN 'GRANT SHARE ON DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 4 THEN 'REVOKE ALTER FROM DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 5 THEN 'REVOKE SHARE FROM DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 6 THEN 'ALTER DATASHARE ADD'::text
           WHEN stl_datashare_changes_producer."action" = 7 THEN 'ALTER DATASHARE REMOVE'::text
           WHEN stl_datashare_changes_producer."action" = 8 THEN 'ALTER DATASHARE SET'::text
           WHEN stl_datashare_changes_producer."action" = 9 THEN 'ALTER DATASHARE OWNER'::text
           WHEN stl_datashare_changes_producer."action" = 10 THEN 'GRANT USAGE ON DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 11 THEN 'REVOKE USAGE FROM DATASHARE'::text
           WHEN stl_datashare_changes_producer."action" = 12 THEN 'AUTO ADD TABLE'::text
           ELSE NULL::text
           END::character varying(128)                                                      AS "action",
       stl_datashare_changes_producer.status,
       CASE
           WHEN stl_datashare_changes_producer.datashareobjtype = 0 THEN 'SCHEMA'::text
           WHEN stl_datashare_changes_producer.datashareobjtype = 1 THEN 'TABLE'::text
           WHEN stl_datashare_changes_producer.datashareobjtype = 2 THEN 'FUNCTION'::text
           WHEN stl_datashare_changes_producer.datashareobjtype = 3 THEN 'VIEW'::text
           WHEN stl_datashare_changes_producer.datashareobjtype = 4 THEN 'LATE BINDING VIEW'::text
           WHEN stl_datashare_changes_producer.datashareobjtype = 5 THEN 'MATERIALIZED VIEW'::text
           ELSE NULL::text
           END::character varying(64)                                                       AS share_object_type,
       CASE
           WHEN stl_datashare_changes_producer.datashareobjtype >= 0 THEN stl_datashare_changes_producer.datashareobjid
           ELSE NULL::integer
           END                                                                              AS share_object_id,
       CASE
           WHEN stl_datashare_changes_producer.datashareobjtype >= 0
               THEN btrim(stl_datashare_changes_producer.datashareobjname::text)
           ELSE NULL::text
           END::character varying(128)                                                      AS share_object_name,
       CASE
           WHEN stl_datashare_changes_producer.targetroletype = 0 THEN 'USER'::text
           WHEN stl_datashare_changes_producer.targetroletype = 1 THEN 'GROUP'::text
           ELSE NULL::text
           END::character varying(16)                                                       AS target_user_type,
       CASE
           WHEN stl_datashare_changes_producer.targetroletype >= 0 THEN stl_datashare_changes_producer.targetroleid
           ELSE NULL::integer
           END                                                                              AS target_userid,
       CASE
           WHEN stl_datashare_changes_producer.targetroletype >= 0
               THEN btrim(stl_datashare_changes_producer.targetrolename::text)
           ELSE NULL::text
           END::character varying(128)                                                      AS target_username,
       btrim(stl_datashare_changes_producer.consumeraccount::text)::character varying(16)   AS consumer_account,
       btrim(stl_datashare_changes_producer.consumernamespace::text)::character varying(64) AS consumer_namespace,
       NULL::"unknown"                                                                      AS producer_account,
       NULL::"unknown"                                                                      AS producer_namespace,
       CASE
           WHEN stl_datashare_changes_producer.shareproperty = 'public accessible'::bpchar
               THEN 'DATASHARE_PUBLICACCESSIBLE'::text
           WHEN stl_datashare_changes_producer.shareproperty = 'datashare owner'::bpchar THEN 'DATASHARE_OWNER'::text
           WHEN stl_datashare_changes_producer.shareproperty = 'include new tables'::bpchar THEN 'INCLUDE_NEW'::text
           ELSE NULL::text
           END::character varying(64)                                                       AS attribute_name,
       btrim(stl_datashare_changes_producer.sharepropvalue::text)::character varying(128)   AS attribute_value,
       btrim(stl_datashare_changes_producer.message::text)::character varying(512)          AS message
FROM stl_datashare_changes_producer
UNION ALL
SELECT stl_datashare_changes_consumer.userid,
       btrim(stl_datashare_changes_consumer.username::text)::character varying(128)         AS username,
       stl_datashare_changes_consumer.pid,
       stl_datashare_changes_consumer.xid,
       NULL::"unknown"                                                                      AS share_id,
       btrim(stl_datashare_changes_consumer.sharename::text)::character varying(128)        AS share_name,
       NULL::"unknown"                                                                      AS source_database_id,
       NULL::"unknown"                                                                      AS source_database_name,
       stl_datashare_changes_consumer.sharedbid                                             AS consumer_database_id,
       btrim(stl_datashare_changes_consumer.sharedbname::text)::character varying(128)      AS consumer_database_name,
       stl_datashare_changes_consumer.actiontime                                            AS recordtime,
       CASE
           WHEN stl_datashare_changes_consumer."action" = 1 THEN 'CREATE DATABASE FROM DATASHARE'::text
           WHEN stl_datashare_changes_consumer."action" = 2 THEN 'GRANT USAGE ON DATABASE'::text
           WHEN stl_datashare_changes_consumer."action" = 3 THEN 'REVOKE USAGE FROM DATABASE'::text
           WHEN stl_datashare_changes_consumer."action" = 4 THEN 'ALTER DATABASE'::text
           WHEN stl_datashare_changes_consumer."action" = 5 THEN 'DROP DATABASE'::text
           ELSE NULL::text
           END::character varying(128)                                                      AS "action",
       stl_datashare_changes_consumer.status,
       NULL::"unknown"                                                                      AS share_object_type,
       NULL::"unknown"                                                                      AS share_object_id,
       NULL::"unknown"                                                                      AS share_object_name,
       CASE
           WHEN stl_datashare_changes_consumer.targettype = 1 THEN 'USER'::text
           WHEN stl_datashare_changes_consumer.targettype = 2 THEN 'GROUP'::text
           ELSE NULL::text
           END::character varying(16)                                                       AS target_user_type,
       CASE
           WHEN stl_datashare_changes_consumer.targettype = 1 OR stl_datashare_changes_consumer.targettype = 2
               THEN stl_datashare_changes_consumer.targetid
           ELSE NULL::integer
           END                                                                              AS target_userid,
       CASE
           WHEN stl_datashare_changes_consumer.targettype = 1 OR stl_datashare_changes_consumer.targettype = 2
               THEN btrim(stl_datashare_changes_consumer.targetname::text)
           ELSE NULL::text
           END::character varying(128)                                                      AS target_username,
       NULL::"unknown"                                                                      AS consumer_account,
       NULL::"unknown"                                                                      AS consumer_namespace,
       btrim(stl_datashare_changes_consumer.produceraccount::text)::character varying(16)   AS producer_account,
       btrim(stl_datashare_changes_consumer.producernamespace::text)::character varying(64) AS producer_namespace,
       CASE
           WHEN stl_datashare_changes_consumer.targettype = 3 AND stl_datashare_changes_consumer."action" = 4
               THEN 'DATABASE_NAME'::text
           WHEN stl_datashare_changes_consumer.targettype = 1 AND stl_datashare_changes_consumer."action" = 4
               THEN 'DATABASE_OWNER'::text
           ELSE NULL::text
           END::character varying(64)                                                       AS attribute_name,
       CASE
           WHEN stl_datashare_changes_consumer.targettype = 3 AND stl_datashare_changes_consumer."action" = 4
               THEN btrim(stl_datashare_changes_consumer.targetname::text)
           WHEN stl_datashare_changes_consumer.targettype = 1 AND stl_datashare_changes_consumer."action" = 4
               THEN btrim(stl_datashare_changes_consumer.targetid::character varying(128)::text)
           ELSE NULL::text
           END::character varying(128)                                                      AS attribute_value,
       btrim(stl_datashare_changes_consumer.message::text)::character varying(512)          AS message
FROM stl_datashare_changes_consumer;

alter table svl_datashare_change_log
    owner to rdsdb;

grant select on svl_datashare_change_log to public;

