create view stl_scan_range_stats
            (query, segment, step, node, local_data_slice, local_compute_slice, starttime, endtime, num_blocks_to_scan,
             total_blocks, num_scan_ranges, min_scan_range_size, max_scan_range_size, avg_scan_range_size,
             num_blf_ranges, min_blf_range_size, max_blf_range_size, avg_blf_range_size, block_reopen_times)
as
SELECT stll_scan_range_stats.query,
       stll_scan_range_stats.segment,
       stll_scan_range_stats.step,
       stll_scan_range_stats.node,
       stll_scan_range_stats.local_data_slice,
       stll_scan_range_stats.local_compute_slice,
       stll_scan_range_stats.starttime,
       stll_scan_range_stats.endtime,
       stll_scan_range_stats.num_blocks_to_scan,
       stll_scan_range_stats.total_blocks,
       stll_scan_range_stats.num_scan_ranges,
       stll_scan_range_stats.min_scan_range_size,
       stll_scan_range_stats.max_scan_range_size,
       stll_scan_range_stats.avg_scan_range_size,
       stll_scan_range_stats.num_blf_ranges,
       stll_scan_range_stats.min_blf_range_size,
       stll_scan_range_stats.max_blf_range_size,
       stll_scan_range_stats.avg_blf_range_size,
       stll_scan_range_stats.block_reopen_times
FROM stll_scan_range_stats;

alter table stl_scan_range_stats
    owner to rdsdb;

