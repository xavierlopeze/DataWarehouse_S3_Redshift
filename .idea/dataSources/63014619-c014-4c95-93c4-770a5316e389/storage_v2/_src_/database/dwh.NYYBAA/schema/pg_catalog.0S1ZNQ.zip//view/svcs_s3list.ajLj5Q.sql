create view svcs_s3list
            (query, segment, node, eventtime, bucket, prefix, recursive, retrieved_files, max_file_size, avg_file_size,
             generated_splits, avg_split_length, duration)
as
SELECT "map".primary_query                                                                                  AS query,
       stcs.segment,
       stcs.node,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.eventtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval                                                                                 AS eventtime,
       stcs.bucket,
       stcs.prefix,
       stcs."recursive",
       stcs.retrieved_files,
       stcs.max_file_size,
       stcs.avg_file_size,
       stcs.generated_splits,
       stcs.avg_split_length,
       stcs.duration
FROM stcs_s3list stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE stcs.__cluster_type = 'cs'::bpchar
  AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10)
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       stcs.userid = "current_user_id"())
  AND stcs.scan_type = 2
UNION ALL
SELECT svl_s3list.query,
       svl_s3list.segment,
       svl_s3list.node,
       svl_s3list.eventtime,
       svl_s3list.bucket::character varying AS bucket,
       svl_s3list.prefix::character varying AS prefix,
       svl_s3list."recursive",
       svl_s3list.retrieved_files,
       svl_s3list.max_file_size,
       svl_s3list.avg_file_size,
       svl_s3list.generated_splits,
       svl_s3list.avg_split_length,
       svl_s3list.duration
FROM svl_s3list;

alter table svcs_s3list
    owner to rdsdb;

grant select on svcs_s3list to public;

