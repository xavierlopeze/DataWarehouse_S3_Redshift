create view stl_query_mem_leaks (qid, endtime, node, type, pid, pname, size, rounded, allocated, hexa, ascii) as
SELECT stll_query_mem_leaks.qid,
       stll_query_mem_leaks.endtime,
       stll_query_mem_leaks.node,
       stll_query_mem_leaks."type",
       stll_query_mem_leaks.pid,
       stll_query_mem_leaks.pname,
       stll_query_mem_leaks.size,
       stll_query_mem_leaks.rounded,
       stll_query_mem_leaks.allocated,
       stll_query_mem_leaks.hexa,
       stll_query_mem_leaks.ascii
FROM stll_query_mem_leaks;

alter table stl_query_mem_leaks
    owner to rdsdb;

