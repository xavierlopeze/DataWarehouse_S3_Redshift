create view stl_monitoring_logs_internal(recordtime, thread, tid, node, slice, file, linenum, message) as
SELECT stll_monitoring_logs_internal.recordtime,
       stll_monitoring_logs_internal.thread,
       stll_monitoring_logs_internal.tid,
       stll_monitoring_logs_internal.node,
       stll_monitoring_logs_internal.slice,
       stll_monitoring_logs_internal."file",
       stll_monitoring_logs_internal.linenum,
       stll_monitoring_logs_internal.message
FROM stll_monitoring_logs_internal;

alter table stl_monitoring_logs_internal
    owner to rdsdb;

