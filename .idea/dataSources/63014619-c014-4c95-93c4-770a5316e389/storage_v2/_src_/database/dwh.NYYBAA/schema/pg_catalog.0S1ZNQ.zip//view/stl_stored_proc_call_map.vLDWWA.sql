create view stl_stored_proc_call_map(userid, query, from_sp_call) as
SELECT stll_stored_proc_call_map.userid, stll_stored_proc_call_map.query, stll_stored_proc_call_map.from_sp_call
FROM stll_stored_proc_call_map;

alter table stl_stored_proc_call_map
    owner to rdsdb;

