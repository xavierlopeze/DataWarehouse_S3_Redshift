create view stl_comm_diag (now, node, slice, is_source, packet_count, duration_ms, bandwidth, config) as
SELECT stll_comm_diag.now,
       stll_comm_diag.node,
       stll_comm_diag.slice,
       stll_comm_diag.is_source,
       stll_comm_diag.packet_count,
       stll_comm_diag.duration_ms,
       stll_comm_diag.bandwidth,
       stll_comm_diag.config
FROM stll_comm_diag;

alter table stl_comm_diag
    owner to rdsdb;

