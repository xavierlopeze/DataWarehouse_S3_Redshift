create view svl_s3partition
            (query, segment, node, slice, starttime, endtime, duration, total_partitions, qualified_partitions,
             assigned_partitions, assignment)
as
SELECT stl_s3partition_elimination.query,
       stl_s3partition_elimination.segment,
       stl_s3partition_elimination.node,
       stl_s3partition_elimination.slice,
       stl_s3partition_elimination.starttime,
       stl_s3partition_elimination.endtime,
       stl_s3partition_elimination.duration,
       stl_s3partition_elimination.total_partitions,
       stl_s3partition_elimination.qualified_partitions,
       stl_s3partition_elimination.assigned_partitions,
       stl_s3partition_elimination."assignment"
FROM stl_s3partition_elimination;

alter table svl_s3partition
    owner to rdsdb;

grant select on svl_s3partition to public;

