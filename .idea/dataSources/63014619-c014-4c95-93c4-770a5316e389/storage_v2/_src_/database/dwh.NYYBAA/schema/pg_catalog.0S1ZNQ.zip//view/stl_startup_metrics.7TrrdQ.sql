create view stl_startup_metrics(node, pid, starttime, endtime, phase, database) as
SELECT stll_startup_metrics.node,
       stll_startup_metrics.pid,
       stll_startup_metrics.starttime,
       stll_startup_metrics.endtime,
       stll_startup_metrics.phase,
       stll_startup_metrics."database"
FROM stll_startup_metrics;

alter table stl_startup_metrics
    owner to rdsdb;

