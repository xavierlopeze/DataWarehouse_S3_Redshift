create view stl_ml_model_stats
            (recordtime, xid, model_name, inference_type, is_auto, model_type, is_kms, is_s3_gc, param_count, is_vpc,
             full_stmt, algo_meta, exec_meta, model_id)
as
SELECT stll_ml_model_stats.recordtime,
       stll_ml_model_stats.xid,
       stll_ml_model_stats.model_name,
       stll_ml_model_stats.inference_type,
       stll_ml_model_stats.is_auto,
       stll_ml_model_stats."model_type",
       stll_ml_model_stats.is_kms,
       stll_ml_model_stats.is_s3_gc,
       stll_ml_model_stats.param_count,
       stll_ml_model_stats.is_vpc,
       stll_ml_model_stats.full_stmt,
       stll_ml_model_stats.algo_meta,
       stll_ml_model_stats.exec_meta,
       stll_ml_model_stats.model_id
FROM stll_ml_model_stats;

alter table stl_ml_model_stats
    owner to rdsdb;

