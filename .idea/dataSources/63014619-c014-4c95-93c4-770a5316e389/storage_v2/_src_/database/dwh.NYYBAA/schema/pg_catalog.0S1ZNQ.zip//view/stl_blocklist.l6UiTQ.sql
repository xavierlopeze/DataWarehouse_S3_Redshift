create view stl_blocklist
            (logtime, slice, col, tbl, blocknum, num_values, extended_limits, minvalue, maxvalue, sb_pos, pinned,
             on_disk, backed_up, modified, hdr_modified, unsorted, tombstone, preferred_diskno, temporary, newblock,
             num_readers, id, flags)
as
SELECT stll_blocklist.logtime,
       stll_blocklist.slice,
       stll_blocklist.col,
       stll_blocklist.tbl,
       stll_blocklist.blocknum,
       stll_blocklist.num_values,
       stll_blocklist.extended_limits,
       stll_blocklist."minvalue",
       stll_blocklist."maxvalue",
       stll_blocklist.sb_pos,
       stll_blocklist."pinned",
       stll_blocklist.on_disk,
       stll_blocklist.backed_up,
       stll_blocklist.modified,
       stll_blocklist.hdr_modified,
       stll_blocklist.unsorted,
       stll_blocklist.tombstone,
       stll_blocklist.preferred_diskno,
       stll_blocklist."temporary",
       stll_blocklist.newblock,
       stll_blocklist.num_readers,
       stll_blocklist.id,
       stll_blocklist.flags
FROM stll_blocklist;

alter table stl_blocklist
    owner to rdsdb;

