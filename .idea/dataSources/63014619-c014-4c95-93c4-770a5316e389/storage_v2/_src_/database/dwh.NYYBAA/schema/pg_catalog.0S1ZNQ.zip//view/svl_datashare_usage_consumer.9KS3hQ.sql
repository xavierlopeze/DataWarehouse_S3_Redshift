create view svl_datashare_usage_consumer
            (userid, pid, xid, request_id, request_type, transaction_uid, recordtime, status, error) as
SELECT stl_datashare_request_consumer.userid,
       stl_datashare_request_consumer.pid,
       stl_datashare_request_consumer.xid,
       stl_datashare_request_consumer.requestid::character varying(50)       AS request_id,
       CASE
           WHEN stl_datashare_request_consumer.api_call = 5
               THEN 'GET FUNCTION'::character varying::character varying(25)
           ELSE 'GET RELATION'::character varying::character varying(25)
           END                                                               AS request_type,
       stl_datashare_request_consumer.transaction_uid::character varying(50) AS transaction_uid,
       stl_datashare_request_consumer.endtime                                AS recordtime,
       stl_datashare_request_consumer.status,
       stl_datashare_request_consumer.message::character varying(512)        AS error
FROM stl_datashare_request_consumer
WHERE stl_datashare_request_consumer.api_call >= 2
  AND stl_datashare_request_consumer.api_call <= 5
  AND stl_datashare_request_consumer.dbtype > 0;

alter table svl_datashare_usage_consumer
    owner to rdsdb;

grant select on svl_datashare_usage_consumer to public;

