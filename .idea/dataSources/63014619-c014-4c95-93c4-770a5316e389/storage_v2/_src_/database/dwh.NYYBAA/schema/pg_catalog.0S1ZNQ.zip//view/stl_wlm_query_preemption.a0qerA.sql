create view stl_wlm_query_preemption
            (eventtime, service_class_preempting, service_class_name_preempting, query_preempting,
             query_priority_preempting, service_class_preempted, service_class_name_preempted, query_preempted,
             query_priority_preempted)
as
SELECT stll_wlm_query_preemption.eventtime,
       stll_wlm_query_preemption.service_class_preempting,
       stll_wlm_query_preemption.service_class_name_preempting,
       stll_wlm_query_preemption.query_preempting,
       stll_wlm_query_preemption.query_priority_preempting,
       stll_wlm_query_preemption.service_class_preempted,
       stll_wlm_query_preemption.service_class_name_preempted,
       stll_wlm_query_preemption.query_preempted,
       stll_wlm_query_preemption.query_priority_preempted
FROM stll_wlm_query_preemption;

alter table stl_wlm_query_preemption
    owner to rdsdb;

