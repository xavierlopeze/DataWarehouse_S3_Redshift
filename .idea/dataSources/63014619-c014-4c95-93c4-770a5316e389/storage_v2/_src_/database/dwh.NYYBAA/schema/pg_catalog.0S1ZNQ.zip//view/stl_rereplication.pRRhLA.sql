create view stl_rereplication (recordtime, slice, sb_pos, id, flags, new_node, new_diskno, new_address, context) as
SELECT stll_rereplication.recordtime,
       stll_rereplication.slice,
       stll_rereplication.sb_pos,
       stll_rereplication.id,
       stll_rereplication.flags,
       stll_rereplication.new_node,
       stll_rereplication.new_diskno,
       stll_rereplication.new_address,
       stll_rereplication.context
FROM stll_rereplication;

alter table stl_rereplication
    owner to rdsdb;

