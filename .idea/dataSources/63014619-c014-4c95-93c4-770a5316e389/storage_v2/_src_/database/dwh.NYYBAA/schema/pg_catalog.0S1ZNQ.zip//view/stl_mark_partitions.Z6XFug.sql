create view stl_mark_partitions(recordtime, action, node, diskno) as
SELECT stll_mark_partitions.recordtime,
       stll_mark_partitions."action",
       stll_mark_partitions.node,
       stll_mark_partitions.diskno
FROM stll_mark_partitions;

alter table stl_mark_partitions
    owner to rdsdb;

