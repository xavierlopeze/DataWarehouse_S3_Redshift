create view stl_datashare_dsms
            (userid, username, xid, pid, initial_query_time, requestid, shareid, sharename, produceraccount,
             producernamespace, role, apicall, starttime, endtime, status, message)
as
SELECT stll_datashare_dsms.userid,
       stll_datashare_dsms.username,
       stll_datashare_dsms.xid,
       stll_datashare_dsms.pid,
       stll_datashare_dsms.initial_query_time,
       stll_datashare_dsms.requestid,
       stll_datashare_dsms.shareid,
       stll_datashare_dsms.sharename,
       stll_datashare_dsms.produceraccount,
       stll_datashare_dsms.producernamespace,
       stll_datashare_dsms.role,
       stll_datashare_dsms.apicall,
       stll_datashare_dsms.starttime,
       stll_datashare_dsms.endtime,
       stll_datashare_dsms.status,
       stll_datashare_dsms.message
FROM stll_datashare_dsms;

alter table stl_datashare_dsms
    owner to rdsdb;

