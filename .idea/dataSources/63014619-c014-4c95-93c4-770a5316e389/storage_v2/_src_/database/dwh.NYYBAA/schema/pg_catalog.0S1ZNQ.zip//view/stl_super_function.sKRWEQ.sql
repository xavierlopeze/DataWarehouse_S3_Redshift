create view stl_super_function(userid, query, functionid, sqloperation) as
SELECT stll_super_function.userid,
       stll_super_function.query,
       stll_super_function.functionid,
       stll_super_function.sqloperation
FROM stll_super_function;

alter table stl_super_function
    owner to rdsdb;

