create view pg_stat_sys_tables
            (relid, schemaname, relname, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd,
             n_tup_del) as
SELECT pg_stat_all_tables.relid,
       pg_stat_all_tables.schemaname,
       pg_stat_all_tables.relname,
       pg_stat_all_tables.seq_scan,
       pg_stat_all_tables.seq_tup_read,
       pg_stat_all_tables.idx_scan,
       pg_stat_all_tables.idx_tup_fetch,
       pg_stat_all_tables.n_tup_ins,
       pg_stat_all_tables.n_tup_upd,
       pg_stat_all_tables.n_tup_del
FROM pg_stat_all_tables
WHERE pg_stat_all_tables.schemaname = 'pg_catalog'::name
   OR pg_stat_all_tables.schemaname = 'pg_toast'::name
   OR pg_stat_all_tables.schemaname = 'information_schema'::name;

alter table pg_stat_sys_tables
    owner to rdsdb;

grant select on pg_stat_sys_tables to public;

