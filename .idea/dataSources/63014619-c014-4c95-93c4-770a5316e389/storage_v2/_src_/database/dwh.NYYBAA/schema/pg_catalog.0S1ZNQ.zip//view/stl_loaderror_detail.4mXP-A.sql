create view stl_loaderror_detail
            (userid, slice, session, query, filename, line_number, field, colname, value, is_null, type, col_length) as
SELECT stll_loaderror_detail.userid,
       stll_loaderror_detail.slice,
       stll_loaderror_detail."session",
       stll_loaderror_detail.query,
       stll_loaderror_detail.filename,
       stll_loaderror_detail.line_number,
       stll_loaderror_detail.field,
       stll_loaderror_detail.colname,
       stll_loaderror_detail.value,
       stll_loaderror_detail.is_null,
       stll_loaderror_detail."type",
       stll_loaderror_detail.col_length
FROM stll_loaderror_detail;

alter table stl_loaderror_detail
    owner to rdsdb;

grant select on stl_loaderror_detail to public;

