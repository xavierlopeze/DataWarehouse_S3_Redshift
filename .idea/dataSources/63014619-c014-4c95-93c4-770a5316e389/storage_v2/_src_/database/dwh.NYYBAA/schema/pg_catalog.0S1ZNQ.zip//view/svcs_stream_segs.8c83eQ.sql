create view svcs_stream_segs(userid, query, stream, segment) as
SELECT stcs.userid, "map".primary_query AS query, stcs.stream, stcs.segment
FROM stcs_stream_segs stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE stcs.__cluster_type = 'cs'::bpchar
  AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10)
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       stcs.userid = "current_user_id"())
UNION ALL
SELECT stl_stream_segs.userid, stl_stream_segs.query, stl_stream_segs.stream, stl_stream_segs.segment
FROM stl_stream_segs;

alter table svcs_stream_segs
    owner to rdsdb;

grant select on svcs_stream_segs to public;

