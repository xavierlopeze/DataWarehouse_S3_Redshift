create view stl_auto_maintenance(eventtime, eventtext) as
SELECT stll_auto_maintenance.eventtime, stll_auto_maintenance.eventtext
FROM stll_auto_maintenance;

alter table stl_auto_maintenance
    owner to rdsdb;

