create view stl_ghost_buffer_stats
            (node_num, start_time, end_time, ghb_eviction_threshold, ghb_size_before_addition, num_blocks_evicted,
             num_blocks_added)
as
SELECT stll_ghost_buffer_stats.node_num,
       stll_ghost_buffer_stats.start_time,
       stll_ghost_buffer_stats.end_time,
       stll_ghost_buffer_stats.ghb_eviction_threshold,
       stll_ghost_buffer_stats.ghb_size_before_addition,
       stll_ghost_buffer_stats.num_blocks_evicted,
       stll_ghost_buffer_stats.num_blocks_added
FROM stll_ghost_buffer_stats;

alter table stl_ghost_buffer_stats
    owner to rdsdb;

