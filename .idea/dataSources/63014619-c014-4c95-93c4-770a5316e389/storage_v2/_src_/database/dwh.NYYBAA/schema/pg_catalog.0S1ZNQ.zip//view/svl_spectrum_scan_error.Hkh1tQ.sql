create view svl_spectrum_scan_error
            (userid, query, location, rowid, colname, original_value, modified_value, trigger, action, action_value,
             error_code) as
SELECT stl_spectrum_scan_error.userid,
       stl_spectrum_scan_error.query,
       stl_spectrum_scan_error."location",
       stl_spectrum_scan_error."rowid",
       stl_spectrum_scan_error.colname,
       stl_spectrum_scan_error.original_value,
       stl_spectrum_scan_error.modified_value,
       CASE
           WHEN stl_spectrum_scan_error."trigger" = 0 THEN 'UNSPECIFIED'::text
           WHEN stl_spectrum_scan_error."trigger" = 1 THEN 'INVALID_CHARS'::text
           WHEN stl_spectrum_scan_error."trigger" = 2 THEN 'SURPLUS_CHARS'::text
           WHEN stl_spectrum_scan_error."trigger" = 3 THEN 'NUMERIC_OVERFLOW'::text
           WHEN stl_spectrum_scan_error."trigger" = 4 THEN 'TYPE_COERCION_FAILURE'::text
           ELSE NULL::text
           END AS "trigger",
       CASE
           WHEN stl_spectrum_scan_error."action" = 0 THEN 'NONE'::text
           WHEN stl_spectrum_scan_error."action" = 1 THEN 'FAIL'::text
           WHEN stl_spectrum_scan_error."action" = 2 THEN 'DROP_ROW'::text
           WHEN stl_spectrum_scan_error."action" = 3 THEN 'SET_TO_NULL'::text
           WHEN stl_spectrum_scan_error."action" = 4 THEN 'REPLACE'::text
           WHEN stl_spectrum_scan_error."action" = 5 THEN 'TRUNCATE'::text
           WHEN stl_spectrum_scan_error."action" = 6 THEN 'OVERFLOW_VALUE'::text
           ELSE NULL::text
           END AS "action",
       stl_spectrum_scan_error.action_value,
       stl_spectrum_scan_error.error_code
FROM stl_spectrum_scan_error;

alter table svl_spectrum_scan_error
    owner to rdsdb;

grant select on svl_spectrum_scan_error to public;

