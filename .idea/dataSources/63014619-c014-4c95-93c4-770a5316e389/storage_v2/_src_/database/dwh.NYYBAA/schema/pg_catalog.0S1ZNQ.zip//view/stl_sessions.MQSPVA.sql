create view stl_sessions (userid, starttime, endtime, process, user_name, db_name, timeout_sec, timed_out) as
SELECT stll_sessions.userid,
       stll_sessions.starttime,
       stll_sessions.endtime,
       stll_sessions.process,
       stll_sessions.user_name,
       stll_sessions.db_name,
       stll_sessions.timeout_sec,
       stll_sessions.timed_out
FROM stll_sessions;

alter table stl_sessions
    owner to rdsdb;

grant select on stl_sessions to public;

