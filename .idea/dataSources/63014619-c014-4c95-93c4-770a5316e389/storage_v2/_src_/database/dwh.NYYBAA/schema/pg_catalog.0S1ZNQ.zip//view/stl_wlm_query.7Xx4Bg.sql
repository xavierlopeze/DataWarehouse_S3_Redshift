create view stl_wlm_query
            (userid, xid, task, query, service_class, slot_count, service_class_start_time, queue_start_time,
             queue_end_time, total_queue_time, exec_start_time, exec_end_time, total_exec_time, service_class_end_time,
             final_state, est_peak_mem, query_priority, service_class_name)
as
SELECT stll_wlm_query.userid,
       stll_wlm_query.xid,
       stll_wlm_query.task,
       stll_wlm_query.query,
       stll_wlm_query.service_class,
       stll_wlm_query.slot_count,
       stll_wlm_query.service_class_start_time,
       stll_wlm_query.queue_start_time,
       stll_wlm_query.queue_end_time,
       stll_wlm_query.total_queue_time,
       stll_wlm_query.exec_start_time,
       stll_wlm_query.exec_end_time,
       stll_wlm_query.total_exec_time,
       stll_wlm_query.service_class_end_time,
       stll_wlm_query.final_state,
       stll_wlm_query.est_peak_mem,
       stll_wlm_query.query_priority,
       stll_wlm_query.service_class_name
FROM stll_wlm_query;

alter table stl_wlm_query
    owner to rdsdb;

grant select on stl_wlm_query to public;

