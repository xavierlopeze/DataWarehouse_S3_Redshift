create view stl_project (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, checksum) as
SELECT stll_project.userid,
       stll_project.query,
       stll_project.slice,
       stll_project.segment,
       stll_project.step,
       stll_project.starttime,
       stll_project.endtime,
       stll_project.tasknum,
       stll_project."rows",
       stll_project.checksum
FROM stll_project;

alter table stl_project
    owner to rdsdb;

grant select on stl_project to public;

