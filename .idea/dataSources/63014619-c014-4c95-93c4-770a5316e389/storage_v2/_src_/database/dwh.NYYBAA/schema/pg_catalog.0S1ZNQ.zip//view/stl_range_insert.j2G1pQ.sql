create view stl_range_insert (userid, query, slice, segment, step, starttime, endtime, tasknum, rows) as
SELECT stll_range_insert.userid,
       stll_range_insert.query,
       stll_range_insert.slice,
       stll_range_insert.segment,
       stll_range_insert.step,
       stll_range_insert.starttime,
       stll_range_insert.endtime,
       stll_range_insert.tasknum,
       stll_range_insert."rows"
FROM stll_range_insert;

alter table stl_range_insert
    owner to rdsdb;

