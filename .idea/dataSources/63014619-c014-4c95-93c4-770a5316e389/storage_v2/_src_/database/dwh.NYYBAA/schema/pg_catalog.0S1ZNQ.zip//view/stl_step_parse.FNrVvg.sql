create view stl_step_parse(slice, query, segnum, linenum, field, data, filename, recordtime) as
SELECT stll_step_parse.slice,
       stll_step_parse.query,
       stll_step_parse.segnum,
       stll_step_parse.linenum,
       stll_step_parse.field,
       stll_step_parse."data",
       stll_step_parse.filename,
       stll_step_parse.recordtime
FROM stll_step_parse;

alter table stl_step_parse
    owner to rdsdb;

