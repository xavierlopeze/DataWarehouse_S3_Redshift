create view stl_sorted_checker_leader
            (starttime, endtime, xid, qid, dbname, schema, tablename, relid, colid, datatype, compression,
             sorted_corrupt, num_incorrect_sorted_rows, fixer, version)
as
SELECT stll_sorted_checker_leader.starttime,
       stll_sorted_checker_leader.endtime,
       stll_sorted_checker_leader.xid,
       stll_sorted_checker_leader.qid,
       stll_sorted_checker_leader.dbname,
       stll_sorted_checker_leader."schema",
       stll_sorted_checker_leader.tablename,
       stll_sorted_checker_leader.relid,
       stll_sorted_checker_leader.colid,
       stll_sorted_checker_leader.datatype,
       stll_sorted_checker_leader."compression",
       stll_sorted_checker_leader.sorted_corrupt,
       stll_sorted_checker_leader.num_incorrect_sorted_rows,
       stll_sorted_checker_leader.fixer,
       stll_sorted_checker_leader.version
FROM stll_sorted_checker_leader;

alter table stl_sorted_checker_leader
    owner to rdsdb;

