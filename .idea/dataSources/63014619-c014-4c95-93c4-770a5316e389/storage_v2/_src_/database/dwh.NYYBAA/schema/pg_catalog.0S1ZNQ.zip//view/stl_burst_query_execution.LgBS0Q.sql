create view stl_burst_query_execution
            (action, userid, pid, xid, query, backup_id, cluster_backup_version, starttime, endtime, cluster_arn,
             max_vis_xid, query_sb_version, num_tuples, fetch_complete, error, connection_guid, xen_error_code)
as
SELECT stll_burst_query_execution."action",
       stll_burst_query_execution.userid,
       stll_burst_query_execution.pid,
       stll_burst_query_execution.xid,
       stll_burst_query_execution.query,
       stll_burst_query_execution.backup_id,
       stll_burst_query_execution.cluster_backup_version,
       stll_burst_query_execution.starttime,
       stll_burst_query_execution.endtime,
       stll_burst_query_execution.cluster_arn,
       stll_burst_query_execution.max_vis_xid,
       stll_burst_query_execution.query_sb_version,
       stll_burst_query_execution.num_tuples,
       stll_burst_query_execution.fetch_complete,
       stll_burst_query_execution.error,
       stll_burst_query_execution.connection_guid,
       stll_burst_query_execution.xen_error_code
FROM stll_burst_query_execution;

alter table stl_burst_query_execution
    owner to rdsdb;

