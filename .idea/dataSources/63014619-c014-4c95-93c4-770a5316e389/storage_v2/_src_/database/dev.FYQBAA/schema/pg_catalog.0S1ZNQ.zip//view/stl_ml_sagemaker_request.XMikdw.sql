create view stl_ml_sagemaker_request(xid, pid, recordtime, node, request_type, request_payload, success) as
SELECT stll_ml_sagemaker_request.xid,
       stll_ml_sagemaker_request.pid,
       stll_ml_sagemaker_request.recordtime,
       stll_ml_sagemaker_request.node,
       stll_ml_sagemaker_request.request_type,
       stll_ml_sagemaker_request.request_payload,
       stll_ml_sagemaker_request.success
FROM stll_ml_sagemaker_request;

alter table stl_ml_sagemaker_request
    owner to rdsdb;

