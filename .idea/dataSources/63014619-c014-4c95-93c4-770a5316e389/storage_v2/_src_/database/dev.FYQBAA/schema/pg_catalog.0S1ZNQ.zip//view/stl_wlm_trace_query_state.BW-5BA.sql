create view stl_wlm_trace_query_state (userid, xid, task, query, service_class, recordtime, old_state, new_state) as
SELECT stll_wlm_trace_query_state.userid,
       stll_wlm_trace_query_state.xid,
       stll_wlm_trace_query_state.task,
       stll_wlm_trace_query_state.query,
       stll_wlm_trace_query_state.service_class,
       stll_wlm_trace_query_state.recordtime,
       stll_wlm_trace_query_state.old_state,
       stll_wlm_trace_query_state.new_state
FROM stll_wlm_trace_query_state;

alter table stl_wlm_trace_query_state
    owner to rdsdb;

