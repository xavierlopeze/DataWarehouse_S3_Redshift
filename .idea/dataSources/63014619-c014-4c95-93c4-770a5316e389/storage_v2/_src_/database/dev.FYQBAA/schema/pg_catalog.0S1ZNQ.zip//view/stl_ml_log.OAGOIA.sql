create view stl_ml_log(xid, pid, recordtime, node, model_name, model_id, operation, message) as
SELECT stll_ml_log.xid,
       stll_ml_log.pid,
       stll_ml_log.recordtime,
       stll_ml_log.node,
       stll_ml_log.model_name,
       stll_ml_log.model_id,
       stll_ml_log.operation,
       stll_ml_log.message
FROM stll_ml_log;

alter table stl_ml_log
    owner to rdsdb;

