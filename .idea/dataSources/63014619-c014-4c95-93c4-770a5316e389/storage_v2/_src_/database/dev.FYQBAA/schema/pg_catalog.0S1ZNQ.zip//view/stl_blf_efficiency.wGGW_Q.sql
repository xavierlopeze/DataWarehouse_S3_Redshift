create view stl_blf_efficiency
            (query, segment, local_data_slice, scanned_blocks, total_blocks, local_compute_slice, node) as
SELECT stll_blf_efficiency.query,
       stll_blf_efficiency.segment,
       stll_blf_efficiency.local_data_slice,
       stll_blf_efficiency.scanned_blocks,
       stll_blf_efficiency.total_blocks,
       stll_blf_efficiency.local_compute_slice,
       stll_blf_efficiency.node
FROM stll_blf_efficiency;

alter table stl_blf_efficiency
    owner to rdsdb;

