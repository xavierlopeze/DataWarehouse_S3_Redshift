create view stl_spatial_query(userid, query, starttime, endtime, query_cmd_type, aborted) as
SELECT stll_spatial_query.userid,
       stll_spatial_query.query,
       stll_spatial_query.starttime,
       stll_spatial_query.endtime,
       stll_spatial_query.query_cmd_type,
       stll_spatial_query.aborted
FROM stll_spatial_query;

alter table stl_spatial_query
    owner to rdsdb;

