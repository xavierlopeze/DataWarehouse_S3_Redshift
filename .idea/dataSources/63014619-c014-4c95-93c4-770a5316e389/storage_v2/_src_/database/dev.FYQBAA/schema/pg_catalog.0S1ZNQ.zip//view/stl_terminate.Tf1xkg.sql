create view stl_terminate(actualpid, pid, eventtime, userid, signal) as
SELECT stll_terminate.actualpid,
       stll_terminate.pid,
       stll_terminate.eventtime,
       stll_terminate.userid,
       stll_terminate.signal
FROM stll_terminate;

alter table stl_terminate
    owner to rdsdb;

