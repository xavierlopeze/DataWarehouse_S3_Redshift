create view stl_hllsketch_function(userid, query, functionid, sqloperation) as
SELECT stll_hllsketch_function.userid,
       stll_hllsketch_function.query,
       stll_hllsketch_function.functionid,
       stll_hllsketch_function.sqloperation
FROM stll_hllsketch_function;

alter table stl_hllsketch_function
    owner to rdsdb;

