create view stl_result_cache_stats
            (recordtime, num_entries, num_valid_entries, lookup_count, hit_count, populate_count, evict_count,
             invalidate_count, mem_usage, match_count, telemetry)
as
SELECT stll_result_cache_stats.recordtime,
       stll_result_cache_stats.num_entries,
       stll_result_cache_stats.num_valid_entries,
       stll_result_cache_stats.lookup_count,
       stll_result_cache_stats.hit_count,
       stll_result_cache_stats.populate_count,
       stll_result_cache_stats.evict_count,
       stll_result_cache_stats.invalidate_count,
       stll_result_cache_stats.mem_usage,
       stll_result_cache_stats.match_count,
       stll_result_cache_stats.telemetry
FROM stll_result_cache_stats;

alter table stl_result_cache_stats
    owner to rdsdb;

