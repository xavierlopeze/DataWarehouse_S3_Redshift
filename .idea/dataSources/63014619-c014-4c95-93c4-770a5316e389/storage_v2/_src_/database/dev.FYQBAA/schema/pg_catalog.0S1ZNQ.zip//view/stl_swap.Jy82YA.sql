create view stl_swap(recordtime, event, address, content, type, size) as
SELECT stll_swap.recordtime,
       stll_swap.event,
       stll_swap.address,
       stll_swap.content,
       stll_swap."type",
       stll_swap.size
FROM stll_swap;

alter table stl_swap
    owner to rdsdb;

