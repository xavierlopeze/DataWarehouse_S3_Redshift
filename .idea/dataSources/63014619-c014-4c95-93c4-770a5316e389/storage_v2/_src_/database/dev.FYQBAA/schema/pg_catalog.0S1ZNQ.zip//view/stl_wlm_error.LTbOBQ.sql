create view stl_wlm_error(userid, recordtime, pid, error_string) as
SELECT stll_wlm_error.userid, stll_wlm_error.recordtime, stll_wlm_error.pid, stll_wlm_error.error_string
FROM stll_wlm_error;

alter table stl_wlm_error
    owner to rdsdb;

grant select on stl_wlm_error to public;

