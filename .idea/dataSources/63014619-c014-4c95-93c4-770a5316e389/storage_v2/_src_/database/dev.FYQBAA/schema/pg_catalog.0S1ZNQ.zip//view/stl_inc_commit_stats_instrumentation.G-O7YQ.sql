create view stl_inc_commit_stats_instrumentation
            (mismatch_type, recordtime, pos, persistency, a_flags, tombstone_id, has_local_rep, num_reps, table_id,
             json) as
SELECT stll_inc_commit_stats_instrumentation.mismatch_type,
       stll_inc_commit_stats_instrumentation.recordtime,
       stll_inc_commit_stats_instrumentation.pos,
       stll_inc_commit_stats_instrumentation.persistency,
       stll_inc_commit_stats_instrumentation.a_flags,
       stll_inc_commit_stats_instrumentation.tombstone_id,
       stll_inc_commit_stats_instrumentation.has_local_rep,
       stll_inc_commit_stats_instrumentation.num_reps,
       stll_inc_commit_stats_instrumentation.table_id,
       stll_inc_commit_stats_instrumentation."json"
FROM stll_inc_commit_stats_instrumentation;

alter table stl_inc_commit_stats_instrumentation
    owner to rdsdb;

