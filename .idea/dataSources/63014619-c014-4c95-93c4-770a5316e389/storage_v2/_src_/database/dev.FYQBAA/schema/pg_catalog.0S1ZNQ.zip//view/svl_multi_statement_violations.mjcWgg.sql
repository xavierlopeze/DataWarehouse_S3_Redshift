create view svl_multi_statement_violations
            (userid, database, cmdname, xid, pid, label, starttime, endtime, sequence, type, text) as
SELECT stl_multi_statement_violations.userid,
       stl_multi_statement_violations."database",
       stl_multi_statement_violations.cmdname,
       stl_multi_statement_violations.xid,
       stl_multi_statement_violations.pid,
       svl_statementtext."label",
       svl_statementtext.starttime,
       svl_statementtext.endtime,
       svl_statementtext."sequence",
       svl_statementtext."type",
       svl_statementtext.text
FROM stl_multi_statement_violations
         LEFT JOIN svl_statementtext ON svl_statementtext.userid = stl_multi_statement_violations.userid AND
                                        svl_statementtext.xid = stl_multi_statement_violations.xid AND
                                        svl_statementtext.pid = stl_multi_statement_violations.pid
ORDER BY stl_multi_statement_violations.xid, svl_statementtext.starttime;

alter table svl_multi_statement_violations
    owner to rdsdb;

grant select on svl_multi_statement_violations to public;

