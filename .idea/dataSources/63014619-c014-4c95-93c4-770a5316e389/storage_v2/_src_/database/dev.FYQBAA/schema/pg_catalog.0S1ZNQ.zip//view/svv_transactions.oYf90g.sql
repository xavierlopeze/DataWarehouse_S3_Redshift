create view svv_transactions
            (txn_owner, txn_db, xid, pid, txn_start, lock_mode, lockable_object_type, relation, granted) as
SELECT rtrim(s.user_name::text)        AS txn_owner,
       rtrim(s.db_name::text)          AS txn_db,
       t.xid,
       t.pid::integer                  AS pid,
       t.start_ts                      AS txn_start,
       l."mode"::character varying(24) AS lock_mode,
       CASE
           WHEN l.relation IS NULL THEN 'transactionid'::text
           ELSE 'relation'::text
           END::character varying(14)  AS lockable_object_type,
       l.relation::integer             AS relation,
       l.granted
FROM stv_transactions t
         LEFT JOIN pg_locks l ON l.pid = t.pid
         LEFT JOIN stv_sessions s ON s.process = t.pid
WHERE t.ended = 0
  AND s.user_name <> 'rdsdb'::bpchar
ORDER BY t.start_ts, t.xid, l.granted, l.relation;

alter table svv_transactions
    owner to rdsdb;

grant select on svv_transactions to public;

