create view stl_smfaults
            (seq, run, mon_type, mon_name, severity, resolution_dbup, resolution_dbdown, code, recordtime, observer,
             culprit, msg, xml_extra, has_measure_val)
as
SELECT stll_smfaults.seq,
       stll_smfaults.run,
       stll_smfaults.mon_type,
       stll_smfaults.mon_name,
       stll_smfaults.severity,
       stll_smfaults.resolution_dbup,
       stll_smfaults.resolution_dbdown,
       stll_smfaults.code,
       stll_smfaults.recordtime,
       stll_smfaults.observer,
       stll_smfaults.culprit,
       stll_smfaults.msg,
       stll_smfaults.xml_extra,
       stll_smfaults.has_measure_val
FROM stll_smfaults;

alter table stl_smfaults
    owner to rdsdb;

