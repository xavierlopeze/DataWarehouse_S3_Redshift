create view stl_ml_create_model_log
            (xid, pid, create_time, schema_id, model_name, model_id, statement, algo_meta, exec_meta) as
SELECT stll_ml_create_model_log.xid,
       stll_ml_create_model_log.pid,
       stll_ml_create_model_log.create_time,
       stll_ml_create_model_log.schema_id,
       stll_ml_create_model_log.model_name,
       stll_ml_create_model_log.model_id,
       stll_ml_create_model_log."statement",
       stll_ml_create_model_log.algo_meta,
       stll_ml_create_model_log.exec_meta
FROM stll_ml_create_model_log;

alter table stl_ml_create_model_log
    owner to rdsdb;

