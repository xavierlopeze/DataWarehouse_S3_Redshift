create view stl_catalog_bloat
            (database_id, userid, pid, logtime, table_id, num_inserts, num_updates, num_deletes, total_insert_size,
             total_update_size, total_delete_size)
as
SELECT stll_catalog_bloat.database_id,
       stll_catalog_bloat.userid,
       stll_catalog_bloat.pid,
       stll_catalog_bloat.logtime,
       stll_catalog_bloat.table_id,
       stll_catalog_bloat.num_inserts,
       stll_catalog_bloat.num_updates,
       stll_catalog_bloat.num_deletes,
       stll_catalog_bloat.total_insert_size,
       stll_catalog_bloat.total_update_size,
       stll_catalog_bloat.total_delete_size
FROM stll_catalog_bloat;

alter table stl_catalog_bloat
    owner to rdsdb;

