create view stl_rlf_scan
            (query, slice, segment, step, section, total_time, min_time, max_time, windows_processed, blocks_opened,
             rows, materialized_columns)
as
SELECT stll_rlf_scan.query,
       stll_rlf_scan.slice,
       stll_rlf_scan.segment,
       stll_rlf_scan.step,
       stll_rlf_scan.section,
       stll_rlf_scan.total_time,
       stll_rlf_scan.min_time,
       stll_rlf_scan.max_time,
       stll_rlf_scan.windows_processed,
       stll_rlf_scan.blocks_opened,
       stll_rlf_scan."rows",
       stll_rlf_scan.materialized_columns
FROM stll_rlf_scan;

alter table stl_rlf_scan
    owner to rdsdb;

