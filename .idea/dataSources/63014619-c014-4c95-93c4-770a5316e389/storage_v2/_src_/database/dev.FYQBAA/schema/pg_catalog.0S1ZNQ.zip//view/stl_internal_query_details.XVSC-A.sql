create view stl_internal_query_details
            (query, xid, initial_query_time, seldispatch_status, query_cmd_type, user_temp_tables_accessed,
             volt_temp_tables_accessed, spectrum_tables_accessed, user_perm_tables_accessed, system_tables_accessed,
             query_target_table_type, memory_demanding_info, nobackup_tables_accessed, zindex_tables_accessed,
             pg_tables_accessed, dirty_tables_read, wlm_slot_type, is_short_query, est_peak_mem_needed,
             wlm_query_memory, datasharing_tables_accessed, uses_new_cost_model, new_model_reason)
as
SELECT stll_internal_query_details.query,
       stll_internal_query_details.xid,
       stll_internal_query_details.initial_query_time,
       stll_internal_query_details.seldispatch_status,
       stll_internal_query_details.query_cmd_type,
       stll_internal_query_details.user_temp_tables_accessed,
       stll_internal_query_details.volt_temp_tables_accessed,
       stll_internal_query_details.spectrum_tables_accessed,
       stll_internal_query_details.user_perm_tables_accessed,
       stll_internal_query_details.system_tables_accessed,
       stll_internal_query_details.query_target_table_type,
       stll_internal_query_details.memory_demanding_info,
       stll_internal_query_details.nobackup_tables_accessed,
       stll_internal_query_details.zindex_tables_accessed,
       stll_internal_query_details.pg_tables_accessed,
       stll_internal_query_details.dirty_tables_read,
       stll_internal_query_details.wlm_slot_type,
       stll_internal_query_details.is_short_query,
       stll_internal_query_details.est_peak_mem_needed,
       stll_internal_query_details.wlm_query_memory,
       stll_internal_query_details.datasharing_tables_accessed,
       stll_internal_query_details.uses_new_cost_model,
       stll_internal_query_details.new_model_reason
FROM stll_internal_query_details;

alter table stl_internal_query_details
    owner to rdsdb;

