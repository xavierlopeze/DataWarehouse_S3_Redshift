create view stl_vec_scan_stats
            (query, slice, segment, scalar_encoding_type, predicate_window_size, payload_window_size, compact_col_count,
             is_operator_pushdown, apply_xid_time, apply_predicate_time, extract_predicate_time, extract_payload_time,
             compact_predicate_time, compact_payload_time, scalar_predicate_time, consume_time)
as
SELECT stll_vec_scan_stats.query,
       stll_vec_scan_stats.slice,
       stll_vec_scan_stats.segment,
       stll_vec_scan_stats.scalar_encoding_type,
       stll_vec_scan_stats.predicate_window_size,
       stll_vec_scan_stats.payload_window_size,
       stll_vec_scan_stats.compact_col_count,
       stll_vec_scan_stats.is_operator_pushdown,
       stll_vec_scan_stats.apply_xid_time,
       stll_vec_scan_stats.apply_predicate_time,
       stll_vec_scan_stats.extract_predicate_time,
       stll_vec_scan_stats.extract_payload_time,
       stll_vec_scan_stats.compact_predicate_time,
       stll_vec_scan_stats.compact_payload_time,
       stll_vec_scan_stats.scalar_predicate_time,
       stll_vec_scan_stats.consume_time
FROM stll_vec_scan_stats;

alter table stl_vec_scan_stats
    owner to rdsdb;

