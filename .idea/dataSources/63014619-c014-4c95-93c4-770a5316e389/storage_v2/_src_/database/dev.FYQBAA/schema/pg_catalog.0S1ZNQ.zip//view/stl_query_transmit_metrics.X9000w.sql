create view stl_query_transmit_metrics
            (userid, xid, pid, query, send_starttime, send_endtime, send_time_spent_usec, send_bytes, send_rows,
             recv_starttime, recv_endtime, recv_time_spent_usec, recv_bytes)
as
SELECT stll_query_transmit_metrics.userid,
       stll_query_transmit_metrics.xid,
       stll_query_transmit_metrics.pid,
       stll_query_transmit_metrics.query,
       stll_query_transmit_metrics.send_starttime,
       stll_query_transmit_metrics.send_endtime,
       stll_query_transmit_metrics.send_time_spent_usec,
       stll_query_transmit_metrics.send_bytes,
       stll_query_transmit_metrics.send_rows,
       stll_query_transmit_metrics.recv_starttime,
       stll_query_transmit_metrics.recv_endtime,
       stll_query_transmit_metrics.recv_time_spent_usec,
       stll_query_transmit_metrics.recv_bytes
FROM stll_query_transmit_metrics;

alter table stl_query_transmit_metrics
    owner to rdsdb;

