create view stl_window
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, is_diskbased, workmem) as
SELECT stll_window.userid,
       stll_window.query,
       stll_window.slice,
       stll_window.segment,
       stll_window.step,
       stll_window.starttime,
       stll_window.endtime,
       stll_window.tasknum,
       stll_window."rows",
       stll_window.is_diskbased,
       stll_window.workmem
FROM stll_window;

alter table stl_window
    owner to rdsdb;

grant select on stl_window to public;

