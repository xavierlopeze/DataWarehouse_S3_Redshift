create view stl_s3_write_block_debug
            (logtime, key, tbl_id, s3_action, s3_state, one_perm_rep, a_temp, is_metadata, flags, node, colnum, sb_pos,
             tombstoned_id, backup_id)
as
SELECT stll_s3_write_block_debug.logtime,
       stll_s3_write_block_debug."key",
       stll_s3_write_block_debug.tbl_id,
       stll_s3_write_block_debug.s3_action,
       stll_s3_write_block_debug.s3_state,
       stll_s3_write_block_debug.one_perm_rep,
       stll_s3_write_block_debug.a_temp,
       stll_s3_write_block_debug.is_metadata,
       stll_s3_write_block_debug.flags,
       stll_s3_write_block_debug.node,
       stll_s3_write_block_debug.colnum,
       stll_s3_write_block_debug.sb_pos,
       stll_s3_write_block_debug.tombstoned_id,
       stll_s3_write_block_debug.backup_id
FROM stll_s3_write_block_debug;

alter table stl_s3_write_block_debug
    owner to rdsdb;

