create view stl_super_column_linker(userid, query, tbl, columnname, sqloperation) as
SELECT stll_super_column_linker.userid,
       stll_super_column_linker.query,
       stll_super_column_linker.tbl,
       stll_super_column_linker.columnname,
       stll_super_column_linker.sqloperation
FROM stll_super_column_linker;

alter table stl_super_column_linker
    owner to rdsdb;

