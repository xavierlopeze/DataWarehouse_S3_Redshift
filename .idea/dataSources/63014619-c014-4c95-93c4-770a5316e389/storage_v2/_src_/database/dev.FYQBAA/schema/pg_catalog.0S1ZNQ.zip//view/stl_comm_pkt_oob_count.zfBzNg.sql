create view stl_comm_pkt_oob_count
            (now, since, node, is_raidp, bad_guid, no_channel, bad_src, bad_dst, bad_cmd, bad_crc, excess_ack,
             low_seqnum, high_seqnum, early_xon, lost_packet, reorder_packet, likely_lost_ack, extreme_delay, in_rob,
             excess_fast_rexmit)
as
SELECT stll_comm_pkt_oob_count.now,
       stll_comm_pkt_oob_count.since,
       stll_comm_pkt_oob_count.node,
       stll_comm_pkt_oob_count.is_raidp,
       stll_comm_pkt_oob_count.bad_guid,
       stll_comm_pkt_oob_count.no_channel,
       stll_comm_pkt_oob_count.bad_src,
       stll_comm_pkt_oob_count.bad_dst,
       stll_comm_pkt_oob_count.bad_cmd,
       stll_comm_pkt_oob_count.bad_crc,
       stll_comm_pkt_oob_count.excess_ack,
       stll_comm_pkt_oob_count.low_seqnum,
       stll_comm_pkt_oob_count.high_seqnum,
       stll_comm_pkt_oob_count.early_xon,
       stll_comm_pkt_oob_count.lost_packet,
       stll_comm_pkt_oob_count.reorder_packet,
       stll_comm_pkt_oob_count.likely_lost_ack,
       stll_comm_pkt_oob_count.extreme_delay,
       stll_comm_pkt_oob_count.in_rob,
       stll_comm_pkt_oob_count.excess_fast_rexmit
FROM stll_comm_pkt_oob_count;

alter table stl_comm_pkt_oob_count
    owner to rdsdb;

