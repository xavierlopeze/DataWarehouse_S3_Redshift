create view stl_schema_quota_ddl(xid, pid, userid, schema_id, action_type, quota, timestamp) as
SELECT stll_schema_quota_ddl.xid,
       stll_schema_quota_ddl.pid,
       stll_schema_quota_ddl.userid,
       stll_schema_quota_ddl.schema_id,
       stll_schema_quota_ddl.action_type,
       stll_schema_quota_ddl."quota",
       stll_schema_quota_ddl."timestamp"
FROM stll_schema_quota_ddl;

alter table stl_schema_quota_ddl
    owner to rdsdb;

