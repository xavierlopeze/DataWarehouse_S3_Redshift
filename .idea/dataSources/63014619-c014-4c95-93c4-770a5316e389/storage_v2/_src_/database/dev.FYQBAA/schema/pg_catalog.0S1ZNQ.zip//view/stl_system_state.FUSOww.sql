create view stl_system_state
            (node, record_time, system_memfree, system_total, swap_free, swap_total, swap_in, swap_out,
             system_memavailable) as
SELECT stll_system_state.node,
       stll_system_state.record_time,
       stll_system_state.system_memfree,
       stll_system_state.system_total,
       stll_system_state.swap_free,
       stll_system_state.swap_total,
       stll_system_state.swap_in,
       stll_system_state.swap_out,
       stll_system_state.system_memavailable
FROM stll_system_state;

alter table stl_system_state
    owner to rdsdb;

