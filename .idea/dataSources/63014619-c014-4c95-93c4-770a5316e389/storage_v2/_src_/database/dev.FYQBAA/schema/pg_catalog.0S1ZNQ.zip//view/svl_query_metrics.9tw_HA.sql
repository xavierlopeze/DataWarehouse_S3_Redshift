create view svl_query_metrics
            (userid, query, service_class, dimension, segment, step, step_label, query_cpu_time, query_blocks_read,
             query_execution_time, query_cpu_usage_percent, query_temp_blocks_to_disk, segment_execution_time, cpu_skew,
             io_skew, scan_row_count, join_row_count, nested_loop_join_row_count, return_row_count,
             spectrum_scan_row_count, spectrum_scan_size_mb, query_queue_time, service_class_name)
as
SELECT qm.userid,
       qm.query,
       qm.service_class,
       CASE
           WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN 'query'::text
           WHEN qm.segment > -1 AND qm.step_type = -1 AND qm.step = -1 THEN 'segment'::text
           WHEN qm.segment > -1 AND qm.step_type > -1 AND qm.step > -1 THEN 'step'::text
           ELSE NULL::text
           END::character varying(24) AS                    dimension,
       CASE
           WHEN qm.segment = -1 THEN NULL::integer
           ELSE qm.segment
           END AS                                           segment,
       CASE
           WHEN qm.step = -1 THEN NULL::integer
           ELSE qm.step
           END AS                                           step,
       CASE
           WHEN qm.step_type = 1 THEN 'scan'::text
           WHEN qm.step_type = 2 THEN 'insert'::text
           WHEN qm.step_type = 3 THEN 'aggr'::text
           WHEN qm.step_type = 4 THEN 'return'::text
           WHEN qm.step_type = 6 THEN 'sort'::text
           WHEN qm.step_type = 7 THEN 'merge'::text
           WHEN qm.step_type = 8 THEN 'dist'::text
           WHEN qm.step_type = 9 THEN 'bcast'::text
           WHEN qm.step_type = 10 THEN 'hjoin'::text
           WHEN qm.step_type = 11 THEN 'mjoin'::text
           WHEN qm.step_type = 12 THEN 'save'::text
           WHEN qm.step_type = 14 THEN 'hash'::text
           WHEN qm.step_type = 15 THEN 'nloop'::text
           WHEN qm.step_type = 16 THEN 'project'::text
           WHEN qm.step_type = 17 THEN 'limit'::text
           WHEN qm.step_type = 18 THEN 'unique'::text
           WHEN qm.step_type = 20 THEN 'delete'::text
           WHEN qm.step_type = 26 THEN 'limit'::text
           WHEN qm.step_type = 29 THEN 'window'::text
           WHEN qm.step_type = 32 THEN 'udf'::text
           WHEN qm.step_type = 33 THEN 'unique'::text
           WHEN qm.step_type = 37 THEN 'returnclient'::text
           WHEN qm.step_type = 38 THEN 'returnleader'::text
           WHEN qm.step_type = 40 THEN 'spectrumscan'::text
           ELSE NULL::text
           END::character varying(30) AS                    step_label,
       CASE
           WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN ceiling(
                       CASE
                           WHEN "max"(qm.cpu_time)::numeric::numeric(38, 6) = -1::numeric(38, 6) THEN NULL::numeric
                           ELSE "max"(qm.cpu_time)::numeric::numeric(38, 6)
                           END / 1000000::numeric::numeric(38, 6))
           ELSE NULL::numeric
           END::bigint AS                                   query_cpu_time,
       CASE
           WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN
               CASE
                   WHEN "max"(qm.blocks_read) = -1 THEN NULL::bigint
                   ELSE "max"(qm.blocks_read)
                   END
           ELSE NULL::bigint
           END AS                                           query_blocks_read,
       ceiling(q.total_exec_time::numeric::numeric(38, 6) /
               1000000::numeric::numeric(38, 6))::bigint AS query_execution_time,
       round(
               CASE
                   WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN 100::numeric * "max"((
                                                                                                                 CASE
                                                                                                                     WHEN qm.cpu_time = -1
                                                                                                                         THEN NULL::bigint
                                                                                                                     ELSE qm.cpu_time
                                                                                                                     END::numeric +
                                                                                                                 0.00001) /
                                                                                                         (
                                                                                                                 CASE
                                                                                                                     WHEN qm.run_time = -1
                                                                                                                         THEN NULL::bigint
                                                                                                                     ELSE qm.run_time
                                                                                                                     END::numeric +
                                                                                                                 0.00001))
                   ELSE NULL::numeric
                   END, 2)::numeric(38, 2) AS               query_cpu_usage_percent,
       CASE
           WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN
               CASE
                   WHEN "max"(qm.blocks_to_disk) = -1 THEN NULL::bigint
                   ELSE "max"(qm.blocks_to_disk)
                   END
           ELSE NULL::bigint
           END AS                                           query_temp_blocks_to_disk,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = -1 THEN ceiling(
                       CASE
                           WHEN "max"(qm.max_run_time) = -1 THEN NULL::bigint
                           ELSE "max"(qm.max_run_time)
                           END::numeric::numeric(38, 6) / 1000000::numeric::numeric(38, 6))
           ELSE NULL::numeric
           END::bigint AS                                   segment_execution_time,
       round(
               CASE
                   WHEN qm.segment > -1 AND qm.step_type = -1 AND "max"(qm.max_cpu_time) > 0 AND "max"(qm.cpu_time) > 0
                       THEN qm.slices::numeric * "max"((
                                                               CASE
                                                                   WHEN qm.max_cpu_time = -1 THEN NULL::bigint
                                                                   ELSE qm.max_cpu_time
                                                                   END::numeric + 0.00001) / (
                                                               CASE
                                                                   WHEN qm.cpu_time = -1 THEN NULL::bigint
                                                                   ELSE qm.cpu_time
                                                                   END::numeric + 0.00001))
                   ELSE NULL::numeric
                   END, 2)::numeric(38, 2) AS               cpu_skew,
       round(
               CASE
                   WHEN qm.segment > -1 AND qm.step_type = -1 AND "max"(qm.max_blocks_read) > 0 AND
                        "max"(qm.blocks_read) > 0 THEN qm.slices::numeric * "max"((
                                                                                          CASE
                                                                                              WHEN qm.max_blocks_read = -1
                                                                                                  THEN NULL::integer
                                                                                              ELSE qm.max_blocks_read
                                                                                              END::numeric + 0.00001) /
                                                                                  (
                                                                                          CASE
                                                                                              WHEN qm.blocks_read = -1
                                                                                                  THEN NULL::bigint
                                                                                              ELSE qm.blocks_read
                                                                                              END::numeric + 0.00001))
                   ELSE NULL::numeric
                   END, 2)::numeric(38, 2) AS               io_skew,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = 1 AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm."rows") = -1 THEN NULL::bigint
                   ELSE "max"(qm."rows")
                   END
           ELSE NULL::bigint
           END AS                                           scan_row_count,
       CASE
           WHEN qm.segment > -1 AND (qm.step_type = 10 OR qm.step_type = 11 OR qm.step_type = 15) AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm."rows") = -1 THEN NULL::bigint
                   ELSE "max"(qm."rows")
                   END
           ELSE NULL::bigint
           END AS                                           join_row_count,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = 15 AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm."rows") = -1 THEN NULL::bigint
                   ELSE "max"(qm."rows")
                   END
           ELSE NULL::bigint
           END AS                                           nested_loop_join_row_count,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = 37 AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm."rows") = -1 THEN NULL::bigint
                   ELSE "max"(qm."rows")
                   END
           ELSE NULL::bigint
           END AS                                           return_row_count,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = 40 AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm."rows") = -1 THEN NULL::bigint
                   ELSE "max"(qm."rows")
                   END
           ELSE NULL::bigint
           END AS                                           spectrum_scan_row_count,
       CASE
           WHEN qm.segment > -1 AND qm.step_type = 40 AND qm.step > -1 THEN
               CASE
                   WHEN "max"(qm.query_scan_size) = -1 THEN NULL::bigint
                   ELSE "max"(qm.query_scan_size)
                   END
           ELSE NULL::bigint
           END AS                                           spectrum_scan_size_mb,
       CASE
           WHEN qm.segment = -1 AND qm.step_type = -1 AND qm.step = -1 THEN ceiling(
                       CASE
                           WHEN "max"(qm.query_queue_time) = -1 THEN NULL::bigint
                           ELSE "max"(qm.query_queue_time)
                           END::numeric::numeric(38, 6) / 1000000::numeric::numeric(38, 6))
           ELSE NULL::numeric
           END::bigint AS                                   query_queue_time,
       qm.service_class_name
FROM stl_query_metrics qm
         JOIN stl_wlm_query q USING (userid, service_class, query)
GROUP BY qm.userid, qm.query, qm.service_class, qm.service_class_name, qm.slices, qm.segment, qm.step_type, qm.step,
         q.total_exec_time;

alter table svl_query_metrics
    owner to rdsdb;

grant select on svl_query_metrics to public;

