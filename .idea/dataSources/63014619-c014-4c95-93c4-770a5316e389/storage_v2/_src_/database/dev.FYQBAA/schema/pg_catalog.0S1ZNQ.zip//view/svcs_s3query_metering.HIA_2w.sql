create view svcs_s3query_metering(eventtime, query, internal_request_uuid, metered_mbs) as
SELECT stl_s3query_metering.eventtime,
       stl_s3query_metering.query,
       stl_s3query_metering.internal_request_uuid,
       stl_s3query_metering.metered_mbs
FROM stl_s3query_metering
UNION ALL
SELECT '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.eventtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval AS eventtime,
       "map".primary_query  AS query,
       stcs.internal_request_uuid,
       stcs.metered_mbs
FROM stcs_s3query_metering stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE stcs.__cluster_type = 'cs'::bpchar
  AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10);

alter table svcs_s3query_metering
    owner to rdsdb;

