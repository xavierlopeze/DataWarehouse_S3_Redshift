create view stl_query_memory_cheating (query, slice, segment, step, eventtime, memory_used_mb, workmem_mb, sim) as
SELECT stll_query_memory_cheating.query,
       stll_query_memory_cheating.slice,
       stll_query_memory_cheating.segment,
       stll_query_memory_cheating.step,
       stll_query_memory_cheating.eventtime,
       stll_query_memory_cheating.memory_used_mb,
       stll_query_memory_cheating.workmem_mb,
       stll_query_memory_cheating.sim
FROM stll_query_memory_cheating;

alter table stl_query_memory_cheating
    owner to rdsdb;

