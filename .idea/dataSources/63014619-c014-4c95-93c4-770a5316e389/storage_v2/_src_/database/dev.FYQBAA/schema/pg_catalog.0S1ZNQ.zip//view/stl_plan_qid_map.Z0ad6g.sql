create view stl_plan_qid_map(query, plan_qid) as
SELECT stll_plan_qid_map.query, stll_plan_qid_map.plan_qid
FROM stll_plan_qid_map;

alter table stl_plan_qid_map
    owner to rdsdb;

