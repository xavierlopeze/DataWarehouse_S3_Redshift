create view stl_autovacuum_detail
            (pid, starttime, endtime, window_time, pause_time, commit_time, max_commit_time, min_commit_time,
             num_commits, tables_skipped, tables_done, num_vacdel, num_vacrp, num_vacsort, space_reclaimed_mb,
             skip_time, fetch_info_time)
as
SELECT stll_autovacuum_detail.pid,
       stll_autovacuum_detail.starttime,
       stll_autovacuum_detail.endtime,
       stll_autovacuum_detail.window_time,
       stll_autovacuum_detail.pause_time,
       stll_autovacuum_detail.commit_time,
       stll_autovacuum_detail.max_commit_time,
       stll_autovacuum_detail.min_commit_time,
       stll_autovacuum_detail.num_commits,
       stll_autovacuum_detail.tables_skipped,
       stll_autovacuum_detail.tables_done,
       stll_autovacuum_detail.num_vacdel,
       stll_autovacuum_detail.num_vacrp,
       stll_autovacuum_detail.num_vacsort,
       stll_autovacuum_detail.space_reclaimed_mb,
       stll_autovacuum_detail.skip_time,
       stll_autovacuum_detail.fetch_info_time
FROM stll_autovacuum_detail;

alter table stl_autovacuum_detail
    owner to rdsdb;

