create view stl_parse (userid, query, slice, segment, step, starttime, endtime, tasknum, rows) as
SELECT stll_parse.userid,
       stll_parse.query,
       stll_parse.slice,
       stll_parse.segment,
       stll_parse.step,
       stll_parse.starttime,
       stll_parse.endtime,
       stll_parse.tasknum,
       stll_parse."rows"
FROM stll_parse;

alter table stl_parse
    owner to rdsdb;

grant select on stl_parse to public;

