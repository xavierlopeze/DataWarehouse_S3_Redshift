create view svv_schema_quota_state (schema_id, schema_name, schema_owner, quota, disk_usage, disk_usage_pct) as
SELECT sqs.schema_id,
       pgn.nspname                                                                                                 AS schema_name,
       pgn.nspowner                                                                                                AS schema_owner,
       sqs."quota",
       sqs.disk_usage,
       round(sqs.disk_usage::double precision * 100::double precision / sqs."quota"::double precision,
             2::numeric)                                                                                           AS disk_usage_pct
FROM stv_schema_quota_state sqs
         JOIN pg_namespace pgn ON sqs.schema_id::oid = pgn.oid;

alter table svv_schema_quota_state
    owner to rdsdb;

grant select on svv_schema_quota_state to public;

