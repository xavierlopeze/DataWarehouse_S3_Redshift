create view stl_plan_querytext(query, sequence, text) as
SELECT stll_plan_querytext.query, stll_plan_querytext."sequence", stll_plan_querytext.text
FROM stll_plan_querytext;

alter table stl_plan_querytext
    owner to rdsdb;

