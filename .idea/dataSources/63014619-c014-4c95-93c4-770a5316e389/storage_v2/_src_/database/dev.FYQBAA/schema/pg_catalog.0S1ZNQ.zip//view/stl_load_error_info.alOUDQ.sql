create view stl_load_error_info (userid, session, query, line_number, field, value, is_null, type, tmod) as
SELECT stll_load_error_info.userid,
       stll_load_error_info."session",
       stll_load_error_info.query,
       stll_load_error_info.line_number,
       stll_load_error_info.field,
       stll_load_error_info.value,
       stll_load_error_info.is_null,
       stll_load_error_info."type",
       stll_load_error_info.tmod
FROM stll_load_error_info;

alter table stl_load_error_info
    owner to rdsdb;

