create view stl_datashare_changes_consumer
            (userid, username, xid, pid, initial_query_time, actiontime, action, sharedbid, sharedbname, sharename,
             produceraccount, producernamespace, targettype, targetid, targetname, status, message)
as
SELECT stll_datashare_changes_consumer.userid,
       stll_datashare_changes_consumer.username,
       stll_datashare_changes_consumer.xid,
       stll_datashare_changes_consumer.pid,
       stll_datashare_changes_consumer.initial_query_time,
       stll_datashare_changes_consumer.actiontime,
       stll_datashare_changes_consumer."action",
       stll_datashare_changes_consumer.sharedbid,
       stll_datashare_changes_consumer.sharedbname,
       stll_datashare_changes_consumer.sharename,
       stll_datashare_changes_consumer.produceraccount,
       stll_datashare_changes_consumer.producernamespace,
       stll_datashare_changes_consumer.targettype,
       stll_datashare_changes_consumer.targetid,
       stll_datashare_changes_consumer.targetname,
       stll_datashare_changes_consumer.status,
       stll_datashare_changes_consumer.message
FROM stll_datashare_changes_consumer;

alter table stl_datashare_changes_consumer
    owner to rdsdb;

