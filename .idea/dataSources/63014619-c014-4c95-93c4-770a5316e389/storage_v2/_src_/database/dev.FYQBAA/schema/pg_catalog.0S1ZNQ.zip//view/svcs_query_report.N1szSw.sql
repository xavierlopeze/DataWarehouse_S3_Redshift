create view svcs_query_report
            (userid, query, slice, segment, step, start_time, end_time, elapsed_time, rows, bytes, label, is_diskbased,
             workmem, is_rrscan, is_delayed_scan, rows_pre_filter)
as
SELECT stcs.userid,
       "map".primary_query                                                                                   AS query,
       stcs.slice,
       stcs.segment,
       stcs.step,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.start_time::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval                                                                                  AS start_time,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.end_time::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval                                                                                  AS end_time,
       stcs.elapsed_time,
       stcs."rows",
       stcs.bytes,
       stcs."label",
       stcs.is_diskbased,
       stcs.workmem,
       stcs.is_rrscan,
       stcs.is_delayed_scan,
       stcs.rows_pre_filter
FROM ((((((((((((((((((SELECT stcs_aggr.userid,
                              stcs_aggr.query,
                              stcs_aggr.slice,
                              stcs_aggr.segment,
                              stcs_aggr.step,
                              stcs_aggr.starttime                                                  AS start_time,
                              stcs_aggr.endtime                                                    AS end_time,
                              stcs_aggr.endtime - stcs_aggr.starttime                              AS elapsed_time,
                              stcs_aggr."rows",
                              stcs_aggr.bytes,
                              ('aggr   tbl='::text || stcs_aggr.tbl::text)::character varying      AS "label",
                              stcs_aggr.is_diskbased,
                              stcs_aggr.workmem,
                              'f'::bpchar                                                          AS is_rrscan,
                              'f'::bpchar                                                          AS is_delayed_scan,
                              0                                                                    AS rows_pre_filter,
                              split_part(stcs_aggr.__path::text, '/'::text, 10)::character varying AS burst_cluster
                       FROM stcs_aggr
                       WHERE stcs_aggr.__cluster_type = 'cs'::bpchar
                         AND to_date(stcs_aggr.__log_generated_date::text, 'YYYYMMDD'::text) >
                             (getdate() - '7 days'::interval)
                       UNION ALL
                       SELECT stcs_bcast.userid,
                              stcs_bcast.query,
                              stcs_bcast.slice,
                              stcs_bcast.segment,
                              stcs_bcast.step,
                              stcs_bcast.starttime                                                  AS start_time,
                              stcs_bcast.endtime                                                    AS end_time,
                              stcs_bcast.endtime - stcs_bcast.starttime                             AS elapsed_time,
                              stcs_bcast."rows",
                              stcs_bcast.bytes,
                              'bcast               '::character varying                             AS "label",
                              'f'::bpchar                                                           AS is_diskbased,
                              0                                                                     AS workmem,
                              'f'::bpchar                                                           AS is_rrscan,
                              'f'::bpchar                                                           AS is_delayed_scan,
                              0                                                                     AS rows_pre_filter,
                              split_part(stcs_bcast.__path::text, '/'::text, 10)::character varying AS burst_cluster
                       FROM stcs_bcast
                       WHERE stcs_bcast.__cluster_type = 'cs'::bpchar
                         AND to_date(stcs_bcast.__log_generated_date::text, 'YYYYMMDD'::text) >
                             (getdate() - '7 days'::interval))
                      UNION ALL
                      SELECT stcs_delete.userid,
                             stcs_delete.query,
                             stcs_delete.slice,
                             stcs_delete.segment,
                             stcs_delete.step,
                             stcs_delete.starttime                                                  AS start_time,
                             stcs_delete.endtime                                                    AS end_time,
                             stcs_delete.endtime - stcs_delete.starttime                            AS elapsed_time,
                             stcs_delete."rows",
                             0                                                                      AS bytes,
                             ('delete tbl='::text || stcs_delete.tbl::text)::character varying      AS "label",
                             'f'::bpchar                                                            AS is_diskbased,
                             0                                                                      AS workmem,
                             'f'::bpchar                                                            AS is_rrscan,
                             'f'::bpchar                                                            AS is_delayed_scan,
                             0                                                                      AS rows_pre_filter,
                             split_part(stcs_delete.__path::text, '/'::text, 10)::character varying AS burst_cluster
                      FROM stcs_delete
                      WHERE stcs_delete.__cluster_type = 'cs'::bpchar
                        AND to_date(stcs_delete.__log_generated_date::text, 'YYYYMMDD'::text) >
                            (getdate() - '7 days'::interval))
                     UNION ALL
                     SELECT stcs_dist.userid,
                            stcs_dist.query,
                            stcs_dist.slice,
                            stcs_dist.segment,
                            stcs_dist.step,
                            stcs_dist.starttime                                                  AS start_time,
                            stcs_dist.endtime                                                    AS end_time,
                            stcs_dist.endtime - stcs_dist.starttime                              AS elapsed_time,
                            stcs_dist."rows",
                            stcs_dist.bytes,
                            'dist                '::character varying                            AS "label",
                            'f'::bpchar                                                          AS is_diskbased,
                            0                                                                    AS workmem,
                            'f'::bpchar                                                          AS is_rrscan,
                            'f'::bpchar                                                          AS is_delayed_scan,
                            0                                                                    AS rows_pre_filter,
                            split_part(stcs_dist.__path::text, '/'::text, 10)::character varying AS burst_cluster
                     FROM stcs_dist
                     WHERE stcs_dist.__cluster_type = 'cs'::bpchar
                       AND to_date(stcs_dist.__log_generated_date::text, 'YYYYMMDD'::text) >
                           (getdate() - '7 days'::interval))
                    UNION ALL
                    SELECT stcs_hash.userid,
                           stcs_hash.query,
                           stcs_hash.slice,
                           stcs_hash.segment,
                           stcs_hash.step,
                           stcs_hash.starttime                                                  AS start_time,
                           stcs_hash.endtime                                                    AS end_time,
                           stcs_hash.endtime - stcs_hash.starttime                              AS elapsed_time,
                           stcs_hash."rows",
                           stcs_hash.bytes,
                           ('hash   tbl='::text || stcs_hash.tbl::text)::character varying      AS "label",
                           stcs_hash.is_diskbased,
                           stcs_hash.workmem,
                           'f'::bpchar                                                          AS is_rrscan,
                           'f'::bpchar                                                          AS is_delayed_scan,
                           0                                                                    AS rows_pre_filter,
                           split_part(stcs_hash.__path::text, '/'::text, 10)::character varying AS burst_cluster
                    FROM stcs_hash
                    WHERE stcs_hash.__cluster_type = 'cs'::bpchar
                      AND to_date(stcs_hash.__log_generated_date::text, 'YYYYMMDD'::text) >
                          (getdate() - '7 days'::interval))
                   UNION ALL
                   SELECT stcs_hashjoin.userid,
                          stcs_hashjoin.query,
                          stcs_hashjoin.slice,
                          stcs_hashjoin.segment,
                          stcs_hashjoin.step,
                          stcs_hashjoin.starttime                                                  AS start_time,
                          stcs_hashjoin.endtime                                                    AS end_time,
                          stcs_hashjoin.endtime - stcs_hashjoin.starttime                          AS elapsed_time,
                          stcs_hashjoin."rows",
                          0                                                                        AS bytes,
                          ('hjoin  tbl='::text || stcs_hashjoin.tbl::text)::character varying      AS "label",
                          'f'::bpchar                                                              AS is_diskbased,
                          0                                                                        AS workmem,
                          'f'::bpchar                                                              AS is_rrscan,
                          'f'::bpchar                                                              AS is_delayed_scan,
                          0                                                                        AS rows_pre_filter,
                          split_part(stcs_hashjoin.__path::text, '/'::text, 10)::character varying AS burst_cluster
                   FROM stcs_hashjoin
                   WHERE stcs_hashjoin.__cluster_type = 'cs'::bpchar
                     AND to_date(stcs_hashjoin.__log_generated_date::text, 'YYYYMMDD'::text) >
                         (getdate() - '7 days'::interval))
                  UNION ALL
                  SELECT stcs_insert.userid,
                         stcs_insert.query,
                         stcs_insert.slice,
                         stcs_insert.segment,
                         stcs_insert.step,
                         stcs_insert.starttime                                                  AS start_time,
                         stcs_insert.endtime                                                    AS end_time,
                         stcs_insert.endtime - stcs_insert.starttime                            AS elapsed_time,
                         stcs_insert."rows",
                         0                                                                      AS bytes,
                         ('insert tbl='::text || stcs_insert.tbl::text)::character varying      AS "label",
                         'f'::bpchar                                                            AS is_diskbased,
                         0                                                                      AS workmem,
                         'f'::bpchar                                                            AS is_rrscan,
                         'f'::bpchar                                                            AS is_delayed_scan,
                         0                                                                      AS rows_pre_filter,
                         split_part(stcs_insert.__path::text, '/'::text, 10)::character varying AS burst_cluster
                  FROM stcs_insert
                  WHERE stcs_insert.__cluster_type = 'cs'::bpchar
                    AND to_date(stcs_insert.__log_generated_date::text, 'YYYYMMDD'::text) >
                        (getdate() - '7 days'::interval))
                 UNION ALL
                 SELECT stcs_limit.userid,
                        stcs_limit.query,
                        stcs_limit.slice,
                        stcs_limit.segment,
                        stcs_limit.step,
                        stcs_limit.starttime                                                  AS start_time,
                        stcs_limit.endtime                                                    AS end_time,
                        stcs_limit.endtime - stcs_limit.starttime                             AS elapsed_time,
                        stcs_limit."rows",
                        0                                                                     AS bytes,
                        'limit               '::character varying                             AS "label",
                        'f'::bpchar                                                           AS is_diskbased,
                        0                                                                     AS workmem,
                        'f'::bpchar                                                           AS is_rrscan,
                        'f'::bpchar                                                           AS is_delayed_scan,
                        0                                                                     AS rows_pre_filter,
                        split_part(stcs_limit.__path::text, '/'::text, 10)::character varying AS burst_cluster
                 FROM stcs_limit
                 WHERE stcs_limit.__cluster_type = 'cs'::bpchar
                   AND to_date(stcs_limit.__log_generated_date::text, 'YYYYMMDD'::text) >
                       (getdate() - '7 days'::interval))
                UNION ALL
                SELECT stcs_merge.userid,
                       stcs_merge.query,
                       stcs_merge.slice,
                       stcs_merge.segment,
                       stcs_merge.step,
                       stcs_merge.starttime                                                  AS start_time,
                       stcs_merge.endtime                                                    AS end_time,
                       stcs_merge.endtime - stcs_merge.starttime                             AS elapsed_time,
                       stcs_merge."rows",
                       0                                                                     AS bytes,
                       'merge               '::character varying                             AS "label",
                       'f'::bpchar                                                           AS is_diskbased,
                       0                                                                     AS workmem,
                       'f'::bpchar                                                           AS is_rrscan,
                       'f'::bpchar                                                           AS is_delayed_scan,
                       0                                                                     AS rows_pre_filter,
                       split_part(stcs_merge.__path::text, '/'::text, 10)::character varying AS burst_cluster
                FROM stcs_merge
                WHERE stcs_merge.__cluster_type = 'cs'::bpchar
                  AND to_date(stcs_merge.__log_generated_date::text, 'YYYYMMDD'::text) >
                      (getdate() - '7 days'::interval))
               UNION ALL
               SELECT stcs_mergejoin.userid,
                      stcs_mergejoin.query,
                      stcs_mergejoin.slice,
                      stcs_mergejoin.segment,
                      stcs_mergejoin.step,
                      stcs_mergejoin.starttime                                                  AS start_time,
                      stcs_mergejoin.endtime                                                    AS end_time,
                      stcs_mergejoin.endtime - stcs_mergejoin.starttime                         AS elapsed_time,
                      stcs_mergejoin."rows",
                      0                                                                         AS bytes,
                      ('mjoin  tbl='::text || stcs_mergejoin.tbl::text)::character varying      AS "label",
                      'f'::bpchar                                                               AS is_diskbased,
                      0                                                                         AS workmem,
                      'f'::bpchar                                                               AS is_rrscan,
                      'f'::bpchar                                                               AS is_delayed_scan,
                      0                                                                         AS rows_pre_filter,
                      split_part(stcs_mergejoin.__path::text, '/'::text, 10)::character varying AS burst_cluster
               FROM stcs_mergejoin
               WHERE stcs_mergejoin.__cluster_type = 'cs'::bpchar
                 AND to_date(stcs_mergejoin.__log_generated_date::text, 'YYYYMMDD'::text) >
                     (getdate() - '7 days'::interval))
              UNION ALL
              SELECT stcs_nestloop.userid,
                     stcs_nestloop.query,
                     stcs_nestloop.slice,
                     stcs_nestloop.segment,
                     stcs_nestloop.step,
                     stcs_nestloop.starttime                                                  AS start_time,
                     stcs_nestloop.endtime                                                    AS end_time,
                     stcs_nestloop.endtime - stcs_nestloop.starttime                          AS elapsed_time,
                     stcs_nestloop."rows",
                     0                                                                        AS bytes,
                     ('nloop  tbl='::text || stcs_nestloop.tbl::text)::character varying      AS "label",
                     'f'::bpchar                                                              AS is_diskbased,
                     0                                                                        AS workmem,
                     'f'::bpchar                                                              AS is_rrscan,
                     'f'::bpchar                                                              AS is_delayed_scan,
                     0                                                                        AS rows_pre_filter,
                     split_part(stcs_nestloop.__path::text, '/'::text, 10)::character varying AS burst_cluster
              FROM stcs_nestloop
              WHERE stcs_nestloop.__cluster_type = 'cs'::bpchar
                AND to_date(stcs_nestloop.__log_generated_date::text, 'YYYYMMDD'::text) >
                    (getdate() - '7 days'::interval))
             UNION ALL
             SELECT stcs_parse.userid,
                    stcs_parse.query,
                    stcs_parse.slice,
                    stcs_parse.segment,
                    stcs_parse.step,
                    stcs_parse.starttime                                                  AS start_time,
                    stcs_parse.endtime                                                    AS end_time,
                    stcs_parse.endtime - stcs_parse.starttime                             AS elapsed_time,
                    stcs_parse."rows",
                    0                                                                     AS bytes,
                    'parse               '::character varying                             AS "label",
                    'f'::bpchar                                                           AS is_diskbased,
                    0                                                                     AS workmem,
                    'f'::bpchar                                                           AS is_rrscan,
                    'f'::bpchar                                                           AS is_delayed_scan,
                    0                                                                     AS rows_pre_filter,
                    split_part(stcs_parse.__path::text, '/'::text, 10)::character varying AS burst_cluster
             FROM stcs_parse
             WHERE stcs_parse.__cluster_type = 'cs'::bpchar
               AND to_date(stcs_parse.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
            UNION ALL
            SELECT stcs_scan.userid,
                   stcs_scan.query,
                   stcs_scan.slice,
                   stcs_scan.segment,
                   stcs_scan.step,
                   stcs_scan.starttime                                                  AS start_time,
                   stcs_scan.endtime                                                    AS end_time,
                   stcs_scan.endtime - stcs_scan.starttime                              AS elapsed_time,
                   stcs_scan."rows",
                   stcs_scan.bytes,
                   CASE
                       WHEN stcs_scan."type" = 19 THEN 'scan   udf='::text || stcs_scan.tbl::text
                       ELSE (('scan   tbl='::text || stcs_scan.tbl::text) || ' name='::text) ||
                            stcs_scan.perm_table_name::text
                       END::character varying                                           AS "label",
                   'f'::bpchar                                                          AS is_diskbased,
                   0                                                                    AS workmem,
                   stcs_scan.is_rrscan,
                   stcs_scan.is_delayed_scan,
                   stcs_scan.rows_pre_filter,
                   split_part(stcs_scan.__path::text, '/'::text, 10)::character varying AS burst_cluster
            FROM stcs_scan
            WHERE stcs_scan.__cluster_type = 'cs'::bpchar
              AND to_date(stcs_scan.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
           UNION ALL
           SELECT stcs_project.userid,
                  stcs_project.query,
                  stcs_project.slice,
                  stcs_project.segment,
                  stcs_project.step,
                  stcs_project.starttime                                                  AS start_time,
                  stcs_project.endtime                                                    AS end_time,
                  stcs_project.endtime - stcs_project.starttime                           AS elapsed_time,
                  stcs_project."rows",
                  0                                                                       AS bytes,
                  'project             '::character varying                               AS "label",
                  'f'::bpchar                                                             AS is_diskbased,
                  0                                                                       AS workmem,
                  'f'::bpchar                                                             AS is_rrscan,
                  'f'::bpchar                                                             AS is_delayed_scan,
                  0                                                                       AS rows_pre_filter,
                  split_part(stcs_project.__path::text, '/'::text, 10)::character varying AS burst_cluster
           FROM stcs_project
           WHERE stcs_project.__cluster_type = 'cs'::bpchar
             AND to_date(stcs_project.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
          UNION ALL
          SELECT stcs_return.userid,
                 stcs_return.query,
                 stcs_return.slice,
                 stcs_return.segment,
                 stcs_return.step,
                 stcs_return.starttime                                                  AS start_time,
                 stcs_return.endtime                                                    AS end_time,
                 stcs_return.endtime - stcs_return.starttime                            AS elapsed_time,
                 stcs_return."rows",
                 stcs_return.bytes,
                 'return              '::character varying                              AS "label",
                 'f'::bpchar                                                            AS is_diskbased,
                 0                                                                      AS workmem,
                 'f'::bpchar                                                            AS is_rrscan,
                 'f'::bpchar                                                            AS is_delayed_scan,
                 0                                                                      AS rows_pre_filter,
                 split_part(stcs_return.__path::text, '/'::text, 10)::character varying AS burst_cluster
          FROM stcs_return
          WHERE stcs_return.__cluster_type = 'cs'::bpchar
            AND to_date(stcs_return.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
         UNION ALL
         SELECT stcs_save.userid,
                stcs_save.query,
                stcs_save.slice,
                stcs_save.segment,
                stcs_save.step,
                stcs_save.starttime                                                  AS start_time,
                stcs_save.endtime                                                    AS end_time,
                stcs_save.endtime - stcs_save.starttime                              AS elapsed_time,
                stcs_save."rows",
                stcs_save.bytes,
                ('save   tbl='::text || stcs_save.tbl::text)::character varying      AS "label",
                stcs_save.is_diskbased,
                stcs_save.workmem,
                'f'::bpchar                                                          AS is_rrscan,
                'f'::bpchar                                                          AS is_delayed_scan,
                0                                                                    AS rows_pre_filter,
                split_part(stcs_save.__path::text, '/'::text, 10)::character varying AS burst_cluster
         FROM stcs_save
         WHERE stcs_save.__cluster_type = 'cs'::bpchar
           AND to_date(stcs_save.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
        UNION ALL
        SELECT stcs_sort.userid,
               stcs_sort.query,
               stcs_sort.slice,
               stcs_sort.segment,
               stcs_sort.step,
               stcs_sort.starttime                                                  AS start_time,
               stcs_sort.endtime                                                    AS end_time,
               stcs_sort.endtime - stcs_sort.starttime                              AS elapsed_time,
               stcs_sort."rows",
               stcs_sort.bytes,
               ('sort   tbl='::text || stcs_sort.tbl::text)::character varying      AS "label",
               stcs_sort.is_diskbased,
               stcs_sort.workmem,
               'f'::bpchar                                                          AS is_rrscan,
               'f'::bpchar                                                          AS is_delayed_scan,
               0                                                                    AS rows_pre_filter,
               split_part(stcs_sort.__path::text, '/'::text, 10)::character varying AS burst_cluster
        FROM stcs_sort
        WHERE stcs_sort.__cluster_type = 'cs'::bpchar
          AND to_date(stcs_sort.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
       UNION ALL
       SELECT stcs_unique.userid,
              stcs_unique.query,
              stcs_unique.slice,
              stcs_unique.segment,
              stcs_unique.step,
              stcs_unique.starttime                                                  AS start_time,
              stcs_unique.endtime                                                    AS end_time,
              stcs_unique.endtime - stcs_unique.starttime                            AS elapsed_time,
              stcs_unique."rows",
              0                                                                      AS bytes,
              'unique              '::character varying                              AS "label",
              stcs_unique.is_diskbased,
              stcs_unique.workmem,
              'f'::bpchar                                                            AS is_rrscan,
              'f'::bpchar                                                            AS is_delayed_scan,
              0                                                                      AS rows_pre_filter,
              split_part(stcs_unique.__path::text, '/'::text, 10)::character varying AS burst_cluster
       FROM stcs_unique
       WHERE stcs_unique.__cluster_type = 'cs'::bpchar
         AND to_date(stcs_unique.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval))
      UNION ALL
      SELECT stcs_window.userid,
             stcs_window.query,
             stcs_window.slice,
             stcs_window.segment,
             stcs_window.step,
             stcs_window.starttime                                                  AS start_time,
             stcs_window.endtime                                                    AS end_time,
             stcs_window.endtime - stcs_window.starttime                            AS elapsed_time,
             stcs_window."rows",
             0                                                                      AS bytes,
             'window              '::character varying                              AS "label",
             stcs_window.is_diskbased,
             stcs_window.workmem,
             'f'::bpchar                                                            AS is_rrscan,
             'f'::bpchar                                                            AS is_delayed_scan,
             0                                                                      AS rows_pre_filter,
             split_part(stcs_window.__path::text, '/'::text, 10)::character varying AS burst_cluster
      FROM stcs_window
      WHERE stcs_window.__cluster_type = 'cs'::bpchar
        AND to_date(stcs_window.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)) stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster = stcs.burst_cluster::bpchar
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       stcs.userid = "current_user_id"());

alter table svcs_query_report
    owner to rdsdb;

