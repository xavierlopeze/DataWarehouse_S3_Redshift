create view stl_comm_rexmit
            (process, recordtime, cmd_code, seqnum, channel, src_slice, dst_slice, len, is_bcast, ack_reply, ack_xon,
             sync_msg, fragment, rexmit_count)
as
SELECT stll_comm_rexmit.process,
       stll_comm_rexmit.recordtime,
       stll_comm_rexmit.cmd_code,
       stll_comm_rexmit.seqnum,
       stll_comm_rexmit.channel,
       stll_comm_rexmit.src_slice,
       stll_comm_rexmit.dst_slice,
       stll_comm_rexmit.len,
       stll_comm_rexmit.is_bcast,
       stll_comm_rexmit.ack_reply,
       stll_comm_rexmit.ack_xon,
       stll_comm_rexmit.sync_msg,
       stll_comm_rexmit.fragment,
       stll_comm_rexmit.rexmit_count
FROM stll_comm_rexmit;

alter table stl_comm_rexmit
    owner to rdsdb;

