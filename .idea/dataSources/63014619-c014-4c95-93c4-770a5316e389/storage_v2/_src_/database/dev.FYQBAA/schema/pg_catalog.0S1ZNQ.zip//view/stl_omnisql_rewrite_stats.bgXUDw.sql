create view stl_omnisql_rewrite_stats
            (query, time, rules, result, pid, xid, translation, printing, reparsing, initial_sexp, rewritten_sexp,
             starttime, endtime, trivial_rules, failed_rules, module, peak_mem_kb)
as
SELECT stll_omnisql_rewrite_stats.query,
       stll_omnisql_rewrite_stats."time",
       stll_omnisql_rewrite_stats.rules,
       stll_omnisql_rewrite_stats."result",
       stll_omnisql_rewrite_stats.pid,
       stll_omnisql_rewrite_stats.xid,
       stll_omnisql_rewrite_stats.translation,
       stll_omnisql_rewrite_stats.printing,
       stll_omnisql_rewrite_stats.reparsing,
       stll_omnisql_rewrite_stats.initial_sexp,
       stll_omnisql_rewrite_stats.rewritten_sexp,
       stll_omnisql_rewrite_stats.starttime,
       stll_omnisql_rewrite_stats.endtime,
       stll_omnisql_rewrite_stats.trivial_rules,
       stll_omnisql_rewrite_stats.failed_rules,
       stll_omnisql_rewrite_stats.module,
       stll_omnisql_rewrite_stats.peak_mem_kb
FROM stll_omnisql_rewrite_stats;

alter table stl_omnisql_rewrite_stats
    owner to rdsdb;

