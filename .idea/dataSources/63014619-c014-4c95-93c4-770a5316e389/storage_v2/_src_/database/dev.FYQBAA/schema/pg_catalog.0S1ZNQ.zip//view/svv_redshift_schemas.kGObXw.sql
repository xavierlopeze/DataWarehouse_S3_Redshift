create view svv_redshift_schemas (database_name, schema_name, schema_owner, schema_type, schema_acl, schema_option) as
SELECT btrim(current_database()::text)::character varying(128)        AS database_name,
       btrim(pgn.nspname::text)::character varying(128)               AS schema_name,
       pgn.nspowner                                                   AS schema_owner,
       'local'::character varying::character varying(128)             AS schema_type,
       array_to_string(pgn.nspacl, '~'::text)::character varying(128) AS schema_acl,
       ''                                                             AS schema_option
FROM pg_namespace pgn
         LEFT JOIN svv_external_schemas ses ON pgn.nspname = ses.schemaname
WHERE ses.eskind IS NULL
  AND has_schema_privilege("current_user"()::name, pgn.nspname::text, 'USAGE'::text)
  AND pgn.nspname <> 'catalog_history'::name
  AND pgn.nspname <> 'pg_toast'::name
  AND pgn.nspname <> 'pg_internal'::name
  AND pgn.nspname !~~ 'pg_temp%'::text
UNION ALL
SELECT btrim(rs_schemas.database_name::text)::character varying(128) AS database_name,
       btrim(rs_schemas.schema_name::text)::character varying(128)   AS schema_name,
       rs_schemas.schema_owner,
       btrim(rs_schemas.schema_type::text)::character varying(128)   AS schema_type,
       btrim(rs_schemas.schema_acl::text)::character varying(128)    AS schema_acl,
       btrim(rs_schemas.schema_option::text)::character varying(128) AS schema_option
FROM pg_get_shared_redshift_schemas() rs_schemas(database_name character varying, schema_name character varying,
                                                 schema_owner integer, schema_type character varying,
                                                 schema_acl character varying, schema_option character varying);

alter table svv_redshift_schemas
    owner to rdsdb;

grant select on svv_redshift_schemas to public;

