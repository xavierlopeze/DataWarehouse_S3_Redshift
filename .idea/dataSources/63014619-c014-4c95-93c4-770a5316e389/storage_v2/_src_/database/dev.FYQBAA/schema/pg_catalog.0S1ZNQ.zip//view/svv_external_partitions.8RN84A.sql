create view svv_external_partitions
            (schemaname, tablename, values, location, input_format, output_format, serialization_lib, serde_parameters,
             compressed, parameters)
as
SELECT btrim(stv_external_partitions.schemaname::text)        AS schemaname,
       btrim(stv_external_partitions.tablename::text)         AS tablename,
       btrim(stv_external_partitions."values"::text)          AS "values",
       btrim(stv_external_partitions."location"::text)        AS "location",
       btrim(stv_external_partitions.input_format::text)      AS input_format,
       btrim(stv_external_partitions.output_format::text)     AS output_format,
       btrim(stv_external_partitions.serialization_lib::text) AS serialization_lib,
       btrim(stv_external_partitions.serde_parameters::text)  AS serde_parameters,
       stv_external_partitions.compressed,
       btrim(stv_external_partitions."parameters"::text)      AS "parameters"
FROM stv_external_partitions
ORDER BY btrim(stv_external_partitions.schemaname::text), btrim(stv_external_partitions.tablename::text),
         btrim(stv_external_partitions."values"::text);

alter table svv_external_partitions
    owner to rdsdb;

grant select on svv_external_partitions to public;

