create view stl_datashare_request_producer
            (userid, pid, requestid, sb_version, dbtype, dbid, shareid, sharename, api_call, obj_type, obj_oid,
             obj_name, starttime, endtime, status, message, consumeraccountid, consumernamespace,
             consumer_transaction_uid)
as
SELECT stll_datashare_request_producer.userid,
       stll_datashare_request_producer.pid,
       stll_datashare_request_producer.requestid,
       stll_datashare_request_producer.sb_version,
       stll_datashare_request_producer.dbtype,
       stll_datashare_request_producer.dbid,
       stll_datashare_request_producer.shareid,
       stll_datashare_request_producer.sharename,
       stll_datashare_request_producer.api_call,
       stll_datashare_request_producer.obj_type,
       stll_datashare_request_producer.obj_oid,
       stll_datashare_request_producer.obj_name,
       stll_datashare_request_producer.starttime,
       stll_datashare_request_producer.endtime,
       stll_datashare_request_producer.status,
       stll_datashare_request_producer.message,
       stll_datashare_request_producer.consumeraccountid,
       stll_datashare_request_producer.consumernamespace,
       stll_datashare_request_producer.consumer_transaction_uid
FROM stll_datashare_request_producer;

alter table stl_datashare_request_producer
    owner to rdsdb;

