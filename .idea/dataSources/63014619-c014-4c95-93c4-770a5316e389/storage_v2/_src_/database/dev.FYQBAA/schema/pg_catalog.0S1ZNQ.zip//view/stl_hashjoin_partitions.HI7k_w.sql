create view stl_hashjoin_partitions
            (query, slice, segment, step, part_num, num_blocks, hash_loops, switched_parts, input_card, output_card) as
SELECT stll_hashjoin_partitions.query,
       stll_hashjoin_partitions.slice,
       stll_hashjoin_partitions.segment,
       stll_hashjoin_partitions.step,
       stll_hashjoin_partitions.part_num,
       stll_hashjoin_partitions.num_blocks,
       stll_hashjoin_partitions.hash_loops,
       stll_hashjoin_partitions.switched_parts,
       stll_hashjoin_partitions.input_card,
       stll_hashjoin_partitions.output_card
FROM stll_hashjoin_partitions;

alter table stl_hashjoin_partitions
    owner to rdsdb;

