create view stl_io_perf(ip, file_size, block_size, num_disks, bytes_per_microsec) as
SELECT stll_io_perf.ip,
       stll_io_perf.file_size,
       stll_io_perf.block_size,
       stll_io_perf.num_disks,
       stll_io_perf.bytes_per_microsec
FROM stll_io_perf;

alter table stl_io_perf
    owner to rdsdb;

