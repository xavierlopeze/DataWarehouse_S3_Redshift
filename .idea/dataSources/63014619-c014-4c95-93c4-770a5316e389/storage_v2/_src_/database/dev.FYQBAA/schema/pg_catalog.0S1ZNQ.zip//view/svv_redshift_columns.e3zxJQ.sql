create view svv_redshift_columns
            (database_name, schema_name, table_name, column_name, ordinal_position, data_type, column_default,
             is_nullable, encoding, distkey, sortkey, column_acl, remarks)
as
(SELECT current_database()::character varying(128)                            AS database_name,
        pns.nspname::character varying(128)                                   AS schema_name,
        pgc.relname::character varying(128)                                   AS table_name,
        pga.attname::character varying(128)                                   AS column_name,
        pga.attnum                                                            AS ordinal_position,
        format_type(pga.atttypid, pga.atttypmod)::character varying           AS data_type,
        ad.adsrc::character varying(4000)                                     AS column_default,
        CASE
            WHEN pga.attnotnull THEN 'NO'::text
            ELSE 'YES'::text
            END::character varying(3)                                         AS is_nullable,
        format_encoding(pga.attencodingtype::integer)::character varying(128) AS "encoding",
        pga.attisdistkey                                                      AS "distkey",
        pga.attsortkeyord                                                     AS "sortkey",
        array_to_string(pa.attacl, '~'::text)::character varying(128)         AS column_acl,
        d.description::character varying(256)                                 AS remarks
 FROM pg_attribute pga
          JOIN pg_class pgc ON pga.attrelid = pgc.oid
          JOIN pg_namespace pns ON pns.oid = pgc.relnamespace
          LEFT JOIN pg_attribute_acl pa ON pa.attrelid = pgc.oid AND pa.attnum = pga.attnum
          LEFT JOIN pg_attrdef ad ON pga.attrelid = ad.adrelid AND pga.attnum = ad.adnum
          LEFT JOIN pg_description d ON pgc.oid = d.objoid AND pga.attnum = d.objsubid
 WHERE pga.attnum > 0
   AND NOT pga.attisdropped
   AND (pgc.relkind = 'r'::"char" OR pgc.relkind = 'v'::"char")
   AND has_schema_privilege("current_user"()::name, pns.nspname::text, 'USAGE'::text)
   AND (has_table_privilege("current_user"()::name, pgc.oid, 'SELECT'::text) OR
        has_column_privilege("current_user"()::name, pgc.oid, pga.attnum, 'SELECT'::text))
   AND pns.nspname <> 'catalog_history'::name
   AND pns.nspname <> 'pg_toast'::name
   AND pns.nspname <> 'pg_internal'::name
   AND pns.nspname !~~ 'pg_temp%'::text
 UNION ALL
 SELECT current_database()::character varying(128)     AS database_name,
        lbv_cols."schema"::character varying(128)      AS schema_name,
        lbv_cols.viewname::character varying(128)      AS table_name,
        lbv_cols.colname::character varying(128)       AS column_name,
        lbv_cols.colnum                                AS ordinal_position,
        lbv_cols."type"::character varying(128)        AS data_type,
        ''::character varying::character varying(4000) AS column_default,
        'YES'::character varying::character varying(3) AS is_nullable,
        ''                                             AS "encoding",
        'f'                                            AS "distkey",
        0                                              AS "sortkey",
        ''                                             AS column_acl,
        ''                                             AS remarks
 FROM pg_get_late_binding_view_cols() lbv_cols("schema" name, viewname name, colname name, "type" character varying,
                                               colnum integer)
 WHERE has_schema_privilege("current_user"()::name, lbv_cols."schema"::text, 'USAGE'::text)
   AND has_table_privilege("current_user"()::name, (lbv_cols."schema"::text || '.'::text) || lbv_cols.viewname::text,
                           'SELECT'::text)
   AND lbv_cols."schema" <> 'catalog_history'::name
   AND lbv_cols."schema" <> 'pg_internal'::name
   AND lbv_cols."schema" <> 'pg_toast'::name
   AND lbv_cols."schema" !~~ 'pg_temp%'::text)
UNION ALL
SELECT btrim(rs_cols.database_name::text)::character varying(128)   AS database_name,
       btrim(rs_cols.schema_name::text)::character varying(128)     AS schema_name,
       btrim(rs_cols.table_name::text)::character varying(128)      AS table_name,
       btrim(rs_cols.column_name::text)::character varying(128)     AS column_name,
       rs_cols.column_number                                        AS ordinal_position,
       btrim(rs_cols.data_type::text)::character varying(128)       AS data_type,
       btrim(rs_cols.column_default::text)::character varying(4000) AS column_default,
       CASE
           WHEN rs_cols.is_nullable THEN 'YES'::text
           ELSE 'NO'::text
           END::character varying(3)                                AS is_nullable,
       btrim(rs_cols."compression"::text)::character varying(128)   AS "encoding",
       rs_cols.is_dist_key                                          AS "distkey",
       rs_cols.sort_key                                             AS "sortkey",
       btrim(rs_cols.column_acl::text)::character varying(128)      AS column_acl,
       btrim(rs_cols.remarks::text)::character varying(256)         AS remarks
FROM pg_get_shared_redshift_columns() rs_cols(database_name character varying, schema_name character varying,
                                              table_name character varying, column_name character varying,
                                              column_number integer, data_type character varying,
                                              column_default character varying, is_nullable boolean,
                                              "compression" character varying, is_dist_key boolean, sort_key integer,
                                              column_acl character varying, remarks character varying)
ORDER BY 1, 2, 3, 5;

alter table svv_redshift_columns
    owner to rdsdb;

grant select on svv_redshift_columns to public;

