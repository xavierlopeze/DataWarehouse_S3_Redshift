create view svl_datashare_usage_producer
            (share_id, share_name, request_id, request_type, object_type, object_oid, object_name, consumer_account,
             consumer_namespace, consumer_transaction_uid, recordtime, status, error)
as
SELECT stl_datashare_request_producer.shareid                                         AS share_id,
       btrim(stl_datashare_request_producer.sharename::text)::character varying(128)  AS share_name,
       stl_datashare_request_producer.requestid::character varying(50)                AS request_id,
       CASE
           WHEN stl_datashare_request_producer.api_call = 5
               THEN 'GET FUNCTION'::character varying::character varying(25)
           ELSE 'GET RELATION'::character varying::character varying(25)
           END                                                                        AS request_type,
       CASE
           WHEN stl_datashare_request_producer.obj_type = 2 THEN 'TABLE'::text
           WHEN stl_datashare_request_producer.obj_type = 3 THEN 'VIEW'::text
           WHEN stl_datashare_request_producer.obj_type = 4 THEN 'LATE BINDING VIEW'::text
           WHEN stl_datashare_request_producer.obj_type = 5 THEN 'MATERIALIZED VIEW'::text
           WHEN stl_datashare_request_producer.obj_type = 6 THEN 'FUNCTION'::text
           ELSE 'UNKNOWN'::text
           END::character varying(64)                                                 AS object_type,
       stl_datashare_request_producer.obj_oid                                         AS object_oid,
       btrim(stl_datashare_request_producer.obj_name::text)::character varying(128)   AS object_name,
       stl_datashare_request_producer.consumeraccountid::character varying(16)        AS consumer_account,
       stl_datashare_request_producer.consumernamespace::character varying(64)        AS consumer_namespace,
       stl_datashare_request_producer.consumer_transaction_uid::character varying(50) AS consumer_transaction_uid,
       stl_datashare_request_producer.endtime                                         AS recordtime,
       stl_datashare_request_producer.status,
       stl_datashare_request_producer.message::character varying(512)                 AS error
FROM stl_datashare_request_producer
WHERE stl_datashare_request_producer.shareid <> 0
  AND stl_datashare_request_producer.api_call >= 2
  AND stl_datashare_request_producer.api_call <= 5;

alter table svl_datashare_usage_producer
    owner to rdsdb;

grant select on svl_datashare_usage_producer to public;

