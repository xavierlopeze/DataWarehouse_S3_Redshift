create view stl_merge (userid, query, slice, segment, step, starttime, endtime, tasknum, rows) as
SELECT stll_merge.userid,
       stll_merge.query,
       stll_merge.slice,
       stll_merge.segment,
       stll_merge.step,
       stll_merge.starttime,
       stll_merge.endtime,
       stll_merge.tasknum,
       stll_merge."rows"
FROM stll_merge;

alter table stl_merge
    owner to rdsdb;

grant select on stl_merge to public;

