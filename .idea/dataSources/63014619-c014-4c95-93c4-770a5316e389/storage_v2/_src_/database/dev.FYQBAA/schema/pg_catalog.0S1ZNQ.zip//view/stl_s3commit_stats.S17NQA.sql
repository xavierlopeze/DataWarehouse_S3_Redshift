create view stl_s3commit_stats
            (xid, node, start_time, end_time, s3_write_untagged_latency, s3_write_add_tag_latency,
             s3_write_delete_tag_latency, num_untagged_s3_writes, num_add_tags_issued_to_s3,
             num_delete_tags_issued_to_s3, dynamo_write_avg_latency_usec, synced_commits_to_s3, s3commit_enable_latency,
             s3commit_disable_latency, dynamo_get_avg_latency_usec, num_tossed_guids, num_tombstoned_guids,
             num_untagged_untracked)
as
SELECT stll_s3commit_stats.xid,
       stll_s3commit_stats.node,
       stll_s3commit_stats.start_time,
       stll_s3commit_stats.end_time,
       stll_s3commit_stats.s3_write_untagged_latency,
       stll_s3commit_stats.s3_write_add_tag_latency,
       stll_s3commit_stats.s3_write_delete_tag_latency,
       stll_s3commit_stats.num_untagged_s3_writes,
       stll_s3commit_stats.num_add_tags_issued_to_s3,
       stll_s3commit_stats.num_delete_tags_issued_to_s3,
       stll_s3commit_stats.dynamo_write_avg_latency_usec,
       stll_s3commit_stats.synced_commits_to_s3,
       stll_s3commit_stats.s3commit_enable_latency,
       stll_s3commit_stats.s3commit_disable_latency,
       stll_s3commit_stats.dynamo_get_avg_latency_usec,
       stll_s3commit_stats.num_tossed_guids,
       stll_s3commit_stats.num_tombstoned_guids,
       stll_s3commit_stats.num_untagged_untracked
FROM stll_s3commit_stats;

alter table stl_s3commit_stats
    owner to rdsdb;

