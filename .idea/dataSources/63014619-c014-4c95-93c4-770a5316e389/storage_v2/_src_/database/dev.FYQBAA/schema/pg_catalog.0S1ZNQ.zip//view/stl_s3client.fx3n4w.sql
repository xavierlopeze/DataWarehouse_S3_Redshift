create view stl_s3client
            (userid, query, slice, recordtime, pid, http_method, s3_action, bucket, key, transfer_size, data_size,
             start_time, end_time, transfer_time, compression_time, connect_time, app_connect_time, retries, request_id,
             extended_request_id, ip_address, thread_id, original_start_time_us, total_transfer_time_us_with_retries,
             node, tbl_id, one_perm_rep, flags, s3_write_type, is_s3commit_write, is_partial, start_offset)
as
SELECT stll_s3client.userid,
       stll_s3client.query,
       stll_s3client.slice,
       stll_s3client.recordtime,
       stll_s3client.pid,
       stll_s3client.http_method,
       stll_s3client.s3_action,
       stll_s3client.bucket,
       stll_s3client."key",
       stll_s3client.transfer_size,
       stll_s3client.data_size,
       stll_s3client.start_time,
       stll_s3client.end_time,
       stll_s3client.transfer_time,
       stll_s3client.compression_time,
       stll_s3client.connect_time,
       stll_s3client.app_connect_time,
       stll_s3client.retries,
       stll_s3client.request_id,
       stll_s3client.extended_request_id,
       stll_s3client.ip_address,
       stll_s3client.thread_id,
       stll_s3client.original_start_time_us,
       stll_s3client.total_transfer_time_us_with_retries,
       stll_s3client.node,
       stll_s3client.tbl_id,
       stll_s3client.one_perm_rep,
       stll_s3client.flags,
       stll_s3client.s3_write_type,
       stll_s3client.is_s3commit_write,
       stll_s3client.is_partial,
       stll_s3client.start_offset
FROM stll_s3client;

alter table stl_s3client
    owner to rdsdb;

grant select on stl_s3client to public;

