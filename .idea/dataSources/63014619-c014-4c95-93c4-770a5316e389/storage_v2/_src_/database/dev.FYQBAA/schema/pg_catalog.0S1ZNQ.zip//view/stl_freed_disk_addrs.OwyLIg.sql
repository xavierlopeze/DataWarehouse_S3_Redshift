create view stl_freed_disk_addrs(recordtime, context, owner, host, diskno, disk_addr) as
SELECT stll_freed_disk_addrs.recordtime,
       stll_freed_disk_addrs.context,
       stll_freed_disk_addrs."owner",
       stll_freed_disk_addrs."host",
       stll_freed_disk_addrs.diskno,
       stll_freed_disk_addrs.disk_addr
FROM stll_freed_disk_addrs;

alter table stl_freed_disk_addrs
    owner to rdsdb;

