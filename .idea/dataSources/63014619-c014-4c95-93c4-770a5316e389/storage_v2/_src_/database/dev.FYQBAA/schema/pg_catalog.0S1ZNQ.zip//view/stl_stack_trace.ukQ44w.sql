create view stl_stack_trace(node, pid, process, frame, address, instruction) as
SELECT stll_stack_trace.node,
       stll_stack_trace.pid,
       stll_stack_trace.process,
       stll_stack_trace.frame,
       stll_stack_trace.address,
       stll_stack_trace.instruction
FROM stll_stack_trace;

alter table stl_stack_trace
    owner to rdsdb;

