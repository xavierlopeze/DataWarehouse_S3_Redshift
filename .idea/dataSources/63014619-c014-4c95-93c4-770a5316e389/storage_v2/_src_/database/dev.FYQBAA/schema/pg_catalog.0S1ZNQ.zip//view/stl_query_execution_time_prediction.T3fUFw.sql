create view stl_query_execution_time_prediction(query, xid, predicted_exec_time, predicted_exec_time_error_boundary) as
SELECT stll_query_execution_time_prediction.query,
       stll_query_execution_time_prediction.xid,
       stll_query_execution_time_prediction.predicted_exec_time,
       stll_query_execution_time_prediction.predicted_exec_time_error_boundary
FROM stll_query_execution_time_prediction;

alter table stl_query_execution_time_prediction
    owner to rdsdb;

