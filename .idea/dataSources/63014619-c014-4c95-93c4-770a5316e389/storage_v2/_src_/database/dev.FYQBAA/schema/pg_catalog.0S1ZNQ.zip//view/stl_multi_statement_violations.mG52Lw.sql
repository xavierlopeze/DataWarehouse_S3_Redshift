create view stl_multi_statement_violations(userid, database, cmdname, xid, pid, eventtime, padb_version) as
SELECT stll_multi_statement_violations.userid,
       stll_multi_statement_violations."database",
       stll_multi_statement_violations.cmdname,
       stll_multi_statement_violations.xid,
       stll_multi_statement_violations.pid,
       stll_multi_statement_violations.eventtime,
       stll_multi_statement_violations.padb_version
FROM stll_multi_statement_violations;

alter table stl_multi_statement_violations
    owner to rdsdb;

grant select on stl_multi_statement_violations to public;

