create view stl_restarted_sessions_internal
            (currenttime, is_reforkable, temp_tbl_created, named_prep_stmt_ct, unnamed_stmt_ct, in_xact_blk,
             is_read_only, is_single_stmt_query, conn_state, pid, in_authentication, is_bootstrap, is_restarted_session,
             is_extended_protocol, is_idle_connection, current_executing_command, is_ssl_compressed, is_protocol_v3,
             are_commands_repeated, unsupported_command_sequence, can_reissue_query, parked_state_in_proxy,
             session_size, is_inc_resize)
as
SELECT stll_restarted_sessions_internal.currenttime,
       stll_restarted_sessions_internal.is_reforkable,
       stll_restarted_sessions_internal.temp_tbl_created,
       stll_restarted_sessions_internal.named_prep_stmt_ct,
       stll_restarted_sessions_internal.unnamed_stmt_ct,
       stll_restarted_sessions_internal.in_xact_blk,
       stll_restarted_sessions_internal.is_read_only,
       stll_restarted_sessions_internal.is_single_stmt_query,
       stll_restarted_sessions_internal.conn_state,
       stll_restarted_sessions_internal.pid,
       stll_restarted_sessions_internal.in_authentication,
       stll_restarted_sessions_internal.is_bootstrap,
       stll_restarted_sessions_internal.is_restarted_session,
       stll_restarted_sessions_internal.is_extended_protocol,
       stll_restarted_sessions_internal.is_idle_connection,
       stll_restarted_sessions_internal.current_executing_command,
       stll_restarted_sessions_internal.is_ssl_compressed,
       stll_restarted_sessions_internal.is_protocol_v3,
       stll_restarted_sessions_internal.are_commands_repeated,
       stll_restarted_sessions_internal.unsupported_command_sequence,
       stll_restarted_sessions_internal.can_reissue_query,
       stll_restarted_sessions_internal.parked_state_in_proxy,
       stll_restarted_sessions_internal.session_size,
       stll_restarted_sessions_internal.is_inc_resize
FROM stll_restarted_sessions_internal;

alter table stl_restarted_sessions_internal
    owner to rdsdb;

