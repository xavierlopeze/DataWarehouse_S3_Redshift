create view stl_undo_transactions(recordtime, table_id, tables_done, tables_total, table_name) as
SELECT stll_undo_transactions.recordtime,
       stll_undo_transactions.table_id,
       stll_undo_transactions.tables_done,
       stll_undo_transactions.tables_total,
       stll_undo_transactions.table_name
FROM stll_undo_transactions;

alter table stl_undo_transactions
    owner to rdsdb;

