create view stl_load_trace(userid, query, slice, recordtime, pid, name, bytes_scanned, message) as
SELECT stll_load_trace.userid,
       stll_load_trace.query,
       stll_load_trace.slice,
       stll_load_trace.recordtime,
       stll_load_trace.pid,
       stll_load_trace.name,
       stll_load_trace.bytes_scanned,
       stll_load_trace.message
FROM stll_load_trace;

alter table stl_load_trace
    owner to rdsdb;

grant select on stl_load_trace to public;

