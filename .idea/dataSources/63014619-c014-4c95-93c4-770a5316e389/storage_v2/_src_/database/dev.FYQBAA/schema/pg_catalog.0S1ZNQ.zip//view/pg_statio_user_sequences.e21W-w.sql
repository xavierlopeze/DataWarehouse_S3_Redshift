create view pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) as
SELECT pg_statio_all_sequences.relid,
       pg_statio_all_sequences.schemaname,
       pg_statio_all_sequences.relname,
       pg_statio_all_sequences.blks_read,
       pg_statio_all_sequences.blks_hit
FROM pg_statio_all_sequences
WHERE pg_statio_all_sequences.schemaname <> 'pg_catalog'::name
  AND pg_statio_all_sequences.schemaname <> 'pg_toast'::name
  AND pg_statio_all_sequences.schemaname <> 'information_schema'::name;

alter table pg_statio_user_sequences
    owner to rdsdb;

grant select on pg_statio_user_sequences to public;

