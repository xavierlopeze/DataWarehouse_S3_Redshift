create view svl_federated_query
            (userid, xid, pid, query, sourcetype, recordtime, querytext, num_rows, num_bytes, duration) as
SELECT stl_federated_query.userid,
       stl_federated_query.xid,
       stl_federated_query.pid,
       stl_federated_query.query,
       stl_federated_query.sourcetype,
       stl_federated_query.recordtime,
       stl_federated_query.querytext,
       stl_federated_query.num_rows,
       stl_federated_query.num_bytes,
       stl_federated_query.duration
FROM stl_federated_query;

alter table svl_federated_query
    owner to rdsdb;

grant select on svl_federated_query to public;

