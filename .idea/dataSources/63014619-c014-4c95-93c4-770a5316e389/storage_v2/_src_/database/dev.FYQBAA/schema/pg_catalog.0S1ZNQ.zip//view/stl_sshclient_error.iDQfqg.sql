create view stl_sshclient_error (userid, query, sliceid, recordtime, pid, ssh_username, endpoint, command, error) as
SELECT stll_sshclient_error.userid,
       stll_sshclient_error.query,
       stll_sshclient_error.sliceid,
       stll_sshclient_error.recordtime,
       stll_sshclient_error.pid,
       stll_sshclient_error.ssh_username,
       stll_sshclient_error.endpoint,
       stll_sshclient_error.command,
       stll_sshclient_error.error
FROM stll_sshclient_error;

alter table stl_sshclient_error
    owner to rdsdb;

grant select on stl_sshclient_error to public;

