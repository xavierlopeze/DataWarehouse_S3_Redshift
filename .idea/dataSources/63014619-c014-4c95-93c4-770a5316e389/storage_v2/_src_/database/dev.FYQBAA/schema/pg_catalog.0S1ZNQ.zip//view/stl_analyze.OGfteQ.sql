create view stl_analyze
            (userid, xid, database, table_id, status, rows, modified_rows, threshold_percent, is_auto, starttime,
             endtime, prevtime, num_predicate_cols, num_new_predicate_cols, is_background, auto_analyze_phase)
as
SELECT stll_analyze.userid,
       stll_analyze.xid,
       stll_analyze."database",
       stll_analyze.table_id,
       stll_analyze.status,
       stll_analyze."rows",
       stll_analyze.modified_rows,
       stll_analyze.threshold_percent,
       stll_analyze.is_auto,
       stll_analyze.starttime,
       stll_analyze.endtime,
       stll_analyze.prevtime,
       stll_analyze.num_predicate_cols,
       stll_analyze.num_new_predicate_cols,
       stll_analyze.is_background,
       stll_analyze.auto_analyze_phase
FROM stll_analyze;

alter table stl_analyze
    owner to rdsdb;

