create view stl_compile_info
            (userid, xid, pid, query, segment, locus, starttime, endtime, bytes, path, compile, complevel, cachehit,
             tokwaittime, compilestarttime, compileendtime, compilelocktime, compilememory, getsuccess, gettime,
             objsize, skip_opt_compile, replace_obj_status)
as
SELECT stll_compile_info.userid,
       stll_compile_info.xid,
       stll_compile_info.pid,
       stll_compile_info.query,
       stll_compile_info.segment,
       stll_compile_info.locus,
       stll_compile_info.starttime,
       stll_compile_info.endtime,
       stll_compile_info.bytes,
       stll_compile_info."path",
       stll_compile_info.compile,
       stll_compile_info.complevel,
       stll_compile_info.cachehit,
       stll_compile_info.tokwaittime,
       stll_compile_info.compilestarttime,
       stll_compile_info.compileendtime,
       stll_compile_info.compilelocktime,
       stll_compile_info.compilememory,
       stll_compile_info.getsuccess,
       stll_compile_info.gettime,
       stll_compile_info.objsize,
       stll_compile_info.skip_opt_compile,
       stll_compile_info.replace_obj_status
FROM stll_compile_info;

alter table stl_compile_info
    owner to rdsdb;

