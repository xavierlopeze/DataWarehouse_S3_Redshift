create view stl_mutex_contention(process, type, attempts, waitpid, starttime, endtime) as
SELECT stll_mutex_contention.process,
       stll_mutex_contention."type",
       stll_mutex_contention.attempts,
       stll_mutex_contention.waitpid,
       stll_mutex_contention.starttime,
       stll_mutex_contention.endtime
FROM stll_mutex_contention;

alter table stl_mutex_contention
    owner to rdsdb;

