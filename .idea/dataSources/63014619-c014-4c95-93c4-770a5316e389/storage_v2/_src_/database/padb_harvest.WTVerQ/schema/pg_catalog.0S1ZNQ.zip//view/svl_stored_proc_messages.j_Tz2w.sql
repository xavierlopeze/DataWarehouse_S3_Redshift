create view svl_stored_proc_messages
            (userid, session_userid, pid, xid, query, recordtime, loglevel, loglevel_text, message, linenum, querytxt,
             label, aborted)
as
SELECT spcm.userid,
       spc.session_userid,
       spc.pid,
       spc.xid,
       spcm.query,
       spcm.recordtime,
       spcm.loglevel,
       CASE
           WHEN spcm.loglevel = 10 THEN 'DEBUG'::text
           WHEN spcm.loglevel = 20 THEN 'LOG'::text
           WHEN spcm.loglevel = 30 THEN 'INFO'::text
           WHEN spcm.loglevel = 40 THEN 'NOTICE'::text
           WHEN spcm.loglevel = 50 THEN 'WARNING'::text
           WHEN spcm.loglevel = 60 THEN 'EXCEPTION'::text
           ELSE NULL::text
           END AS loglevel_text,
       spcm.message,
       spcm.linenum,
       spc.querytxt,
       spc."label",
       spc.aborted
FROM stl_stored_proc_messages spcm
         LEFT JOIN stl_stored_proc_call spc ON spcm.query = spc.query;

alter table svl_stored_proc_messages
    owner to rdsdb;

grant select on svl_stored_proc_messages to public;

