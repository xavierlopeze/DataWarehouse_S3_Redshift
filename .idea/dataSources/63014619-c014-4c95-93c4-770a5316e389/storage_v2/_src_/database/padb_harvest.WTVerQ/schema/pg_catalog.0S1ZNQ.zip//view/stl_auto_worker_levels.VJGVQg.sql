create view stl_auto_worker_levels
            (pid, start_level, end_level, start_wlm_occupancy, end_wlm_occupancy, num_windows, since, now, status) as
SELECT stll_auto_worker_levels.pid,
       stll_auto_worker_levels.start_level,
       stll_auto_worker_levels.end_level,
       stll_auto_worker_levels.start_wlm_occupancy,
       stll_auto_worker_levels.end_wlm_occupancy,
       stll_auto_worker_levels.num_windows,
       stll_auto_worker_levels.since,
       stll_auto_worker_levels.now,
       stll_auto_worker_levels.status
FROM stll_auto_worker_levels;

alter table stl_auto_worker_levels
    owner to rdsdb;

