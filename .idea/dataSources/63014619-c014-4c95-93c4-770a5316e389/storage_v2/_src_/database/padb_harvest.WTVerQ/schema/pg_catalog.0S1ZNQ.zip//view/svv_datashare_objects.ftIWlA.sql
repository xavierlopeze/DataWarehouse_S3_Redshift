create view svv_datashare_objects
            (share_type, share_name, object_type, object_name, producer_account, producer_namespace, include_new) as
SELECT 'OUTBOUND'                                                 AS share_type,
       outbound_objects.share_name::character varying(128)        AS share_name,
       outbound_objects.object_type::character varying(64)        AS object_type,
       outbound_objects.object_name::character varying(512)       AS object_name,
       outbound_objects.producer_account::character varying(16)   AS producer_account,
       outbound_objects.producer_namespace::character varying(64) AS producer_namespace,
       CASE
           WHEN outbound_objects.object_type::text = 'schema'::text THEN outbound_objects.include_new
           ELSE NULL::boolean
           END                                                    AS include_new
FROM pg_get_outbound_datashare_objects() outbound_objects(share_name character varying, object_type character varying,
                                                          object_name character varying,
                                                          producer_account character varying,
                                                          producer_namespace character varying, include_new boolean)
UNION ALL
SELECT 'INBOUND'                                                  AS share_type,
       incoming_objects.share_name::character varying(128)        AS share_name,
       incoming_objects.object_type::character varying(64)        AS object_type,
       incoming_objects.object_name::character varying(512)       AS object_name,
       incoming_objects.producer_account::character varying(16)   AS producer_account,
       incoming_objects.producer_namespace::character varying(64) AS producer_namespace,
       NULL::"unknown"                                            AS include_new
FROM pg_get_inbound_datashare_objects() incoming_objects(share_name character varying, object_type character varying,
                                                         object_name character varying,
                                                         producer_account character varying,
                                                         producer_namespace character varying);

alter table svv_datashare_objects
    owner to rdsdb;

grant select on svv_datashare_objects to public;

