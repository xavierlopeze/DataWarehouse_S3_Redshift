create view stl_federated_calls
            (userid, xid, pid, query, sourcetype, segment, slice, recordtime, calltype, duration, querytext,
             on_leader) as
SELECT stll_federated_calls.userid,
       stll_federated_calls.xid,
       stll_federated_calls.pid,
       stll_federated_calls.query,
       stll_federated_calls.sourcetype,
       stll_federated_calls.segment,
       stll_federated_calls.slice,
       stll_federated_calls.recordtime,
       stll_federated_calls.calltype,
       stll_federated_calls.duration,
       stll_federated_calls.querytext,
       stll_federated_calls.on_leader
FROM stll_federated_calls;

alter table stl_federated_calls
    owner to rdsdb;

