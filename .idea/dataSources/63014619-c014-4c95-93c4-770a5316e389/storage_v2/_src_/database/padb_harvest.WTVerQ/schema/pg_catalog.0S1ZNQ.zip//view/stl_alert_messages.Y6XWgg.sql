create view stl_alert_messages
            (eventtime, pid, error, code, context, query, file, linenumber, process, padb, tracefile) as
SELECT stll_alert_messages.eventtime,
       stll_alert_messages.pid,
       stll_alert_messages.error,
       stll_alert_messages.code,
       stll_alert_messages.context,
       stll_alert_messages.query,
       stll_alert_messages."file",
       stll_alert_messages.linenumber,
       stll_alert_messages.process,
       stll_alert_messages.padb,
       stll_alert_messages.tracefile
FROM stll_alert_messages;

alter table stl_alert_messages
    owner to rdsdb;

