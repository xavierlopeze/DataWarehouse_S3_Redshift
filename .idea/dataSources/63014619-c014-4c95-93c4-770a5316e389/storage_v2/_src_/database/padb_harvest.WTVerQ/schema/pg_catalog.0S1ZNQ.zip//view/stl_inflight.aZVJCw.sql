create view stl_inflight
            (userid, logtime, slice, query, label, xid, pid, starttime, text, suspended, insert_pristine, working_mem,
             concurrency_scaling_status)
as
SELECT stll_inflight.userid,
       stll_inflight.logtime,
       stll_inflight.slice,
       stll_inflight.query,
       stll_inflight."label",
       stll_inflight.xid,
       stll_inflight.pid,
       stll_inflight.starttime,
       stll_inflight.text,
       stll_inflight.suspended,
       stll_inflight.insert_pristine,
       stll_inflight.working_mem,
       stll_inflight.concurrency_scaling_status
FROM stll_inflight;

alter table stl_inflight
    owner to rdsdb;

