create view stl_mem_freelist (recordtime, node, slice, type, uid, pid, requested, roundedsize, page, leaked) as
SELECT stll_mem_freelist.recordtime,
       stll_mem_freelist.node,
       stll_mem_freelist.slice,
       stll_mem_freelist."type",
       stll_mem_freelist.uid,
       stll_mem_freelist.pid,
       stll_mem_freelist.requested,
       stll_mem_freelist.roundedsize,
       stll_mem_freelist.page,
       stll_mem_freelist.leaked
FROM stll_mem_freelist;

alter table stl_mem_freelist
    owner to rdsdb;

