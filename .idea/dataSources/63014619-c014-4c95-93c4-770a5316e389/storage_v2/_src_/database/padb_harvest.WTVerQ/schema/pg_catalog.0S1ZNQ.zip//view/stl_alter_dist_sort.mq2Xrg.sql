create view stl_alter_dist_sort
            (xid, cutoff_xid, tbl, event, src_rows, dest_rows, redo_delete_rows, undone_rows, undone_txns, eventtime,
             origin_dist_style, num_sort_keys, target_distkey, request_sort, num_sort_iterations, dst_sorted_rows,
             is_autoworker_altered)
as
SELECT stll_alter_dist_sort.xid,
       stll_alter_dist_sort.cutoff_xid,
       stll_alter_dist_sort.tbl,
       stll_alter_dist_sort.event,
       stll_alter_dist_sort.src_rows,
       stll_alter_dist_sort.dest_rows,
       stll_alter_dist_sort.redo_delete_rows,
       stll_alter_dist_sort.undone_rows,
       stll_alter_dist_sort.undone_txns,
       stll_alter_dist_sort.eventtime,
       stll_alter_dist_sort.origin_dist_style,
       stll_alter_dist_sort.num_sort_keys,
       stll_alter_dist_sort.target_distkey,
       stll_alter_dist_sort.request_sort,
       stll_alter_dist_sort.num_sort_iterations,
       stll_alter_dist_sort.dst_sorted_rows,
       stll_alter_dist_sort.is_autoworker_altered
FROM stll_alter_dist_sort;

alter table stl_alter_dist_sort
    owner to rdsdb;

