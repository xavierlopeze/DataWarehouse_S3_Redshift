create view stl_background_monitor(recordtime, status) as
SELECT stll_background_monitor.recordtime, stll_background_monitor.status
FROM stll_background_monitor;

alter table stl_background_monitor
    owner to rdsdb;

