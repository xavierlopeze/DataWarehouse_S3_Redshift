create view stl_disk_cache_write
            (blocks_pushed, blocks_instant_pushed, avg_lru_size_before_push, push_attempts, pending_writes_push,
             pending_reads_push, blocks_written_back, writeback_preempts, avg_lru_size_before_writeback,
             writeback_attempts, pending_writes_writeback, pending_reads_writeback, avg_push_time_microsec,
             avg_writeback_time_microsec, sample_start_time, sample_end_time, node)
as
SELECT stll_disk_cache_write.blocks_pushed,
       stll_disk_cache_write.blocks_instant_pushed,
       stll_disk_cache_write.avg_lru_size_before_push,
       stll_disk_cache_write.push_attempts,
       stll_disk_cache_write.pending_writes_push,
       stll_disk_cache_write.pending_reads_push,
       stll_disk_cache_write.blocks_written_back,
       stll_disk_cache_write.writeback_preempts,
       stll_disk_cache_write.avg_lru_size_before_writeback,
       stll_disk_cache_write.writeback_attempts,
       stll_disk_cache_write.pending_writes_writeback,
       stll_disk_cache_write.pending_reads_writeback,
       stll_disk_cache_write.avg_push_time_microsec,
       stll_disk_cache_write.avg_writeback_time_microsec,
       stll_disk_cache_write.sample_start_time,
       stll_disk_cache_write.sample_end_time,
       stll_disk_cache_write.node
FROM stll_disk_cache_write;

alter table stl_disk_cache_write
    owner to rdsdb;

