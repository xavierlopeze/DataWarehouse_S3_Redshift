create view svl_query_summary
            (userid, query, stm, seg, step, maxtime, avgtime, rows, bytes, rate_row, rate_byte, label, is_diskbased,
             workmem, is_rrscan, is_delayed_scan, rows_pre_filter)
as
SELECT svl_query_report.userid,
       svl_query_report.query,
       stl_stream_segs.stream                AS stm,
       svl_query_report.segment              AS seg,
       svl_query_report.step,
       "max"(svl_query_report.elapsed_time)  AS maxtime,
       avg(svl_query_report.elapsed_time)    AS avgtime,
       sum(svl_query_report."rows")          AS "rows",
       sum(svl_query_report.bytes)           AS bytes,
       round((sum(svl_query_report."rows") /
              CASE
                  WHEN "date_part"('epoch'::text,
                                   "max"(svl_query_report.end_time - svl_query_report.start_time))::bigint = 0 THEN NULL::bigint
                  ELSE "date_part"('epoch'::text, "max"(svl_query_report.end_time - svl_query_report.start_time))::bigint
                  END)::double precision)    AS rate_row,
       round((sum(svl_query_report.bytes) /
              CASE
                  WHEN "date_part"('epoch'::text,
                                   "max"(svl_query_report.end_time - svl_query_report.start_time))::bigint = 0 THEN NULL::bigint
                  ELSE "date_part"('epoch'::text, "max"(svl_query_report.end_time - svl_query_report.start_time))::bigint
                  END)::double precision)    AS rate_byte,
       svl_query_report."label",
       svl_query_report.is_diskbased,
       sum(svl_query_report.workmem)         AS workmem,
       svl_query_report.is_rrscan,
       svl_query_report.is_delayed_scan,
       sum(svl_query_report.rows_pre_filter) AS rows_pre_filter
FROM svl_query_report,
     stl_stream_segs
WHERE svl_query_report.query = stl_stream_segs.query
  AND svl_query_report.segment = stl_stream_segs.segment
GROUP BY svl_query_report.userid, svl_query_report.query, stl_stream_segs.stream, svl_query_report.segment,
         svl_query_report.step, svl_query_report."label", svl_query_report.is_diskbased, svl_query_report.is_rrscan,
         svl_query_report.is_delayed_scan;

alter table svl_query_summary
    owner to rdsdb;

grant select on svl_query_summary to public;

