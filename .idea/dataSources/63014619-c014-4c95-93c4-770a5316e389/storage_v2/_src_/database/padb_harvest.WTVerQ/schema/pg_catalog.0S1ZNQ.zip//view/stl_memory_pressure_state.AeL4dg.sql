create view stl_memory_pressure_state(now, node, memory_type, state, last_state) as
SELECT stll_memory_pressure_state.now,
       stll_memory_pressure_state.node,
       stll_memory_pressure_state.memory_type,
       stll_memory_pressure_state.state,
       stll_memory_pressure_state.last_state
FROM stll_memory_pressure_state;

alter table stl_memory_pressure_state
    owner to rdsdb;

