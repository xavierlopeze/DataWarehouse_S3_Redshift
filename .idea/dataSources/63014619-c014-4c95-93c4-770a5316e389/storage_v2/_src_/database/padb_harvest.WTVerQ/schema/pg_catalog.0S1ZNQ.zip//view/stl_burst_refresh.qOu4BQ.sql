create view stl_burst_refresh(record_time, node, process, pid, error_code, message) as
SELECT stll_burst_refresh.record_time,
       stll_burst_refresh.node,
       stll_burst_refresh.process,
       stll_burst_refresh.pid,
       stll_burst_refresh.error_code,
       stll_burst_refresh.message
FROM stll_burst_refresh;

alter table stl_burst_refresh
    owner to rdsdb;

