create view stl_comm_pkt_sent_count
            (now, since, src_node, dest_node, is_raidp, bytes, rexmit, xon, reply, ack, packet, fast_rexmit,
             original_ack) as
SELECT stll_comm_pkt_sent_count.now,
       stll_comm_pkt_sent_count.since,
       stll_comm_pkt_sent_count.src_node,
       stll_comm_pkt_sent_count.dest_node,
       stll_comm_pkt_sent_count.is_raidp,
       stll_comm_pkt_sent_count.bytes,
       stll_comm_pkt_sent_count.rexmit,
       stll_comm_pkt_sent_count.xon,
       stll_comm_pkt_sent_count.reply,
       stll_comm_pkt_sent_count.ack,
       stll_comm_pkt_sent_count.packet,
       stll_comm_pkt_sent_count.fast_rexmit,
       stll_comm_pkt_sent_count.original_ack
FROM stll_comm_pkt_sent_count;

alter table stl_comm_pkt_sent_count
    owner to rdsdb;

