create view stl_connection_log
            (event, recordtime, remotehost, remoteport, pid, dbname, username, authmethod, duration, sslversion,
             sslcipher, mtu, sslcompression, sslexpansion, iamauthguid, application_name, os_version, driver_version,
             plugin_name, protocol_version)
as
SELECT stll_connection_log.event,
       stll_connection_log.recordtime,
       stll_connection_log.remotehost,
       stll_connection_log.remoteport,
       stll_connection_log.pid,
       stll_connection_log.dbname,
       stll_connection_log.username,
       stll_connection_log.authmethod,
       stll_connection_log.duration,
       stll_connection_log.sslversion,
       stll_connection_log.sslcipher,
       stll_connection_log.mtu,
       stll_connection_log.sslcompression,
       stll_connection_log.sslexpansion,
       stll_connection_log.iamauthguid,
       stll_connection_log.application_name,
       stll_connection_log.os_version,
       stll_connection_log.driver_version,
       stll_connection_log.plugin_name,
       stll_connection_log.protocol_version
FROM stll_connection_log;

alter table stl_connection_log
    owner to rdsdb;

