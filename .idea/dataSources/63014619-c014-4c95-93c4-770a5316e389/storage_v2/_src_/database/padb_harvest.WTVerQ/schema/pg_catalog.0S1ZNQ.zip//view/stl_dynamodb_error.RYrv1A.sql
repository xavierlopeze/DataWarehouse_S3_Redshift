create view stl_dynamodb_error (userid, qid, process, recordtime, pid, errcode, file, linenum, context, error) as
SELECT stll_dynamodb_error.userid,
       stll_dynamodb_error.qid,
       stll_dynamodb_error.process,
       stll_dynamodb_error.recordtime,
       stll_dynamodb_error.pid,
       stll_dynamodb_error.errcode,
       stll_dynamodb_error."file",
       stll_dynamodb_error.linenum,
       stll_dynamodb_error.context,
       stll_dynamodb_error.error
FROM stll_dynamodb_error;

alter table stl_dynamodb_error
    owner to rdsdb;

