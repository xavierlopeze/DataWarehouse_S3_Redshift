create view stl_wlm_service_class_config
            (service_class, queueing_strategy, num_query_tasks, target_num_query_tasks, evictable, eviction_threshold,
             query_working_mem, target_query_working_mem, min_step_mem, name, max_execution_time, user_group_wild_card,
             query_group_wild_card, concurrency_scaling, query_priority, eventtime)
as
SELECT stll_wlm_service_class_config.service_class,
       stll_wlm_service_class_config.queueing_strategy,
       stll_wlm_service_class_config.num_query_tasks,
       stll_wlm_service_class_config.target_num_query_tasks,
       stll_wlm_service_class_config.evictable,
       stll_wlm_service_class_config.eviction_threshold,
       stll_wlm_service_class_config.query_working_mem,
       stll_wlm_service_class_config.target_query_working_mem,
       stll_wlm_service_class_config.min_step_mem,
       stll_wlm_service_class_config.name,
       stll_wlm_service_class_config.max_execution_time,
       stll_wlm_service_class_config.user_group_wild_card,
       stll_wlm_service_class_config.query_group_wild_card,
       stll_wlm_service_class_config.concurrency_scaling,
       stll_wlm_service_class_config.query_priority,
       stll_wlm_service_class_config.eventtime
FROM stll_wlm_service_class_config;

alter table stl_wlm_service_class_config
    owner to rdsdb;

