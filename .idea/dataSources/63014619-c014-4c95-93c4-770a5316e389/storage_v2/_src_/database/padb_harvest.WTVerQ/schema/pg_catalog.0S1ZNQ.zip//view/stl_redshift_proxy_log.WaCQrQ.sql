create view stl_redshift_proxy_log(time, client_endpoint, event) as
SELECT stll_redshift_proxy_log."time", stll_redshift_proxy_log.client_endpoint, stll_redshift_proxy_log.event
FROM stll_redshift_proxy_log;

alter table stl_redshift_proxy_log
    owner to rdsdb;

