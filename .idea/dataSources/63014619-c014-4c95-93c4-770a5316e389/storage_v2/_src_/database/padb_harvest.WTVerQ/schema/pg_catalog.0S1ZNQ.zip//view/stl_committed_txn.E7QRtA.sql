create view stl_committed_txn(dump_end_time, xid, start_time, end_time, tbl, is_write) as
SELECT stll_committed_txn.dump_end_time,
       stll_committed_txn.xid,
       stll_committed_txn.start_time,
       stll_committed_txn.end_time,
       stll_committed_txn.tbl,
       stll_committed_txn.is_write
FROM stll_committed_txn;

alter table stl_committed_txn
    owner to rdsdb;

