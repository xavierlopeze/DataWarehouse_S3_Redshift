create view stl_smfaults_overflow
            (parent_seq, parent_run, seq, run, mon_type, mon_name, severity, resolution_dbup, resolution_dbdown, code,
             recordtime, observer, culprit, msg, xml_extra, has_measure_val)
as
SELECT stll_smfaults_overflow.parent_seq,
       stll_smfaults_overflow.parent_run,
       stll_smfaults_overflow.seq,
       stll_smfaults_overflow.run,
       stll_smfaults_overflow.mon_type,
       stll_smfaults_overflow.mon_name,
       stll_smfaults_overflow.severity,
       stll_smfaults_overflow.resolution_dbup,
       stll_smfaults_overflow.resolution_dbdown,
       stll_smfaults_overflow.code,
       stll_smfaults_overflow.recordtime,
       stll_smfaults_overflow.observer,
       stll_smfaults_overflow.culprit,
       stll_smfaults_overflow.msg,
       stll_smfaults_overflow.xml_extra,
       stll_smfaults_overflow.has_measure_val
FROM stll_smfaults_overflow;

alter table stl_smfaults_overflow
    owner to rdsdb;

