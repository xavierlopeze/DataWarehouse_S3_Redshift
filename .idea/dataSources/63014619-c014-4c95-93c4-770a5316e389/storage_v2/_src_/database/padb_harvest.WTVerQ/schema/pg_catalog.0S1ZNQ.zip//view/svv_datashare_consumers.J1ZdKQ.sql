create view svv_datashare_consumers(share_name, consumer_account, consumer_namespace, share_date) as
SELECT pd.sharename::character varying(128)         AS share_name,
       dsc.consumeraccount::character varying(16)   AS consumer_account,
       dsc.consumernamespace::character varying(64) AS consumer_namespace,
       dsc.sharedate                                AS share_date
FROM pg_datashare_consumers dsc
         LEFT JOIN pg_datashare pd ON pd.oid = dsc.shareid
WHERE has_datashare_privilege("current_user"()::name, pd.sharename::text);

alter table svv_datashare_consumers
    owner to rdsdb;

grant select on svv_datashare_consumers to public;

