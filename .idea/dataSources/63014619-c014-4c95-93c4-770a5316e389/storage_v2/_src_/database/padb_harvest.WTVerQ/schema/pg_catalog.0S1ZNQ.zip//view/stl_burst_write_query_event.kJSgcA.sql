create view stl_burst_write_query_event
            (pid, xid, query, tbl, event, eventtime, owned_cluster, num_dirty_cluster, structure_change_sb, undo_sb) as
SELECT stll_burst_write_query_event.pid,
       stll_burst_write_query_event.xid,
       stll_burst_write_query_event.query,
       stll_burst_write_query_event.tbl,
       stll_burst_write_query_event.event,
       stll_burst_write_query_event.eventtime,
       stll_burst_write_query_event.owned_cluster,
       stll_burst_write_query_event.num_dirty_cluster,
       stll_burst_write_query_event.structure_change_sb,
       stll_burst_write_query_event.undo_sb
FROM stll_burst_write_query_event;

alter table stl_burst_write_query_event
    owner to rdsdb;

