create view stl_ml_dlr_usage
            (record_time, node, query, slice, pid, model_id, filestore_ids, file_size, mem_used, dlr_version, num_args,
             num_inferences)
as
SELECT stll_ml_dlr_usage.record_time,
       stll_ml_dlr_usage.node,
       stll_ml_dlr_usage.query,
       stll_ml_dlr_usage.slice,
       stll_ml_dlr_usage.pid,
       stll_ml_dlr_usage.model_id,
       stll_ml_dlr_usage.filestore_ids,
       stll_ml_dlr_usage.file_size,
       stll_ml_dlr_usage.mem_used,
       stll_ml_dlr_usage.dlr_version,
       stll_ml_dlr_usage.num_args,
       stll_ml_dlr_usage.num_inferences
FROM stll_ml_dlr_usage;

alter table stl_ml_dlr_usage
    owner to rdsdb;

