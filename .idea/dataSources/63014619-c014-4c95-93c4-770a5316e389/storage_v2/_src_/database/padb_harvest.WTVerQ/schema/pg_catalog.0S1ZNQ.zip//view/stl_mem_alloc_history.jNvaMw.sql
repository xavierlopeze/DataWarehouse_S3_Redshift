create view stl_mem_alloc_history(process, recordtime, node, slice, pid, alloc, address, size, type) as
SELECT stll_mem_alloc_history.process,
       stll_mem_alloc_history.recordtime,
       stll_mem_alloc_history.node,
       stll_mem_alloc_history.slice,
       stll_mem_alloc_history.pid,
       stll_mem_alloc_history.alloc,
       stll_mem_alloc_history.address,
       stll_mem_alloc_history.size,
       stll_mem_alloc_history."type"
FROM stll_mem_alloc_history;

alter table stl_mem_alloc_history
    owner to rdsdb;

