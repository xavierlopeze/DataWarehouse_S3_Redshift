create view stl_burst_write_block_header_trace(xid, query, tbl, node, block_header_rcvd, rcvd_time) as
SELECT stll_burst_write_block_header_trace.xid,
       stll_burst_write_block_header_trace.query,
       stll_burst_write_block_header_trace.tbl,
       stll_burst_write_block_header_trace.node,
       stll_burst_write_block_header_trace.block_header_rcvd,
       stll_burst_write_block_header_trace.rcvd_time
FROM stll_burst_write_block_header_trace;

alter table stl_burst_write_block_header_trace
    owner to rdsdb;

