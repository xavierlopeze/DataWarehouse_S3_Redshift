create view svv_external_columns (schemaname, tablename, columnname, external_type, columnnum, part_key, is_nullable) as
SELECT btrim(ext_cols.schemaname::text)::character varying(128)    AS schemaname,
       btrim(ext_cols.tablename::text)::character varying(128)     AS tablename,
       btrim(ext_cols.columnname::text)::character varying(128)    AS columnname,
       btrim(ext_cols.external_type::text)::character varying(128) AS external_type,
       ext_cols.columnnum,
       ext_cols.part_key,
       btrim(ext_cols.is_nullable::text)::character varying(128)   AS is_nullable
FROM pg_get_external_columns() ext_cols(esoid integer, schemaname character varying, tablename character varying,
                                        columnname character varying, external_type character varying,
                                        columnnum integer, part_key integer, is_nullable character varying)
ORDER BY btrim(ext_cols.schemaname::text)::character varying(128),
         btrim(ext_cols.tablename::text)::character varying(128), ext_cols.columnnum;

alter table svv_external_columns
    owner to rdsdb;

grant select on svv_external_columns to public;

