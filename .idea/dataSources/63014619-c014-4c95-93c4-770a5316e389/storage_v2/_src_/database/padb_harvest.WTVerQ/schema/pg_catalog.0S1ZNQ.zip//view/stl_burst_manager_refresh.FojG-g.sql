create view stl_burst_manager_refresh(eventtime, action, type, pid, refresh_version, cluster_arn, error) as
SELECT stll_burst_manager_refresh.eventtime,
       stll_burst_manager_refresh."action",
       stll_burst_manager_refresh."type",
       stll_burst_manager_refresh.pid,
       stll_burst_manager_refresh.refresh_version,
       stll_burst_manager_refresh.cluster_arn,
       stll_burst_manager_refresh.error
FROM stll_burst_manager_refresh;

alter table stl_burst_manager_refresh
    owner to rdsdb;

