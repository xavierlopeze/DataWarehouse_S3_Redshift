create view stl_ssn_violation(xid, session_id, start_time, serialization_time, pstamp, sstamp) as
SELECT stll_ssn_violation.xid,
       stll_ssn_violation.session_id,
       stll_ssn_violation.start_time,
       stll_ssn_violation.serialization_time,
       stll_ssn_violation.pstamp,
       stll_ssn_violation.sstamp
FROM stll_ssn_violation;

alter table stl_ssn_violation
    owner to rdsdb;

