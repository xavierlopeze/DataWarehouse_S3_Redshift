create view stl_restarted_sessions
            (currenttime, dbname, newpid, oldpid, username, remotehost, remoteport, parkedtime, session_vars) as
SELECT stll_restarted_sessions.currenttime,
       stll_restarted_sessions.dbname,
       stll_restarted_sessions.newpid,
       stll_restarted_sessions.oldpid,
       stll_restarted_sessions.username,
       stll_restarted_sessions.remotehost,
       stll_restarted_sessions.remoteport,
       stll_restarted_sessions.parkedtime,
       stll_restarted_sessions.session_vars
FROM stll_restarted_sessions;

alter table stl_restarted_sessions
    owner to rdsdb;

grant select on stl_restarted_sessions to public;

