create view stl_block_io_metrics
            (node, start_time, end_time, fetch_in_memory_blocks, fetch_pending_io_blocks, fetch_primary_blocks,
             fetch_mirror_blocks, fetch_s3_blocks, primary_read_latency, mirror_read_latency, s3_read_latency,
             primary_write_latency, mirror_write_latency, rehydration_in_progress, block_rehydrated,
             block_need_rehydration, total_allocated_blocks, prefetch_primary_blocks, prefetch_mirror_blocks,
             prefetch_s3_blocks, s3_write_tagged_latency, s3_write_untagged_latency, s3_write_add_tag_latency,
             s3_write_delete_tag_latency, num_tagged_s3_writes, num_untagged_s3_writes, num_add_tags_issued_to_s3,
             num_delete_tags_issued_to_s3, num_tagged_temp_s3_writes, num_tagged_perm_spillover_s3_writes,
             num_untagged_perm_spillover_s3_writes, num_metadata_s3_writes)
as
SELECT stll_block_io_metrics.node,
       stll_block_io_metrics.start_time,
       stll_block_io_metrics.end_time,
       stll_block_io_metrics.fetch_in_memory_blocks,
       stll_block_io_metrics.fetch_pending_io_blocks,
       stll_block_io_metrics.fetch_primary_blocks,
       stll_block_io_metrics.fetch_mirror_blocks,
       stll_block_io_metrics.fetch_s3_blocks,
       stll_block_io_metrics.primary_read_latency,
       stll_block_io_metrics.mirror_read_latency,
       stll_block_io_metrics.s3_read_latency,
       stll_block_io_metrics.primary_write_latency,
       stll_block_io_metrics.mirror_write_latency,
       stll_block_io_metrics.rehydration_in_progress,
       stll_block_io_metrics.block_rehydrated,
       stll_block_io_metrics.block_need_rehydration,
       stll_block_io_metrics.total_allocated_blocks,
       stll_block_io_metrics.prefetch_primary_blocks,
       stll_block_io_metrics.prefetch_mirror_blocks,
       stll_block_io_metrics.prefetch_s3_blocks,
       stll_block_io_metrics.s3_write_tagged_latency,
       stll_block_io_metrics.s3_write_untagged_latency,
       stll_block_io_metrics.s3_write_add_tag_latency,
       stll_block_io_metrics.s3_write_delete_tag_latency,
       stll_block_io_metrics.num_tagged_s3_writes,
       stll_block_io_metrics.num_untagged_s3_writes,
       stll_block_io_metrics.num_add_tags_issued_to_s3,
       stll_block_io_metrics.num_delete_tags_issued_to_s3,
       stll_block_io_metrics.num_tagged_temp_s3_writes,
       stll_block_io_metrics.num_tagged_perm_spillover_s3_writes,
       stll_block_io_metrics.num_untagged_perm_spillover_s3_writes,
       stll_block_io_metrics.num_metadata_s3_writes
FROM stll_block_io_metrics;

alter table stl_block_io_metrics
    owner to rdsdb;

