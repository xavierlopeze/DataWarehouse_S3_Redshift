create view stl_scan
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, fetches, type, tbl,
             is_rrscan, is_delayed_scan, rows_pre_filter, rows_pre_user_filter, perm_table_name, is_rlf_scan,
             is_rlf_scan_reason, num_em_blocks, checksum, runtime_filtering, scan_region, num_sortkey_as_predicate,
             row_fetcher_state, consumed_scan_ranges, work_stealing_reason, is_vectorized_scan,
             is_vectorized_scan_reason, row_fetcher_reason, topology_signature)
as
SELECT stll_scan.userid,
       stll_scan.query,
       stll_scan.slice,
       stll_scan.segment,
       stll_scan.step,
       stll_scan.starttime,
       stll_scan.endtime,
       stll_scan.tasknum,
       stll_scan."rows",
       stll_scan.bytes,
       stll_scan.fetches,
       stll_scan."type",
       stll_scan.tbl,
       stll_scan.is_rrscan,
       stll_scan.is_delayed_scan,
       stll_scan.rows_pre_filter,
       stll_scan.rows_pre_user_filter,
       stll_scan.perm_table_name,
       stll_scan.is_rlf_scan,
       stll_scan.is_rlf_scan_reason,
       stll_scan.num_em_blocks,
       stll_scan.checksum,
       stll_scan.runtime_filtering,
       stll_scan.scan_region,
       stll_scan.num_sortkey_as_predicate,
       stll_scan.row_fetcher_state,
       stll_scan.consumed_scan_ranges,
       stll_scan.work_stealing_reason,
       stll_scan.is_vectorized_scan,
       stll_scan.is_vectorized_scan_reason,
       stll_scan.row_fetcher_reason,
       stll_scan.topology_signature
FROM stll_scan;

alter table stl_scan
    owner to rdsdb;

grant select on stl_scan to public;

