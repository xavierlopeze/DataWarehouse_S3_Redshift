create view stl_schema_quota_violations
            (ownerid, userid, xid, pid, schema_id, schema_name, quota, disk_usage, disk_usage_pct, timestamp,
             disk_usage_diff) as
SELECT stll_schema_quota_violations.ownerid,
       stll_schema_quota_violations.userid,
       stll_schema_quota_violations.xid,
       stll_schema_quota_violations.pid,
       stll_schema_quota_violations.schema_id,
       stll_schema_quota_violations.schema_name,
       stll_schema_quota_violations."quota",
       stll_schema_quota_violations.disk_usage,
       stll_schema_quota_violations.disk_usage_pct,
       stll_schema_quota_violations."timestamp",
       stll_schema_quota_violations.disk_usage_diff
FROM stll_schema_quota_violations;

alter table stl_schema_quota_violations
    owner to rdsdb;

grant select on stl_schema_quota_violations to public;

