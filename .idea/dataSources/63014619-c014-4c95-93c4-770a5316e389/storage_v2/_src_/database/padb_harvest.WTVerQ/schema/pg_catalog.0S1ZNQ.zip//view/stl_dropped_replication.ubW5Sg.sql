create view stl_dropped_replication
            (recordtime, slice, sb_pos, node, diskno, address, invalid, failed, reps_remaining, reason) as
SELECT stll_dropped_replication.recordtime,
       stll_dropped_replication.slice,
       stll_dropped_replication.sb_pos,
       stll_dropped_replication.node,
       stll_dropped_replication.diskno,
       stll_dropped_replication.address,
       stll_dropped_replication.invalid,
       stll_dropped_replication.failed,
       stll_dropped_replication.reps_remaining,
       stll_dropped_replication.reason
FROM stll_dropped_replication;

alter table stl_dropped_replication
    owner to rdsdb;

