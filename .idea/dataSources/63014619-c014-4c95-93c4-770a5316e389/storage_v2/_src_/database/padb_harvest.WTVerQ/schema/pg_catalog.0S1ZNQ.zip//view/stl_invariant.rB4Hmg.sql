create view stl_invariant(node, process, now, name, message, padb_version) as
SELECT stll_invariant.node,
       stll_invariant.process,
       stll_invariant.now,
       stll_invariant.name,
       stll_invariant.message,
       stll_invariant.padb_version
FROM stll_invariant;

alter table stl_invariant
    owner to rdsdb;

