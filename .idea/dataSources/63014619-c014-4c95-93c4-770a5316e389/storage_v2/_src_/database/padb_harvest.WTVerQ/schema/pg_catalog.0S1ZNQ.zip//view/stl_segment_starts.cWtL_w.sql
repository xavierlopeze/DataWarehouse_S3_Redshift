create view stl_segment_starts(userid, node, tasknum, pid, starttime, query, slice, seg) as
SELECT stll_segment_starts.userid,
       stll_segment_starts.node,
       stll_segment_starts.tasknum,
       stll_segment_starts.pid,
       stll_segment_starts.starttime,
       stll_segment_starts.query,
       stll_segment_starts.slice,
       stll_segment_starts.seg
FROM stll_segment_starts;

alter table stl_segment_starts
    owner to rdsdb;

