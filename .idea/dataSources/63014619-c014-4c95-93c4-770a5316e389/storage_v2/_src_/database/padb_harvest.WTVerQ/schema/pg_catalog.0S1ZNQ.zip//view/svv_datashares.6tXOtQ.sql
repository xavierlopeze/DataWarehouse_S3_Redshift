create view svv_datashares
            (share_name, share_id, share_owner, source_database, consumer_database, share_type, createdate,
             is_publicaccessible, share_acl, producer_account, producer_namespace)
as
SELECT ds.sharename::character varying(128)                            AS share_name,
       ds.oid                                                          AS share_id,
       ds.shareowner                                                   AS share_owner,
       pd.datname::character varying(128)                              AS source_database,
       NULL::"unknown"                                                 AS consumer_database,
       'OUTBOUND'                                                      AS share_type,
       ds.createdate,
       ds.publicaccess                                                 AS is_publicaccessible,
       array_to_string(ds.shareacl, '~'::text)::character varying(256) AS share_acl,
       "current_aws_account"()                                         AS producer_account,
       "current_namespace"()                                           AS producer_namespace
FROM pg_datashare ds
         JOIN pg_database pd ON ds.sharedb = pd.oid
WHERE has_datashare_privilege("current_user"()::name, ds.sharename::text)
UNION ALL
SELECT inbound_shares.share_name,
       NULL::"unknown"                     AS share_id,
       NULL::"unknown"                     AS share_owner,
       NULL::"unknown"                     AS source_database,
       pgd.datname::character varying(128) AS consumer_database,
       'INBOUND'                           AS share_type,
       NULL::"unknown"                     AS createdate,
       inbound_shares.is_publicaccessible,
       NULL::"unknown"                     AS share_acl,
       inbound_shares.producer_account,
       inbound_shares.producer_namespace
FROM (SELECT btrim("tables".share_name::text)::character varying(128)        AS share_name,
             btrim("tables".share_id::text)::character varying(256)          AS share_id,
             btrim("tables".producer_account::text)::character varying(16)   AS producer_account,
             btrim("tables".producer_namespace::text)::character varying(64) AS producer_namespace,
             "tables".is_publicaccessible
      FROM pg_get_inbound_datashares() "tables"(share_name character varying, share_id character varying,
                                                producer_account character varying,
                                                producer_namespace character varying,
                                                is_publicaccessible boolean)) inbound_shares
         LEFT JOIN pg_external_database ped ON ped.shareid = inbound_shares.share_id::text
         LEFT JOIN pg_database pgd ON pgd.oid = ped.dbid;

alter table svv_datashares
    owner to rdsdb;

grant select on svv_datashares to public;

