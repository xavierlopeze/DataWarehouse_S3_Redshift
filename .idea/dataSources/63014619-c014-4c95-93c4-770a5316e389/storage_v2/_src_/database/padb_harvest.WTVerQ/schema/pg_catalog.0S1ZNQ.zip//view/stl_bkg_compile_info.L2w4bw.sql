create view stl_bkg_compile_info
            (userid, xid, pid, query, segment, locus, starttime, endtime, bytes, path, compile, complevel, cachehit,
             tokwaittime, compilestarttime, compileendtime, compilelocktime, compilememory, putsuccess, getsuccess,
             puttime, gettime, objsize, skip_opt_compile)
as
SELECT stll_bkg_compile_info.userid,
       stll_bkg_compile_info.xid,
       stll_bkg_compile_info.pid,
       stll_bkg_compile_info.query,
       stll_bkg_compile_info.segment,
       stll_bkg_compile_info.locus,
       stll_bkg_compile_info.starttime,
       stll_bkg_compile_info.endtime,
       stll_bkg_compile_info.bytes,
       stll_bkg_compile_info."path",
       stll_bkg_compile_info.compile,
       stll_bkg_compile_info.complevel,
       stll_bkg_compile_info.cachehit,
       stll_bkg_compile_info.tokwaittime,
       stll_bkg_compile_info.compilestarttime,
       stll_bkg_compile_info.compileendtime,
       stll_bkg_compile_info.compilelocktime,
       stll_bkg_compile_info.compilememory,
       stll_bkg_compile_info.putsuccess,
       stll_bkg_compile_info.getsuccess,
       stll_bkg_compile_info.puttime,
       stll_bkg_compile_info.gettime,
       stll_bkg_compile_info.objsize,
       stll_bkg_compile_info.skip_opt_compile
FROM stll_bkg_compile_info;

alter table stl_bkg_compile_info
    owner to rdsdb;

