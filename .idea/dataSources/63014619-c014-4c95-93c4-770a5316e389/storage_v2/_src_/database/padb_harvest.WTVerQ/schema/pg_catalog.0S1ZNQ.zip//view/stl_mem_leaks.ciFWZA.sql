create view stl_mem_leaks(recordtime, node, type, uid, pid, requested, allocated, page, leaked) as
SELECT stll_mem_leaks.recordtime,
       stll_mem_leaks.node,
       stll_mem_leaks."type",
       stll_mem_leaks.uid,
       stll_mem_leaks.pid,
       stll_mem_leaks.requested,
       stll_mem_leaks.allocated,
       stll_mem_leaks.page,
       stll_mem_leaks.leaked
FROM stll_mem_leaks;

alter table stl_mem_leaks
    owner to rdsdb;

