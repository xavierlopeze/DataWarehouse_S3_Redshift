create view stl_lwlock(log_time, pid, lwlockid, lwlock_name, mode, acquire_wait_us) as
SELECT stll_lwlock.log_time,
       stll_lwlock.pid,
       stll_lwlock.lwlockid,
       stll_lwlock.lwlock_name,
       stll_lwlock."mode",
       stll_lwlock.acquire_wait_us
FROM stll_lwlock;

alter table stl_lwlock
    owner to rdsdb;

