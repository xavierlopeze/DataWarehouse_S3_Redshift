create view svv_sem_usage
            (name, miss_ratio, waits, requests, wait_time_sec, longest_sec, miss_wait_msec, expected_wait_msec) as
SELECT stv_sem_usage.name,
       round(sum(stv_sem_usage.count)::double precision / sum(stv_sem_usage.mutex_requests)::double precision *
             100.0::double precision, 2::numeric)                                                               AS miss_ratio,
       sum(stv_sem_usage.count)                                                                                 AS waits,
       sum(stv_sem_usage.mutex_requests)                                                                        AS requests,
       round(sum(stv_sem_usage.waiting_time)::numeric / 1000000.0, 3)                                           AS wait_time_sec,
       round("max"(stv_sem_usage.longest)::numeric / 1000000.0, 3)                                              AS longest_sec,
       round(sum(stv_sem_usage.waiting_time)::numeric / 1000.0 / sum(stv_sem_usage.count)::numeric,
             2)                                                                                                 AS miss_wait_msec,
       round(sum(stv_sem_usage.waiting_time)::numeric / 1000.0 / sum(stv_sem_usage.mutex_requests)::numeric,
             3)                                                                                                 AS expected_wait_msec
FROM stv_sem_usage
WHERE stv_sem_usage.node < 1000
GROUP BY stv_sem_usage.name
HAVING sum(stv_sem_usage.count) > 0
   AND sum(stv_sem_usage.mutex_requests) > 0
ORDER BY round(sum(stv_sem_usage.waiting_time)::numeric / 1000000.0, 3) DESC;

alter table svv_sem_usage
    owner to rdsdb;

