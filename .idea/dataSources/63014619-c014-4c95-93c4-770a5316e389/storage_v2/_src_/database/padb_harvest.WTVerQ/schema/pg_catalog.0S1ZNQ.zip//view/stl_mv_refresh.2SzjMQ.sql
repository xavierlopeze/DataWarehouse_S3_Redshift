create view stl_mv_refresh (userid, xid, starttime, endtime, schemaoid, mvoid, status, refresh_type, db_oid) as
SELECT stll_mv_refresh.userid,
       stll_mv_refresh.xid,
       stll_mv_refresh.starttime,
       stll_mv_refresh.endtime,
       stll_mv_refresh.schemaoid,
       stll_mv_refresh.mvoid,
       stll_mv_refresh.status,
       stll_mv_refresh.refresh_type,
       stll_mv_refresh.db_oid
FROM stll_mv_refresh;

alter table stl_mv_refresh
    owner to rdsdb;

