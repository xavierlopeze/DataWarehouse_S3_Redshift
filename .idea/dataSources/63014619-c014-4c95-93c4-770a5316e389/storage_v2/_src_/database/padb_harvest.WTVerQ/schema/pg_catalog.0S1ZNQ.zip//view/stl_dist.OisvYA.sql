create view stl_dist
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, packets, topology_signature,
             is_intra_node)
as
SELECT stll_dist.userid,
       stll_dist.query,
       stll_dist.slice,
       stll_dist.segment,
       stll_dist.step,
       stll_dist.starttime,
       stll_dist.endtime,
       stll_dist.tasknum,
       stll_dist."rows",
       stll_dist.bytes,
       stll_dist.packets,
       stll_dist.topology_signature,
       stll_dist.is_intra_node
FROM stll_dist;

alter table stl_dist
    owner to rdsdb;

grant select on stl_dist to public;

