create view stl_backup_leader
            (currenttime, backup_id, sb_version, starttime, in_progress, error_code, error_msg, enc_key_hash_base64,
             tlr_metadata_successful, tlr_metadata_time, tlr_metadata_error_msg, partial, backup_superblock_format,
             time_wait_commit_lock, time_hold_commit_lock, time_spent_commit_transaction, inc_no_backup,
             sb_version_stage3, backup_superblock_method, num_tables, inc_resize_lock_optional,
             inc_resize_lock_mandatory)
as
SELECT stll_backup_leader.currenttime,
       stll_backup_leader.backup_id,
       stll_backup_leader.sb_version,
       stll_backup_leader.starttime,
       stll_backup_leader.in_progress,
       stll_backup_leader.error_code,
       stll_backup_leader.error_msg,
       stll_backup_leader.enc_key_hash_base64,
       stll_backup_leader.tlr_metadata_successful,
       stll_backup_leader.tlr_metadata_time,
       stll_backup_leader.tlr_metadata_error_msg,
       stll_backup_leader."partial",
       stll_backup_leader.backup_superblock_format,
       stll_backup_leader.time_wait_commit_lock,
       stll_backup_leader.time_hold_commit_lock,
       stll_backup_leader.time_spent_commit_transaction,
       stll_backup_leader.inc_no_backup,
       stll_backup_leader.sb_version_stage3,
       stll_backup_leader.backup_superblock_method,
       stll_backup_leader.num_tables,
       stll_backup_leader.inc_resize_lock_optional,
       stll_backup_leader.inc_resize_lock_mandatory
FROM stll_backup_leader;

alter table stl_backup_leader
    owner to rdsdb;

