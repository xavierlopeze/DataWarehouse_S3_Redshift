create view stl_table_partition_scan
            (query, segment, step, slice, col, part, blocks_read, blocks_used, rows_read, rows_used) as
SELECT stll_table_partition_scan.query,
       stll_table_partition_scan.segment,
       stll_table_partition_scan.step,
       stll_table_partition_scan.slice,
       stll_table_partition_scan.col,
       stll_table_partition_scan.part,
       stll_table_partition_scan.blocks_read,
       stll_table_partition_scan.blocks_used,
       stll_table_partition_scan.rows_read,
       stll_table_partition_scan.rows_used
FROM stll_table_partition_scan;

alter table stl_table_partition_scan
    owner to rdsdb;

