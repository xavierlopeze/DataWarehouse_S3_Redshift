create view stl_udf_compile_error(userid, recordtime, pid, error) as
SELECT stll_udf_compile_error.userid,
       stll_udf_compile_error.recordtime,
       stll_udf_compile_error.pid,
       stll_udf_compile_error.error
FROM stll_udf_compile_error;

alter table stl_udf_compile_error
    owner to rdsdb;

grant select on stl_udf_compile_error to public;

