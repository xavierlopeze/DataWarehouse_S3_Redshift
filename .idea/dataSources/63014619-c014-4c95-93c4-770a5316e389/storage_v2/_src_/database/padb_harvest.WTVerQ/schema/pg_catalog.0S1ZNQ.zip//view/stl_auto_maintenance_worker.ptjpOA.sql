create view stl_auto_maintenance_worker
            (userid, pid, mode, db_id, xid, table_id, eventtime, pause_count, tables_skipped, status, error_message) as
SELECT stll_auto_maintenance_worker.userid,
       stll_auto_maintenance_worker.pid,
       stll_auto_maintenance_worker."mode",
       stll_auto_maintenance_worker.db_id,
       stll_auto_maintenance_worker.xid,
       stll_auto_maintenance_worker.table_id,
       stll_auto_maintenance_worker.eventtime,
       stll_auto_maintenance_worker.pause_count,
       stll_auto_maintenance_worker.tables_skipped,
       stll_auto_maintenance_worker.status,
       stll_auto_maintenance_worker.error_message
FROM stll_auto_maintenance_worker;

alter table stl_auto_maintenance_worker
    owner to rdsdb;

