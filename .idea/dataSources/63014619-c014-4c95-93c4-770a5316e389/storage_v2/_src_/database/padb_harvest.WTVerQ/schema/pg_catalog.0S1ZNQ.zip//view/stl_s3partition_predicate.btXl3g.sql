create view stl_s3partition_predicate
            (userid, query, segment, node, slice, eventtime, predicate, effectiveness, error) as
SELECT stll_s3partition_predicate.userid,
       stll_s3partition_predicate.query,
       stll_s3partition_predicate.segment,
       stll_s3partition_predicate.node,
       stll_s3partition_predicate.slice,
       stll_s3partition_predicate.eventtime,
       stll_s3partition_predicate."predicate",
       stll_s3partition_predicate.effectiveness,
       stll_s3partition_predicate.error
FROM stll_s3partition_predicate;

alter table stl_s3partition_predicate
    owner to rdsdb;

