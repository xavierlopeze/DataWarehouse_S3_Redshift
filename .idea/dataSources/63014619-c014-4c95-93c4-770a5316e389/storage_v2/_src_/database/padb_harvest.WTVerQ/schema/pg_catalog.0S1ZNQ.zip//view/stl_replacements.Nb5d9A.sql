create view stl_replacements
            (userid, slice, tbl, starttime, session, query, filename, line_number, colname, raw_line) as
SELECT stll_replacements.userid,
       stll_replacements.slice,
       stll_replacements.tbl,
       stll_replacements.starttime,
       stll_replacements."session",
       stll_replacements.query,
       stll_replacements.filename,
       stll_replacements.line_number,
       stll_replacements.colname,
       stll_replacements.raw_line
FROM stll_replacements;

alter table stl_replacements
    owner to rdsdb;

grant select on stl_replacements to public;

