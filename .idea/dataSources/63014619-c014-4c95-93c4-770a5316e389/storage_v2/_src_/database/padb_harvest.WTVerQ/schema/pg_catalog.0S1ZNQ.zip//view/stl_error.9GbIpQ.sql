create view stl_error (userid, process, recordtime, pid, errcode, file, linenum, context, error) as
SELECT stll_error.userid,
       stll_error.process,
       stll_error.recordtime,
       stll_error.pid,
       stll_error.errcode,
       stll_error."file",
       stll_error.linenum,
       stll_error.context,
       stll_error.error
FROM stll_error;

alter table stl_error
    owner to rdsdb;

grant select on stl_error to public;

