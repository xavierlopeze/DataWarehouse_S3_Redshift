create view stl_delete_tag_throttle
            (node_num, window_start, window_end, xid, max_delete_tags, delete_tags_outstanding, delete_tags_total,
             delete_tags_window, tps, contains_burst_write)
as
SELECT stll_delete_tag_throttle.node_num,
       stll_delete_tag_throttle.window_start,
       stll_delete_tag_throttle.window_end,
       stll_delete_tag_throttle.xid,
       stll_delete_tag_throttle.max_delete_tags,
       stll_delete_tag_throttle.delete_tags_outstanding,
       stll_delete_tag_throttle.delete_tags_total,
       stll_delete_tag_throttle.delete_tags_window,
       stll_delete_tag_throttle.tps,
       stll_delete_tag_throttle.contains_burst_write
FROM stll_delete_tag_throttle;

alter table stl_delete_tag_throttle
    owner to rdsdb;

